package com.goatmusic.app.player

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class GoatPlaybackService : Service() {

    companion object {
        @Volatile
        var latestNotification: Notification? = null
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onCreate() {
        super.onCreate()
        acquireLocks()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            GoatNotificationBridge.ACTION_PREV -> GoatNotificationBridge.onPrevCallback?.invoke()
            GoatNotificationBridge.ACTION_PLAY_PAUSE -> GoatNotificationBridge.onPlayPauseCallback?.invoke()
            GoatNotificationBridge.ACTION_NEXT -> GoatNotificationBridge.onNextCallback?.invoke()
            GoatNotificationBridge.ACTION_LIKE -> GoatNotificationBridge.onLikeCallback?.invoke()
            GoatNotificationBridge.ACTION_STOP_CLOSE -> {
                GoatNotificationBridge.onAppSwipedClosedCallback?.invoke()
                stopForegroundCleanup()
                return START_NOT_STICKY
            }
        }

        val notif = latestNotification
        if (notif != null) {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        GoatNotificationBridge.NOTIFICATION_ID,
                        notif,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                    )
                } else {
                    startForeground(GoatNotificationBridge.NOTIFICATION_ID, notif)
                }
            }
        }

        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        GoatNotificationBridge.onAppSwipedClosedCallback?.invoke()
        stopForegroundCleanup()
        super.onTaskRemoved(rootIntent)
    }

    private fun stopForegroundCleanup() {
        releaseLocks()
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        }
        runCatching {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(GoatNotificationBridge.NOTIFICATION_ID)
            nm.cancelAll()
        }
        stopSelf()
    }

    private fun acquireLocks() {
        runCatching {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GoatMusic::PlaybackWakeLock").apply {
                    setReferenceCounted(false)
                    acquire(4 * 60 * 60 * 1000L)
                }
            }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (wifiLock == null) {
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "GoatMusic::PlaybackWifiLock").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        }
    }

    private fun releaseLocks() {
        runCatching {
            wakeLock?.let { if (it.isHeld) it.release() }
            wakeLock = null
            wifiLock?.let { if (it.isHeld) it.release() }
            wifiLock = null
        }
    }

    override fun onDestroy() {
        releaseLocks()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
