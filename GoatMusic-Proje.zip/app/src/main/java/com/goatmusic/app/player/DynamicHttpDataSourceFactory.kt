@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.goatmusic.app.player

import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultHttpDataSource
import com.goatmusic.app.engine.GoatStreamEngine

class DynamicHttpDataSourceFactory : DataSource.Factory {
    override fun createDataSource(): DataSource {
        val headers = mutableMapOf(
            "Referer" to GoatStreamEngine.activePlaybackReferer,
            "Origin" to "https://www.youtube.com"
        )
        val cookies = GoatStreamEngine.getYouTubeCookies()
        if (cookies.isNotBlank()) {
            headers["Cookie"] = cookies
        }

        return DefaultHttpDataSource.Factory()
            .setUserAgent(GoatStreamEngine.activePlaybackUserAgent)
            .setDefaultRequestProperties(headers)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20_000)
            .setReadTimeoutMs(30_000)
            .createDataSource()
    }
}
