package com.goatmusic.app.data

import android.content.Context
import com.goatmusic.app.model.GoatTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class LibraryRepository(context: Context) {

    private val prefs = context.getSharedPreferences("goat_music_library", Context.MODE_PRIVATE)

    fun getSavedTracks(): List<GoatTrack> {
        val raw = prefs.getString("saved_tracks_json", "[]") ?: "[]"
        val list = mutableListOf<GoatTrack>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val audioPath = o.optString("localAudioPath").takeIf { it.isNotBlank() && File(it).exists() }
                val videoPath = o.optString("localVideoPath").takeIf { it.isNotBlank() && File(it).exists() }
                list.add(
                    GoatTrack(
                        id = o.optString("id"),
                        title = o.optString("title"),
                        artist = o.optString("artist"),
                        durationText = o.optString("durationText"),
                        durationSec = o.optLong("durationSec", 0L),
                        thumbnailUrl = o.optString("thumbnailUrl"),
                        localAudioPath = audioPath,
                        localVideoPath = videoPath,
                        isFavorite = o.optBoolean("isFavorite", false),
                        addedAt = o.optLong("addedAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list.sortedByDescending { it.addedAt }
    }

    fun upsertTrack(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = track.copy(
                localAudioPath = track.localAudioPath ?: existing.localAudioPath,
                localVideoPath = track.localVideoPath ?: existing.localVideoPath,
                isFavorite = track.isFavorite || existing.isFavorite
            )
        } else {
            current.add(0, track)
        }
        saveAll(current)
        return current
    }

    fun toggleFavorite(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(isFavorite = !existing.isFavorite)
        } else {
            current.add(0, track.copy(isFavorite = true))
        }
        saveAll(current)
        return current
    }

    fun removeTrack(trackId: String): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val target = current.find { it.id == trackId }
        target?.localAudioPath?.let { runCatching { File(it).delete() } }
        target?.localVideoPath?.let { runCatching { File(it).delete() } }
        current.removeAll { it.id == trackId }
        saveAll(current)
        return current
    }

    private fun saveAll(tracks: List<GoatTrack>) {
        val arr = JSONArray()
        tracks.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("artist", t.artist)
                put("durationText", t.durationText)
                put("durationSec", t.durationSec)
                put("thumbnailUrl", t.thumbnailUrl)
                put("localAudioPath", t.localAudioPath.orEmpty())
                put("localVideoPath", t.localVideoPath.orEmpty())
                put("isFavorite", t.isFavorite)
                put("addedAt", t.addedAt)
            })
        }
        prefs.edit().putString("saved_tracks_json", arr.toString()).apply()
    }
}
