package com.goatmusic.app.data

import android.content.Context
import android.os.Environment
import android.util.Log
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class LibraryRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("goat_music_library_v6", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "LibraryRepository"
        const val PLAYLIST_LIKED_ID = "sys_liked"
        const val PLAYLIST_DOWNLOADED_ID = "sys_downloaded"
        private const val VAULT_FOLDER_NAME = "GoatMusic_Vault"
        private const val VAULT_DB_FILE_NAME = "goat_vault_db_v6.json"

        fun getIsolatedVaultDirectory(context: Context): File {
            val publicDocVault = runCatching {
                val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                val dir = File(docs, VAULT_FOLDER_NAME)
                if (!dir.exists()) dir.mkdirs()
                val nomedia = File(dir, ".nomedia")
                if (!nomedia.exists()) nomedia.createNewFile()
                if (dir.canWrite()) dir else null
            }.getOrNull()

            if (publicDocVault != null) return publicDocVault

            val appVault = File(context.getExternalFilesDir(null) ?: context.filesDir, VAULT_FOLDER_NAME)
            if (!appVault.exists()) appVault.mkdirs()
            runCatching {
                val nomedia = File(appVault, ".nomedia")
                if (!nomedia.exists()) nomedia.createNewFile()
            }
            return appVault
        }
    }

    init {
        migrateOrRestoreVaultDatabase()
        syncIsolatedVaultFiles()
    }

    private fun getVaultDbFiles(): List<File> {
        val list = mutableListOf<File>()
        runCatching {
            val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            val dir = File(docs, VAULT_FOLDER_NAME).apply { mkdirs() }
            File(dir, ".nomedia").apply { if (!exists()) createNewFile() }
            list.add(File(dir, VAULT_DB_FILE_NAME))
        }
        runCatching {
            val appDir = File(context.getExternalFilesDir(null) ?: context.filesDir, VAULT_FOLDER_NAME).apply { mkdirs() }
            list.add(File(appDir, VAULT_DB_FILE_NAME))
        }
        return list
    }

    private fun saveVaultDatabaseToDisk() {
        try {
            val root = JSONObject().apply {
                put("tracks", JSONArray(prefs.getString("saved_tracks_json", "[]") ?: "[]"))
                put("playlists", JSONArray(prefs.getString("custom_playlists_json", "[]") ?: "[]"))
                put("liked_order", JSONArray(prefs.getString("liked_order_json", "[]") ?: "[]"))
                put("downloaded_order", JSONArray(prefs.getString("downloaded_order_json", "[]") ?: "[]"))
                put("updatedAt", System.currentTimeMillis())
            }
            val bytes = root.toString().toByteArray(Charsets.UTF_8)
            for (dbFile in getVaultDbFiles()) {
                runCatching {
                    dbFile.parentFile?.mkdirs()
                    FileOutputStream(dbFile, false).use { it.write(bytes) }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "saveVaultDatabaseToDisk note: ${e.message}")
        }
    }

    private fun migrateOrRestoreVaultDatabase() {
        val currentRaw = prefs.getString("saved_tracks_json", null)
        if (!currentRaw.isNullOrBlank() && currentRaw != "[]") return

        for (dbFile in getVaultDbFiles()) {
            try {
                if (dbFile.exists() && dbFile.length() > 10L) {
                    val root = JSONObject(dbFile.readText(Charsets.UTF_8))
                    val tracksArr = root.optJSONArray("tracks")
                    val playlistsArr = root.optJSONArray("playlists")
                    val likedOrderArr = root.optJSONArray("liked_order")
                    val dlOrderArr = root.optJSONArray("downloaded_order")
                    val editor = prefs.edit()
                    if (tracksArr != null) editor.putString("saved_tracks_json", tracksArr.toString())
                    if (playlistsArr != null) editor.putString("custom_playlists_json", playlistsArr.toString())
                    if (likedOrderArr != null) editor.putString("liked_order_json", likedOrderArr.toString())
                    if (dlOrderArr != null) editor.putString("downloaded_order_json", dlOrderArr.toString())
                    editor.apply()
                    return
                }
            } catch (_: Exception) {
            }
        }

        for (oldPrefName in listOf("goat_music_library_v5", "goat_music_library_v4")) {
            val oldPrefs = context.getSharedPreferences(oldPrefName, Context.MODE_PRIVATE)
            val oldTracks = oldPrefs.getString("saved_tracks_json", null)
            if (!oldTracks.isNullOrBlank() && oldTracks != "[]") {
                prefs.edit()
                    .putString("saved_tracks_json", oldTracks)
                    .putString("custom_playlists_json", oldPrefs.getString("custom_playlists_json", "[]"))
                    .putString("liked_order_json", oldPrefs.getString("liked_order_json", "[]"))
                    .putString("downloaded_order_json", oldPrefs.getString("downloaded_order_json", "[]"))
                    .apply()
                saveVaultDatabaseToDisk()
                return
            }
        }
    }

    fun syncIsolatedVaultFiles() {
        try {
            val current = getSavedTracks().toMutableList()
            var changed = false

            val vaultDirs = mutableListOf<File>()
            runCatching {
                val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                vaultDirs.add(File(docs, VAULT_FOLDER_NAME))
            }
            runCatching {
                vaultDirs.add(File(context.getExternalFilesDir(null) ?: context.filesDir, VAULT_FOLDER_NAME))
                context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)?.let {
                    vaultDirs.add(File(it, "GoatMusic"))
                }
            }

            val vaultFiles = mutableListOf<File>()
            vaultDirs.forEach { dir ->
                if (dir.exists() && dir.isDirectory) {
                    dir.listFiles()?.forEach { f ->
                        if (f.isFile && (f.name.startsWith("GMV_") || dir.parentFile?.name == "Music") && f.length() > 15_000L) {
                            vaultFiles.add(f)
                        }
                    }
                }
            }

            for (f in vaultFiles) {
                val ext = f.extension.lowercase()
                if (ext != "m4a" && ext != "mp4") continue
                val rawBase = f.nameWithoutExtension.removePrefix("GMV_")
                val extractedId = rawBase.substringAfterLast("_", "").takeIf { it.length == 11 } ?: continue
                val cleanName = rawBase.substringBeforeLast("_")
                val title = cleanName.substringBefore(" - ").trim().ifBlank { cleanName }
                val artist = cleanName.substringAfter(" - ", "Goat Music").trim()

                val existingIdx = current.indexOfFirst { it.id == extractedId }
                if (existingIdx >= 0) {
                    val ex = current[existingIdx]
                    val updated = if (ext == "m4a" && ex.localAudioPath.isNullOrBlank()) {
                        ex.copy(localAudioPath = f.absolutePath)
                    } else if (ext == "mp4" && ex.localVideoPath.isNullOrBlank()) {
                        ex.copy(localVideoPath = f.absolutePath)
                    } else ex
                    if (updated != ex) {
                        current[existingIdx] = updated
                        changed = true
                    }
                } else {
                    current.add(
                        GoatTrack(
                            id = extractedId,
                            title = title,
                            artist = artist,
                            durationText = "",
                            durationSec = 0L,
                            thumbnailUrl = "https://i.ytimg.com/vi/$extractedId/hqdefault.jpg",
                            localAudioPath = if (ext == "m4a") f.absolutePath else null,
                            localVideoPath = if (ext == "mp4") f.absolutePath else null
                        )
                    )
                    changed = true
                }
            }

            if (changed) {
                saveAllTracks(current)
            }
        } catch (e: Exception) {
            Log.w(TAG, "syncIsolatedVaultFiles note: ${e.message}")
        }
    }

    fun getSavedTracks(): List<GoatTrack> {
        val raw = prefs.getString("saved_tracks_json", "[]") ?: "[]"
        val list = mutableListOf<GoatTrack>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (id.startsWith("ms_") || id.startsWith("local_")) continue
                val audioPath = o.optString("localAudioPath").takeIf { it.isNotBlank() && File(it).exists() }
                val videoPath = o.optString("localVideoPath").takeIf { it.isNotBlank() && File(it).exists() }
                list.add(
                    GoatTrack(
                        id = id,
                        title = o.optString("title"),
                        artist = o.optString("artist"),
                        durationText = o.optString("durationText"),
                        durationSec = o.optLong("durationSec", 0L),
                        thumbnailUrl = o.optString("thumbnailUrl"),
                        localAudioPath = audioPath,
                        localVideoPath = videoPath,
                        isFavorite = o.optBoolean("isFavorite", false),
                        playCount = o.optInt("playCount", 0),
                        lastPlayedAt = o.optLong("lastPlayedAt", 0L),
                        addedAt = o.optLong("addedAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun recordTrackPlayed(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val now = System.currentTimeMillis()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(
                playCount = existing.playCount + 1,
                lastPlayedAt = now,
                durationSec = if (track.durationSec > 0L) track.durationSec else existing.durationSec,
                durationText = track.durationText.ifBlank { existing.durationText },
                localAudioPath = track.localAudioPath ?: existing.localAudioPath,
                localVideoPath = track.localVideoPath ?: existing.localVideoPath
            )
        } else {
            current.add(0, track.copy(playCount = 1, lastPlayedAt = now))
        }
        saveAllTracks(current)
        return current
    }

    fun upsertTrack(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(
                title = track.title,
                artist = track.artist,
                durationSec = if (track.durationSec > 0L) track.durationSec else existing.durationSec,
                durationText = track.durationText.ifBlank { existing.durationText },
                localAudioPath = track.localAudioPath ?: existing.localAudioPath,
                localVideoPath = track.localVideoPath ?: existing.localVideoPath,
                isFavorite = track.isFavorite || existing.isFavorite
            )
        } else {
            current.add(0, track)
        }
        saveAllTracks(current)
        return current
    }

    fun toggleFavorite(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(isFavorite = !existing.isFavorite)
        } else {
            current.add(0, track.copy(isFavorite = true))
        }
        saveAllTracks(current)
        return current
    }

    fun deleteDownloadedFiles(trackId: String): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == trackId }
        if (idx >= 0) {
            val target = current[idx]
            target.localAudioPath?.let { runCatching { File(it).delete() } }
            target.localVideoPath?.let { runCatching { File(it).delete() } }
            current[idx] = target.copy(localAudioPath = null, localVideoPath = null)
        }
        saveAllTracks(current)
        return current
    }

    private fun saveAllTracks(tracks: List<GoatTrack>) {
        val arr = JSONArray()
        tracks.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("artist", t.artist)
                put("durationText", t.durationText)
                put("durationSec", t.durationSec)
                put("thumbnailUrl", t.thumbnailUrl)
                put("localAudioPath", t.localAudioPath.orEmpty())
                put("localVideoPath", t.localVideoPath.orEmpty())
                put("isFavorite", t.isFavorite)
                put("playCount", t.playCount)
                put("lastPlayedAt", t.lastPlayedAt)
                put("addedAt", t.addedAt)
            })
        }
        prefs.edit().putString("saved_tracks_json", arr.toString()).apply()
        saveVaultDatabaseToDisk()
    }

    private fun getOrderList(prefKey: String): List<String> {
        val raw = prefs.getString(prefKey, "[]") ?: "[]"
        val res = mutableListOf<String>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val id = arr.optString(i)
                if (id.isNotBlank()) res.add(id)
            }
        }
        return res
    }

    private fun saveOrderList(prefKey: String, ids: List<String>) {
        val arr = JSONArray()
        ids.forEach { arr.put(it) }
        prefs.edit().putString(prefKey, arr.toString()).apply()
        saveVaultDatabaseToDisk()
    }

    fun getAllPlaylistsWithSystem(tracks: List<GoatTrack>): List<GoatPlaylist> {
        val likedTracks = tracks.filter { it.isFavorite }
        val likedOrder = getOrderList("liked_order_json")
        val orderedLikedIds = (likedOrder.filter { id -> likedTracks.any { it.id == id } } +
            likedTracks.map { it.id }.filterNot { likedOrder.contains(it) }).distinct()

        val downloadedTracks = tracks.filter { it.isDownloadedAny }
        val dlOrder = getOrderList("downloaded_order_json")
        val orderedDlIds = (dlOrder.filter { id -> downloadedTracks.any { it.id == id } } +
            downloadedTracks.map { it.id }.filterNot { dlOrder.contains(it) }).distinct()

        val systemPlaylists = listOf(
            GoatPlaylist(
                id = PLAYLIST_LIKED_ID,
                name = "Beğenilen Şarkılar",
                trackIds = orderedLikedIds,
                isSystemPlaylist = true
            ),
            GoatPlaylist(
                id = PLAYLIST_DOWNLOADED_ID,
                name = "İndirilen Şarkılar",
                trackIds = orderedDlIds,
                isSystemPlaylist = true
            )
        )
        return systemPlaylists + getCustomPlaylists()
    }

    private fun getCustomPlaylists(): List<GoatPlaylist> {
        val raw = prefs.getString("custom_playlists_json", "[]") ?: "[]"
        val list = mutableListOf<GoatPlaylist>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val tArr = o.optJSONArray("trackIds") ?: JSONArray()
                val ids = mutableListOf<String>()
                for (j in 0 until tArr.length()) {
                    val tid = tArr.optString(j)
                    if (tid.isNotBlank()) ids.add(tid)
                }
                list.add(
                    GoatPlaylist(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        trackIds = ids,
                        isSystemPlaylist = false,
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        }
        return list
    }

    private fun saveCustomPlaylists(playlists: List<GoatPlaylist>) {
        val arr = JSONArray()
        playlists.filterNot { it.isSystemPlaylist }.forEach { pl ->
            arr.put(JSONObject().apply {
                put("id", pl.id)
                put("name", pl.name)
                val tArr = JSONArray()
                pl.trackIds.forEach { tArr.put(it) }
                put("trackIds", tArr)
                put("createdAt", pl.createdAt)
            })
        }
        prefs.edit().putString("custom_playlists_json", arr.toString()).apply()
        saveVaultDatabaseToDisk()
    }

    fun createCustomPlaylist(name: String): List<GoatPlaylist> {
        val current = getCustomPlaylists().toMutableList()
        current.add(
            GoatPlaylist(
                id = "pl_" + UUID.randomUUID().toString().take(8),
                name = name.trim(),
                trackIds = emptyList(),
                isSystemPlaylist = false
            )
        )
        saveCustomPlaylists(current)
        return current
    }

    fun deleteCustomPlaylist(playlistId: String): List<GoatPlaylist> {
        val current = getCustomPlaylists().filterNot { it.id == playlistId }
        saveCustomPlaylists(current)
        return current
    }

    fun toggleTrackInCustomPlaylist(playlistId: String, track: GoatTrack) {
        upsertTrack(track)
        val current = getCustomPlaylists().toMutableList()
        val idx = current.indexOfFirst { it.id == playlistId }
        if (idx >= 0) {
            val pl = current[idx]
            val newIds = if (pl.trackIds.contains(track.id)) {
                pl.trackIds - track.id
            } else {
                pl.trackIds + track.id
            }
            current[idx] = pl.copy(trackIds = newIds)
            saveCustomPlaylists(current)
        }
    }

    fun addMultipleTracksToPlaylist(playlistId: String, tracks: List<GoatTrack>) {
        if (tracks.isEmpty()) return
        tracks.forEach { upsertTrack(it) }
        when (playlistId) {
            PLAYLIST_LIKED_ID -> {
                val all = getSavedTracks().toMutableList()
                val addSet = tracks.map { it.id }.toSet()
                for (i in all.indices) {
                    if (addSet.contains(all[i].id)) {
                        all[i] = all[i].copy(isFavorite = true)
                    }
                }
                saveAllTracks(all)
            }
            else -> {
                val current = getCustomPlaylists().toMutableList()
                val idx = current.indexOfFirst { it.id == playlistId }
                if (idx >= 0) {
                    val pl = current[idx]
                    val combined = (pl.trackIds + tracks.map { it.id }).distinct()
                    current[idx] = pl.copy(trackIds = combined)
                    saveCustomPlaylists(current)
                }
            }
        }
    }

    fun reorderPlaylistTracks(playlistId: String, fromIndex: Int, toIndex: Int, currentIds: List<String>) {
        if (fromIndex !in currentIds.indices || toIndex !in currentIds.indices) return
        val mut = currentIds.toMutableList()
        val moved = mut.removeAt(fromIndex)
        mut.add(toIndex, moved)
        when (playlistId) {
            PLAYLIST_LIKED_ID -> saveOrderList("liked_order_json", mut)
            PLAYLIST_DOWNLOADED_ID -> saveOrderList("downloaded_order_json", mut)
            else -> {
                val custom = getCustomPlaylists().toMutableList()
                val idx = custom.indexOfFirst { it.id == playlistId }
                if (idx >= 0) {
                    custom[idx] = custom[idx].copy(trackIds = mut)
                    saveCustomPlaylists(custom)
                }
            }
        }
    }
}
