package com.goatmusic.app.data

import android.content.ContentUris
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

class LibraryRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("goat_music_library_v6", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "LibraryRepository"
        const val PLAYLIST_LIKED_ID = "sys_liked"
        const val PLAYLIST_DOWNLOADED_ID = "sys_downloaded"
        private const val VAULT_FOLDER_NAME = "GoatMusic_Vault"
        private const val VAULT_DB_FILE_NAME = "goat_vault_db_v6.json"

        /**
         * Android 11+ Scoped Storage'da File.exists() true dönse bile FileInputStream EACCES
         * verebilir. Bu fonksiyon dosyanın gerçekten okunabildiğini (%100) doğrular!
         */
        fun isFileActuallyReadable(path: String?): Boolean {
            if (path.isNullOrBlank()) return false
            return try {
                val f = File(path)
                if (!f.exists() || !f.isFile || f.length() <= 10_000L) return false
                FileInputStream(f).use { fis ->
                    val buf = ByteArray(32)
                    fis.read(buf) > 0
                }
            } catch (_: Throwable) {
                false
            }
        }

        /**
         * Dosya adından ("GMV_Başlık - Sanatçı_11HaneliId.m4a") gerçek 11 haneli YouTube ID'sini
         * içinde alt çizgi (_) olsa bile hatasız ayıklar.
         */
        fun extractYoutubeIdFromVaultFileName(fileNameWithoutExt: String): String? {
            val rawBase = fileNameWithoutExt.removePrefix("GMV_").trim()
            if (rawBase.length > 12 && rawBase[rawBase.length - 12] == '_') {
                val candidate = rawBase.takeLast(11)
                if (candidate.all { it.isLetterOrDigit() || it == '_' || it == '-' }) {
                    return candidate
                }
            }
            val afterLast = rawBase.substringAfterLast("_", "")
            if (afterLast.length == 11 && afterLast.all { it.isLetterOrDigit() || it == '_' || it == '-' }) {
                return afterLast
            }
            return null
        }

        fun getIsolatedVaultDirectory(context: Context): File {
            // Önce uygulamanın her zaman %100 okuma/yazma iznine sahip olduğu kendi dizinini veya Music dizinini kontrol et
            val publicMusicDir = runCatching {
                val music = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
                val dir = File(music, "GoatMusic")
                if (!dir.exists()) dir.mkdirs()
                val probe = File(dir, ".write_test")
                FileOutputStream(probe).use { it.write(1) }
                probe.delete()
                dir
            }.getOrNull()

            if (publicMusicDir != null) return publicMusicDir

            val publicDocVault = runCatching {
                val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                val dir = File(docs, VAULT_FOLDER_NAME)
                if (!dir.exists()) dir.mkdirs()
                val probe = File(dir, ".write_test")
                FileOutputStream(probe).use { it.write(1) }
                probe.delete()
                dir
            }.getOrNull()

            if (publicDocVault != null) return publicDocVault

            val appVault = File(context.getExternalFilesDir(null) ?: context.filesDir, VAULT_FOLDER_NAME)
            if (!appVault.exists()) appVault.mkdirs()
            return appVault
        }

        fun getAppPrivateVaultDirectory(context: Context): File {
            val appVault = File(context.getExternalFilesDir(null) ?: context.filesDir, VAULT_FOLDER_NAME)
            if (!appVault.exists()) appVault.mkdirs()
            return appVault
        }
    }

    init {
        deepRestoreAndMergeVaultDatabase()
        repairSavedTrackIdsAndPaths()
        syncIsolatedVaultFiles()
    }

    private fun getAllCandidateVaultDirectories(): List<File> {
        val dirs = mutableListOf<File>()
        runCatching {
            dirs.add(getAppPrivateVaultDirectory(context))
            context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)?.let {
                dirs.add(File(it, "GoatMusic"))
                dirs.add(File(it, VAULT_FOLDER_NAME))
            }
            context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)?.let {
                dirs.add(File(it, VAULT_FOLDER_NAME))
            }
        }
        runCatching {
            val music = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            dirs.add(File(music, "GoatMusic"))
            dirs.add(File(music, VAULT_FOLDER_NAME))
        }
        runCatching {
            val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            dirs.add(File(docs, VAULT_FOLDER_NAME))
            dirs.add(File(docs, "GoatMusic"))
        }
        runCatching {
            val root = Environment.getExternalStorageDirectory()
            dirs.add(File(root, "Documents/$VAULT_FOLDER_NAME"))
            dirs.add(File(root, VAULT_FOLDER_NAME))
            dirs.add(File(root, "Music/$VAULT_FOLDER_NAME"))
            dirs.add(File(root, "Music/GoatMusic"))
            dirs.add(File(root, "Download/$VAULT_FOLDER_NAME"))
            dirs.add(File(root, "Download/GoatMusic"))
        }
        return dirs.distinctBy { it.absolutePath }
    }

    private fun getVaultDbFiles(): List<File> {
        val list = mutableListOf<File>()
        for (dir in getAllCandidateVaultDirectories()) {
            list.add(File(dir, VAULT_DB_FILE_NAME))
            list.add(File(dir, "goat_vault_db_v5.json"))
            list.add(File(dir, "goat_vault_db.json"))
            runCatching {
                if (dir.exists() && dir.isDirectory) {
                    dir.listFiles()?.forEach { f ->
                        if (f.isFile && f.extension.equals("json", ignoreCase = true) && f.length() > 10L) {
                            list.add(f)
                        }
                    }
                }
            }
        }
        return list.distinctBy { it.absolutePath }
    }

    /**
     * Önceki sürümlerde dosya adındaki alt çizgi (_) yüzünden bozulmuş ID'leri veya
     * okunamayan eski dosya yollarını otomatik onarır.
     */
    fun repairSavedTrackIdsAndPaths() {
        try {
            val raw = prefs.getString("saved_tracks_json", "[]") ?: "[]"
            val arr = JSONArray(raw)
            if (arr.length() == 0) return

            // Okunabilir tüm yerel ses/video dosyalarını ID -> File olarak haritala
            val readableById = mutableMapOf<String, File>()
            for (dir in getAllCandidateVaultDirectories()) {
                runCatching {
                    if (dir.exists() && dir.isDirectory) {
                        dir.listFiles()?.forEach { f ->
                            if (isFileActuallyReadable(f.absolutePath)) {
                                val ext = f.extension.lowercase()
                                if (ext == "m4a" || ext == "mp4" || ext == "webm" || ext == "opus") {
                                    val yid = extractYoutubeIdFromVaultFileName(f.nameWithoutExtension)
                                    if (yid != null) {
                                        readableById[yid] = f
                                    }
                                }
                            }
                        }
                    }
                }
            }

            val idRemap = mutableMapOf<String, String>()
            val repairedTracks = mutableListOf<GoatTrack>()
            val seenIds = mutableSetOf<String>()
            var modified = false

            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                var id = o.optString("id").trim()
                if (id.isBlank() || id.startsWith("ms_") || id.startsWith("local_")) continue

                val rawAudioPath = o.optString("localAudioPath")
                val rawVideoPath = o.optString("localVideoPath")

                // Eğer dosya yolundan gerçek 11 haneli ID çıkarılabiliyorsa ve mevcut ID bozulmuşsa onar
                val pathForId = rawAudioPath.ifBlank { rawVideoPath }
                if (pathForId.isNotBlank()) {
                    val fileNameNoExt = File(pathForId).nameWithoutExtension
                    val trueId = extractYoutubeIdFromVaultFileName(fileNameNoExt)
                    if (trueId != null && trueId != id) {
                        idRemap[id] = trueId
                        id = trueId
                        modified = true
                    }
                }

                var validAudio: String? = if (isFileActuallyReadable(rawAudioPath)) rawAudioPath else null
                val validVideo: String? = if (isFileActuallyReadable(rawVideoPath)) rawVideoPath else null

                if (validAudio == null) {
                    val fallbackFile = readableById[id]
                    if (fallbackFile != null && isFileActuallyReadable(fallbackFile.absolutePath)) {
                        validAudio = fallbackFile.absolutePath
                        modified = true
                    } else if (rawAudioPath.isNotBlank()) {
                        modified = true
                    }
                }

                var title = o.optString("title", "Bilinmeyen Şarkı").trim()
                var artist = o.optString("artist", "Goat Music").trim()
                // Başlığın sonunda "_11HaneliId" kalmışsa temizle
                if (title.endsWith("_$id")) {
                    title = title.removeSuffix("_$id").trim()
                    modified = true
                }

                if (seenIds.add(id)) {
                    repairedTracks.add(
                        GoatTrack(
                            id = id,
                            title = title.ifBlank { "Bilinmeyen Şarkı" },
                            artist = artist.ifBlank { "Goat Music" },
                            durationText = o.optString("durationText", ""),
                            durationSec = o.optLong("durationSec", 0L),
                            thumbnailUrl = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
                            localAudioPath = validAudio,
                            localVideoPath = validVideo,
                            isFavorite = o.optBoolean("isFavorite", false),
                            playCount = o.optInt("playCount", 0),
                            lastPlayedAt = o.optLong("lastPlayedAt", 0L),
                            addedAt = o.optLong("addedAt", System.currentTimeMillis())
                        )
                    )
                } else {
                    modified = true
                }
            }

            if (modified) {
                writeTracksToPrefsOnly(repairedTracks)
                if (idRemap.isNotEmpty()) {
                    val custom = getCustomPlaylists().map { pl ->
                        pl.copy(trackIds = pl.trackIds.map { idRemap[it] ?: it }.distinct())
                    }
                    writeCustomPlaylistsToPrefsOnly(custom)
                }
                saveVaultDatabaseToDisk()
            }
        } catch (e: Exception) {
            Log.w(TAG, "repairSavedTrackIdsAndPaths warning: ${e.message}")
        }
    }

    fun deepRestoreAndMergeVaultDatabase() {
        try {
            for (oldPrefName in listOf("goat_music_library_v5", "goat_music_library_v4", "goat_music_prefs")) {
                val oldPrefs = context.getSharedPreferences(oldPrefName, Context.MODE_PRIVATE)
                val oldTracks = oldPrefs.getString("saved_tracks_json", null)
                if (!oldTracks.isNullOrBlank() && oldTracks != "[]") {
                    mergeJsonBackupIntoMemory(
                        tracksArr = runCatching { JSONArray(oldTracks) }.getOrNull(),
                        playlistsArr = runCatching { JSONArray(oldPrefs.getString("custom_playlists_json", "[]")) }.getOrNull(),
                        likedOrderArr = runCatching { JSONArray(oldPrefs.getString("liked_order_json", "[]")) }.getOrNull(),
                        dlOrderArr = runCatching { JSONArray(oldPrefs.getString("downloaded_order_json", "[]")) }.getOrNull()
                    )
                }
            }

            for (dbFile in getVaultDbFiles()) {
                runCatching {
                    if (dbFile.exists() && dbFile.canRead() && dbFile.length() > 10L) {
                        val rawText = dbFile.readText(Charsets.UTF_8).trim()
                        if (rawText.startsWith("{")) {
                            val root = JSONObject(rawText)
                            mergeJsonBackupIntoMemory(
                                tracksArr = root.optJSONArray("tracks"),
                                playlistsArr = root.optJSONArray("playlists"),
                                likedOrderArr = root.optJSONArray("liked_order"),
                                dlOrderArr = root.optJSONArray("downloaded_order")
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "deepRestoreAndMergeVaultDatabase warning: ${e.message}")
        }
    }

    private fun mergeJsonBackupIntoMemory(
        tracksArr: JSONArray?,
        playlistsArr: JSONArray?,
        likedOrderArr: JSONArray?,
        dlOrderArr: JSONArray?
    ) {
        var anyMerged = false

        if (tracksArr != null && tracksArr.length() > 0) {
            val currentMap = getSavedTracks().associateBy { it.id }.toMutableMap()
            for (i in 0 until tracksArr.length()) {
                val o = tracksArr.optJSONObject(i) ?: continue
                var id = o.optString("id").trim()
                if (id.isBlank() || id.startsWith("ms_") || id.startsWith("local_")) continue

                val rawAudio = o.optString("localAudioPath")
                val rawVideo = o.optString("localVideoPath")
                val pathForId = rawAudio.ifBlank { rawVideo }
                if (pathForId.isNotBlank()) {
                    extractYoutubeIdFromVaultFileName(File(pathForId).nameWithoutExtension)?.let { trueId ->
                        id = trueId
                    }
                }

                val diskAudio = rawAudio.takeIf { isFileActuallyReadable(it) }
                val diskVideo = rawVideo.takeIf { isFileActuallyReadable(it) }
                val wasDownloadedBefore = rawAudio.isNotBlank() || rawVideo.isNotBlank()

                val diskTrack = GoatTrack(
                    id = id,
                    title = o.optString("title", "Bilinmeyen Şarkı").removeSuffix("_$id").trim(),
                    artist = o.optString("artist", "Goat Music"),
                    durationText = o.optString("durationText", ""),
                    durationSec = o.optLong("durationSec", 0L),
                    thumbnailUrl = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
                    localAudioPath = diskAudio,
                    localVideoPath = diskVideo,
                    isFavorite = o.optBoolean("isFavorite", false) || wasDownloadedBefore,
                    playCount = o.optInt("playCount", 0),
                    lastPlayedAt = o.optLong("lastPlayedAt", 0L),
                    addedAt = o.optLong("addedAt", System.currentTimeMillis())
                )

                val existing = currentMap[id]
                if (existing == null) {
                    currentMap[id] = diskTrack
                    anyMerged = true
                } else {
                    val merged = existing.copy(
                        title = existing.title.ifBlank { diskTrack.title },
                        artist = if (existing.artist.isBlank() || existing.artist == "Goat Music") diskTrack.artist else existing.artist,
                        durationText = existing.durationText.ifBlank { diskTrack.durationText },
                        durationSec = maxOf(existing.durationSec, diskTrack.durationSec),
                        localAudioPath = existing.localAudioPath ?: diskTrack.localAudioPath,
                        localVideoPath = existing.localVideoPath ?: diskTrack.localVideoPath,
                        isFavorite = existing.isFavorite || o.optBoolean("isFavorite", false),
                        playCount = maxOf(existing.playCount, diskTrack.playCount),
                        lastPlayedAt = maxOf(existing.lastPlayedAt, diskTrack.lastPlayedAt),
                        addedAt = minOf(existing.addedAt, diskTrack.addedAt)
                    )
                    if (merged != existing) {
                        currentMap[id] = merged
                        anyMerged = true
                    }
                }
            }
            if (anyMerged) {
                writeTracksToPrefsOnly(currentMap.values.sortedByDescending { it.addedAt })
            }
        }

        if (playlistsArr != null && playlistsArr.length() > 0) {
            val currentPlaylists = getCustomPlaylists().toMutableList()
            var plChanged = false
            val deletedIds = getOrderList("deleted_playlist_ids_json").toSet()
            for (i in 0 until playlistsArr.length()) {
                val o = playlistsArr.optJSONObject(i) ?: continue
                val plId = o.optString("id")
                val plName = o.optString("name").trim()
                if (plName.isBlank()) continue
                if (deletedIds.contains(plId) || deletedIds.contains(plName.lowercase())) continue
                val tArr = o.optJSONArray("trackIds") ?: JSONArray()
                val diskIds = mutableListOf<String>()
                for (j in 0 until tArr.length()) {
                    val tid = tArr.optString(j)
                    if (tid.isNotBlank()) diskIds.add(tid)
                }

                val existingIdx = currentPlaylists.indexOfFirst {
                    it.id == plId || it.name.equals(plName, ignoreCase = true)
                }
                if (existingIdx < 0) {
                    currentPlaylists.add(
                        GoatPlaylist(
                            id = plId.ifBlank { "pl_" + UUID.randomUUID().toString().take(8) },
                            name = plName,
                            trackIds = diskIds.distinct(),
                            isSystemPlaylist = false,
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                    plChanged = true
                } else {
                    val ex = currentPlaylists[existingIdx]
                    val combinedIds = (ex.trackIds + diskIds).distinct()
                    if (combinedIds != ex.trackIds) {
                        currentPlaylists[existingIdx] = ex.copy(trackIds = combinedIds)
                        plChanged = true
                    }
                }
            }
            if (plChanged) {
                writeCustomPlaylistsToPrefsOnly(currentPlaylists)
            }
        }

        if (likedOrderArr != null && likedOrderArr.length() > 0) {
            val curOrder = getOrderList("liked_order_json")
            val diskOrder = (0 until likedOrderArr.length()).mapNotNull { likedOrderArr.optString(it).takeIf { s -> s.isNotBlank() } }
            val mergedOrder = (curOrder + diskOrder).distinct()
            if (mergedOrder != curOrder) {
                val arr = JSONArray()
                mergedOrder.forEach { arr.put(it) }
                prefs.edit().putString("liked_order_json", arr.toString()).apply()
            }
        }

        if (dlOrderArr != null && dlOrderArr.length() > 0) {
            val curOrder = getOrderList("downloaded_order_json")
            val diskOrder = (0 until dlOrderArr.length()).mapNotNull { dlOrderArr.optString(it).takeIf { s -> s.isNotBlank() } }
            val mergedOrder = (curOrder + diskOrder).distinct()
            if (mergedOrder != curOrder) {
                val arr = JSONArray()
                mergedOrder.forEach { arr.put(it) }
                prefs.edit().putString("downloaded_order_json", arr.toString()).apply()
            }
        }
    }

    private fun saveVaultDatabaseToDisk() {
        try {
            val tracksJson = JSONArray(prefs.getString("saved_tracks_json", "[]") ?: "[]")
            val playlistsJson = JSONArray(prefs.getString("custom_playlists_json", "[]") ?: "[]")
            if (tracksJson.length() == 0 && playlistsJson.length() == 0) return

            val root = JSONObject().apply {
                put("tracks", tracksJson)
                put("playlists", playlistsJson)
                put("liked_order", JSONArray(prefs.getString("liked_order_json", "[]") ?: "[]"))
                put("downloaded_order", JSONArray(prefs.getString("downloaded_order_json", "[]") ?: "[]"))
                put("updatedAt", System.currentTimeMillis())
            }
            val bytes = root.toString().toByteArray(Charsets.UTF_8)

            val primaryDirs = listOfNotNull(
                runCatching { getAppPrivateVaultDirectory(context) }.getOrNull(),
                runCatching {
                    File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "GoatMusic")
                }.getOrNull(),
                runCatching {
                    File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), VAULT_FOLDER_NAME)
                }.getOrNull()
            )

            for (dir in primaryDirs) {
                runCatching {
                    if (!dir.exists()) dir.mkdirs()
                    val dbFile = File(dir, VAULT_DB_FILE_NAME)
                    FileOutputStream(dbFile, false).use { it.write(bytes) }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "saveVaultDatabaseToDisk note: ${e.message}")
        }
    }

    fun syncIsolatedVaultFiles() {
        try {
            val current = getSavedTracks().toMutableList()
            var changed = false
            val privateVault = getAppPrivateVaultDirectory(context)

            val discoveredFiles = mutableMapOf<String, File>()

            // 1. Doğrudan okunabilir dosya sistemi taraması
            for (dir in getAllCandidateVaultDirectories()) {
                runCatching {
                    if (dir.exists() && dir.isDirectory) {
                        dir.listFiles()?.forEach { f ->
                            if (f.isFile && f.length() > 15_000L && isFileActuallyReadable(f.absolutePath)) {
                                val ext = f.extension.lowercase()
                                if (ext == "m4a" || ext == "mp4" || ext == "webm" || ext == "opus") {
                                    discoveredFiles[f.absolutePath] = f
                                }
                            }
                        }
                    }
                }
            }

            // 2. Android MediaStore taraması (Eğer doğrudan FileInputStream izni yoksa ContentResolver ile uygulama kasasına kopyalar)
            runCatching {
                val uri = MediaStore.Files.getContentUri("external")
                val projection = arrayOf(
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.DATA,
                    MediaStore.Files.FileColumns.DISPLAY_NAME,
                    MediaStore.Files.FileColumns.SIZE
                )
                val selection = "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ? OR ${MediaStore.Files.FileColumns.DATA} LIKE ?"
                val selectionArgs = arrayOf("GMV_%", "%GoatMusic%")
                context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                    val idCol = cursor.getColumnIndex(MediaStore.Files.FileColumns._ID)
                    val dataCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)
                    val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                    while (cursor.moveToNext()) {
                        val path = if (dataCol >= 0) cursor.getString(dataCol) else null
                        val dispName = if (nameCol >= 0) cursor.getString(nameCol) else null
                        val mediaId = if (idCol >= 0) cursor.getLong(idCol) else -1L

                        if (!path.isNullOrBlank() && isFileActuallyReadable(path)) {
                            discoveredFiles[path] = File(path)
                        } else if (mediaId > 0L && !dispName.isNullOrBlank() && dispName.startsWith("GMV_")) {
                            val targetCopy = File(privateVault, dispName)
                            if (!isFileActuallyReadable(targetCopy.absolutePath)) {
                                runCatching {
                                    val contentUri = ContentUris.withAppendedId(uri, mediaId)
                                    context.contentResolver.openInputStream(contentUri)?.use { input ->
                                        FileOutputStream(targetCopy).use { output ->
                                            input.copyTo(output)
                                        }
                                    }
                                }
                            }
                            if (isFileActuallyReadable(targetCopy.absolutePath)) {
                                discoveredFiles[targetCopy.absolutePath] = targetCopy
                            }
                        }
                    }
                }
            }

            for (f in discoveredFiles.values) {
                val ext = f.extension.lowercase()
                if (ext != "m4a" && ext != "mp4" && ext != "webm" && ext != "opus") continue
                val extractedId = extractYoutubeIdFromVaultFileName(f.nameWithoutExtension) ?: continue
                val rawBase = f.nameWithoutExtension.removePrefix("GMV_").trim()
                val cleanName = if (rawBase.endsWith("_$extractedId")) {
                    rawBase.removeSuffix("_$extractedId").trim()
                } else {
                    rawBase
                }
                val title = cleanName.substringBeforeLast(" - ", cleanName).trim().ifBlank { cleanName }
                val artist = cleanName.substringAfterLast(" - ", "Goat Music").trim().ifBlank { "Goat Music" }

                val existingIdx = current.indexOfFirst { it.id == extractedId }
                if (existingIdx >= 0) {
                    val ex = current[existingIdx]
                    val updated = if (ext != "mp4" && !isFileActuallyReadable(ex.localAudioPath)) {
                        ex.copy(
                            localAudioPath = f.absolutePath,
                            title = ex.title.ifBlank { title },
                            artist = if (ex.artist.isBlank() || ex.artist == "Goat Music") artist else ex.artist
                        )
                    } else if (ext == "mp4" && !isFileActuallyReadable(ex.localVideoPath)) {
                        ex.copy(
                            localVideoPath = f.absolutePath,
                            title = ex.title.ifBlank { title },
                            artist = if (ex.artist.isBlank() || ex.artist == "Goat Music") artist else ex.artist
                        )
                    } else ex
                    if (updated != ex) {
                        current[existingIdx] = updated
                        changed = true
                    }
                } else {
                    current.add(
                        GoatTrack(
                            id = extractedId,
                            title = title,
                            artist = artist,
                            durationText = "",
                            durationSec = 0L,
                            thumbnailUrl = "https://i.ytimg.com/vi/$extractedId/hqdefault.jpg",
                            localAudioPath = if (ext != "mp4") f.absolutePath else null,
                            localVideoPath = if (ext == "mp4") f.absolutePath else null,
                            addedAt = f.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis()
                        )
                    )
                    changed = true
                }
            }

            if (changed) {
                saveAllTracks(current)
            }
        } catch (e: Exception) {
            Log.w(TAG, "syncIsolatedVaultFiles note: ${e.message}")
        }
    }

    fun getSavedTracks(): List<GoatTrack> {
        val raw = prefs.getString("saved_tracks_json", "[]") ?: "[]"
        val list = mutableListOf<GoatTrack>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                var id = o.optString("id").trim()
                if (id.isBlank() || id.startsWith("ms_") || id.startsWith("local_")) continue
                val rawAudio = o.optString("localAudioPath")
                val rawVideo = o.optString("localVideoPath")
                val pathForId = rawAudio.ifBlank { rawVideo }
                if (pathForId.isNotBlank()) {
                    extractYoutubeIdFromVaultFileName(File(pathForId).nameWithoutExtension)?.let { trueId ->
                        id = trueId
                    }
                }
                val audioPath = rawAudio.takeIf { isFileActuallyReadable(it) }
                val videoPath = rawVideo.takeIf { isFileActuallyReadable(it) }
                list.add(
                    GoatTrack(
                        id = id,
                        title = o.optString("title").removeSuffix("_$id").trim(),
                        artist = o.optString("artist"),
                        durationText = o.optString("durationText"),
                        durationSec = o.optLong("durationSec", 0L),
                        thumbnailUrl = o.optString("thumbnailUrl").ifBlank { "https://i.ytimg.com/vi/$id/hqdefault.jpg" },
                        localAudioPath = audioPath,
                        localVideoPath = videoPath,
                        isFavorite = o.optBoolean("isFavorite", false),
                        playCount = o.optInt("playCount", 0),
                        lastPlayedAt = o.optLong("lastPlayedAt", 0L),
                        addedAt = o.optLong("addedAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun replaceCorruptedTrackId(oldId: String, newTrack: GoatTrack) {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == oldId }
        if (idx >= 0) {
            val old = current[idx]
            current[idx] = old.copy(
                id = newTrack.id,
                durationSec = if (old.durationSec > 0L) old.durationSec else newTrack.durationSec,
                durationText = old.durationText.ifBlank { newTrack.durationText },
                thumbnailUrl = "https://i.ytimg.com/vi/${newTrack.id}/hqdefault.jpg"
            )
            saveAllTracks(current)
        }
        val custom = getCustomPlaylists().map { pl ->
            if (pl.trackIds.contains(oldId)) {
                pl.copy(trackIds = pl.trackIds.map { if (it == oldId) newTrack.id else it }.distinct())
            } else pl
        }
        saveCustomPlaylists(custom)
    }

    fun recordTrackPlayed(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val now = System.currentTimeMillis()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(
                playCount = existing.playCount + 1,
                lastPlayedAt = now,
                durationSec = if (track.durationSec > 0L) track.durationSec else existing.durationSec,
                durationText = track.durationText.ifBlank { existing.durationText },
                localAudioPath = track.localAudioPath ?: existing.localAudioPath,
                localVideoPath = track.localVideoPath ?: existing.localVideoPath
            )
        } else {
            current.add(0, track.copy(playCount = 1, lastPlayedAt = now))
        }
        saveAllTracks(current)
        return current
    }

    fun upsertTrack(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(
                title = track.title,
                artist = track.artist,
                durationSec = if (track.durationSec > 0L) track.durationSec else existing.durationSec,
                durationText = track.durationText.ifBlank { existing.durationText },
                localAudioPath = track.localAudioPath ?: existing.localAudioPath,
                localVideoPath = track.localVideoPath ?: existing.localVideoPath,
                isFavorite = track.isFavorite || existing.isFavorite
            )
        } else {
            current.add(0, track)
        }
        saveAllTracks(current)
        return current
    }

    fun toggleFavorite(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(isFavorite = !existing.isFavorite)
        } else {
            current.add(0, track.copy(isFavorite = true))
        }
        saveAllTracks(current)
        return current
    }

    fun deleteDownloadedFiles(trackId: String): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == trackId }
        if (idx >= 0) {
            val target = current[idx]
            target.localAudioPath?.let { runCatching { File(it).delete() } }
            target.localVideoPath?.let { runCatching { File(it).delete() } }
            current[idx] = target.copy(localAudioPath = null, localVideoPath = null)
        }
        saveAllTracks(current)
        return current
    }

    private fun writeTracksToPrefsOnly(tracks: List<GoatTrack>) {
        val arr = JSONArray()
        tracks.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("artist", t.artist)
                put("durationText", t.durationText)
                put("durationSec", t.durationSec)
                put("thumbnailUrl", t.thumbnailUrl)
                put("localAudioPath", t.localAudioPath.orEmpty())
                put("localVideoPath", t.localVideoPath.orEmpty())
                put("isFavorite", t.isFavorite)
                put("playCount", t.playCount)
                put("lastPlayedAt", t.lastPlayedAt)
                put("addedAt", t.addedAt)
            })
        }
        prefs.edit().putString("saved_tracks_json", arr.toString()).apply()
    }

    private fun saveAllTracks(tracks: List<GoatTrack>) {
        writeTracksToPrefsOnly(tracks)
        saveVaultDatabaseToDisk()
    }

    private fun getOrderList(prefKey: String): List<String> {
        val raw = prefs.getString(prefKey, "[]") ?: "[]"
        val res = mutableListOf<String>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val id = arr.optString(i)
                if (id.isNotBlank()) res.add(id)
            }
        }
        return res
    }

    private fun saveOrderList(prefKey: String, ids: List<String>) {
        val arr = JSONArray()
        ids.forEach { arr.put(it) }
        prefs.edit().putString(prefKey, arr.toString()).apply()
        saveVaultDatabaseToDisk()
    }

    fun getAllPlaylistsWithSystem(tracks: List<GoatTrack>): List<GoatPlaylist> {
        val likedTracks = tracks.filter { it.isFavorite }
        val likedOrder = getOrderList("liked_order_json")
        val orderedLikedIds = (likedOrder.filter { id -> likedTracks.any { it.id == id } } +
            likedTracks.map { it.id }.filterNot { likedOrder.contains(it) }).distinct()

        val downloadedTracks = tracks.filter { it.isDownloadedAny }
        val dlOrder = getOrderList("downloaded_order_json")
        val orderedDlIds = (dlOrder.filter { id -> downloadedTracks.any { it.id == id } } +
            downloadedTracks.map { it.id }.filterNot { dlOrder.contains(it) }).distinct()

        val systemPlaylists = listOf(
            GoatPlaylist(
                id = PLAYLIST_LIKED_ID,
                name = "Beğenilen Şarkılar",
                trackIds = orderedLikedIds,
                isSystemPlaylist = true
            ),
            GoatPlaylist(
                id = PLAYLIST_DOWNLOADED_ID,
                name = "İndirilen Şarkılar",
                trackIds = orderedDlIds,
                isSystemPlaylist = true
            )
        )
        return systemPlaylists + getCustomPlaylists()
    }

    private fun getCustomPlaylists(): List<GoatPlaylist> {
        val raw = prefs.getString("custom_playlists_json", "[]") ?: "[]"
        val list = mutableListOf<GoatPlaylist>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val tArr = o.optJSONArray("trackIds") ?: JSONArray()
                val ids = mutableListOf<String>()
                for (j in 0 until tArr.length()) {
                    val tid = tArr.optString(j)
                    if (tid.isNotBlank()) ids.add(tid)
                }
                list.add(
                    GoatPlaylist(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        trackIds = ids,
                        isSystemPlaylist = false,
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        }
        return list
    }

    private fun writeCustomPlaylistsToPrefsOnly(playlists: List<GoatPlaylist>) {
        val arr = JSONArray()
        playlists.filterNot { it.isSystemPlaylist }.forEach { pl ->
            arr.put(JSONObject().apply {
                put("id", pl.id)
                put("name", pl.name)
                val tArr = JSONArray()
                pl.trackIds.forEach { tArr.put(it) }
                put("trackIds", tArr)
                put("createdAt", pl.createdAt)
            })
        }
        prefs.edit().putString("custom_playlists_json", arr.toString()).apply()
    }

    private fun saveCustomPlaylists(playlists: List<GoatPlaylist>) {
        writeCustomPlaylistsToPrefsOnly(playlists)
        saveVaultDatabaseToDisk()
    }

    fun createCustomPlaylist(name: String): List<GoatPlaylist> {
        val cleanNameLower = name.trim().lowercase()
        val deletedList = getOrderList("deleted_playlist_ids_json").filterNot { it == cleanNameLower }
        val dArr = JSONArray()
        deletedList.forEach { dArr.put(it) }
        prefs.edit().putString("deleted_playlist_ids_json", dArr.toString()).apply()

        val current = getCustomPlaylists().toMutableList()
        current.add(
            GoatPlaylist(
                id = "pl_" + UUID.randomUUID().toString().take(8),
                name = name.trim(),
                trackIds = emptyList(),
                isSystemPlaylist = false
            )
        )
        saveCustomPlaylists(current)
        return current
    }

    fun renameCustomPlaylist(playlistId: String, newName: String): List<GoatPlaylist> {
        val trimmed = newName.trim()
        if (trimmed.isBlank()) return getCustomPlaylists()
        val current = getCustomPlaylists().toMutableList()
        val idx = current.indexOfFirst { it.id == playlistId }
        if (idx >= 0) {
            val oldNameLower = current[idx].name.trim().lowercase()
            val deletedList = getOrderList("deleted_playlist_ids_json").toMutableList()
            deletedList.add(oldNameLower)
            deletedList.removeAll { it == trimmed.lowercase() }
            val dArr = JSONArray()
            deletedList.distinct().forEach { dArr.put(it) }
            prefs.edit().putString("deleted_playlist_ids_json", dArr.toString()).apply()

            current[idx] = current[idx].copy(name = trimmed)
            saveCustomPlaylists(current)
        }
        return current
    }

    fun deleteCustomPlaylist(playlistId: String): List<GoatPlaylist> {
        val allCustom = getCustomPlaylists()
        val target = allCustom.find { it.id == playlistId }
        val deletedList = getOrderList("deleted_playlist_ids_json").toMutableList()
        deletedList.add(playlistId)
        if (target != null) {
            deletedList.add(target.name.trim().lowercase())
        }
        val dArr = JSONArray()
        deletedList.distinct().forEach { dArr.put(it) }
        prefs.edit().putString("deleted_playlist_ids_json", dArr.toString()).apply()

        val current = allCustom.filterNot { it.id == playlistId }
        saveCustomPlaylists(current)
        return current
    }

    fun toggleTrackInCustomPlaylist(playlistId: String, track: GoatTrack) {
        upsertTrack(track)
        val current = getCustomPlaylists().toMutableList()
        val idx = current.indexOfFirst { it.id == playlistId }
        if (idx >= 0) {
            val pl = current[idx]
            val newIds = if (pl.trackIds.contains(track.id)) {
                pl.trackIds - track.id
            } else {
                pl.trackIds + track.id
            }
            current[idx] = pl.copy(trackIds = newIds)
            saveCustomPlaylists(current)
        }
    }

    fun addMultipleTracksToPlaylist(playlistId: String, tracks: List<GoatTrack>) {
        if (tracks.isEmpty()) return
        tracks.forEach { upsertTrack(it) }
        when (playlistId) {
            PLAYLIST_LIKED_ID -> {
                val all = getSavedTracks().toMutableList()
                val addSet = tracks.map { it.id }.toSet()
                for (i in all.indices) {
                    if (addSet.contains(all[i].id)) {
                        all[i] = all[i].copy(isFavorite = true)
                    }
                }
                saveAllTracks(all)
            }
            else -> {
                val current = getCustomPlaylists().toMutableList()
                val idx = current.indexOfFirst { it.id == playlistId }
                if (idx >= 0) {
                    val pl = current[idx]
                    val combined = (pl.trackIds + tracks.map { it.id }).distinct()
                    current[idx] = pl.copy(trackIds = combined)
                    saveCustomPlaylists(current)
                }
            }
        }
    }

    fun reorderPlaylistTracks(playlistId: String, fromIndex: Int, toIndex: Int, currentIds: List<String>) {
        if (fromIndex !in currentIds.indices || toIndex !in currentIds.indices) return
        val mut = currentIds.toMutableList()
        val moved = mut.removeAt(fromIndex)
        mut.add(toIndex, moved)
        when (playlistId) {
            PLAYLIST_LIKED_ID -> saveOrderList("liked_order_json", mut)
            PLAYLIST_DOWNLOADED_ID -> saveOrderList("downloaded_order_json", mut)
            else -> {
                val custom = getCustomPlaylists().toMutableList()
                val idx = custom.indexOfFirst { it.id == playlistId }
                if (idx >= 0) {
                    custom[idx] = custom[idx].copy(trackIds = mut)
                    saveCustomPlaylists(custom)
                }
            }
        }
    }
}
