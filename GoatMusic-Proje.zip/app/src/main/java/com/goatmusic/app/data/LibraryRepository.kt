package com.goatmusic.app.data

import android.content.ContentUris
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * LibraryRepository v5.0:
 * 1) Uygulama silinip yuklense bile telefonun genel Music/GoatMusic ve Download/GoatMusic
 *    klasorlerindeki yedek dosyasindan (goat_library_backup_v5.json) ve Android MediaStore
 *    uzerinden tum indirmeleri, begenileri ve playlistleri otomatik geri yukler.
 * 2) Begenilen Sarkilar, Indirilen Sarkilar ve Ozel Playlistlerde basili tutup surukleyerek
 *    sarki sirasini degistirmeyi (reorder) destekler.
 */
class LibraryRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("goat_music_library_v5", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "LibraryRepository"
        const val PLAYLIST_LIKED_ID = "sys_liked"
        const val PLAYLIST_DOWNLOADED_ID = "sys_downloaded"
        private const val BACKUP_FILE_NAME = "goat_library_backup_v5.json"
    }

    init {
        restoreFromDeviceBackupIfNeeded()
        recoverDownloadedFilesFromMediaStore()
    }

    private fun getPublicBackupFiles(): List<File> {
        val list = mutableListOf<File>()
        runCatching {
            val musicDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
                "GoatMusic"
            )
            list.add(File(musicDir, BACKUP_FILE_NAME))
        }
        runCatching {
            val dlDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "GoatMusic"
            )
            list.add(File(dlDir, BACKUP_FILE_NAME))
        }
        runCatching {
            val docDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                "GoatMusic"
            )
            list.add(File(docDir, BACKUP_FILE_NAME))
        }
        return list
    }

    private fun persistBackupToPublicStorage() {
        try {
            val root = JSONObject().apply {
                put("tracks", JSONArray(prefs.getString("saved_tracks_json", "[]") ?: "[]"))
                put("playlists", JSONArray(prefs.getString("custom_playlists_json", "[]") ?: "[]"))
                put("liked_order", JSONArray(prefs.getString("liked_order_json", "[]") ?: "[]"))
                put("downloaded_order", JSONArray(prefs.getString("downloaded_order_json", "[]") ?: "[]"))
                put("updatedAt", System.currentTimeMillis())
            }
            val bytes = root.toString().toByteArray(Charsets.UTF_8)
            for (file in getPublicBackupFiles()) {
                runCatching {
                    file.parentFile?.mkdirs()
                    FileOutputStream(file, false).use { it.write(bytes) }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "persistBackupToPublicStorage note: ${e.message}")
        }
    }

    private fun restoreFromDeviceBackupIfNeeded() {
        // Eger yeni kurulum yapildiysa ve SharedPreferences bossa cihazdaki yedekten geri yukle
        val currentTracksRaw = prefs.getString("saved_tracks_json", null)
        if (!currentTracksRaw.isNullOrBlank() && currentTracksRaw != "[]") return

        // Once v4 SharedPreferences varsa oradan tasi
        val v4Prefs = context.getSharedPreferences("goat_music_library_v4", Context.MODE_PRIVATE)
        val v4Tracks = v4Prefs.getString("saved_tracks_json", null)
        if (!v4Tracks.isNullOrBlank() && v4Tracks != "[]") {
            prefs.edit()
                .putString("saved_tracks_json", v4Tracks)
                .putString("custom_playlists_json", v4Prefs.getString("custom_playlists_json", "[]"))
                .apply()
            persistBackupToPublicStorage()
            return
        }

        // Cihaz genel hafizasindaki yedek dosyasini kontrol et
        for (file in getPublicBackupFiles()) {
            try {
                if (file.exists() && file.length() > 10L) {
                    val root = JSONObject(file.readText(Charsets.UTF_8))
                    val tracksArr = root.optJSONArray("tracks")
                    val playlistsArr = root.optJSONArray("playlists")
                    val likedOrderArr = root.optJSONArray("liked_order")
                    val dlOrderArr = root.optJSONArray("downloaded_order")
                    val editor = prefs.edit()
                    if (tracksArr != null) editor.putString("saved_tracks_json", tracksArr.toString())
                    if (playlistsArr != null) editor.putString("custom_playlists_json", playlistsArr.toString())
                    if (likedOrderArr != null) editor.putString("liked_order_json", likedOrderArr.toString())
                    if (dlOrderArr != null) editor.putString("downloaded_order_json", dlOrderArr.toString())
                    editor.apply()
                    return
                }
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Telefonun Music/GoatMusic ve Movies/GoatMusic klasorlerindeki daha onceden indirilmis
     * M4A ve MP4 dosyalarini tarayarak uygulama silinip yuklense bile otomatik geri baglar.
     */
    fun recoverDownloadedFilesFromMediaStore() {
        try {
            val current = getSavedTracks().toMutableList()
            var changed = false

            // 1. Uygulama ici klasoru tara
            val appMusicDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "GoatMusic")
            val appMoviesDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "GoatMusic")
            val pubMusicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "GoatMusic")
            val pubMoviesDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "GoatMusic")

            val allFiles = mutableListOf<File>()
            listOf(appMusicDir, appMoviesDir, pubMusicDir, pubMoviesDir).forEach { dir ->
                runCatching {
                    if (dir.exists() && dir.isDirectory) {
                        dir.listFiles()?.let { allFiles.addAll(it) }
                    }
                }
            }

            for (f in allFiles) {
                if (!f.isFile || f.length() < 15_000L) continue
                val nameNoExt = f.nameWithoutExtension
                val ext = f.extension.lowercase()
                if (ext != "m4a" && ext != "mp4") continue

                val extractedId = nameNoExt.substringAfterLast("_", "").takeIf { it.length == 11 }
                val cleanName = if (extractedId != null) nameNoExt.substringBeforeLast("_") else nameNoExt
                val title = cleanName.substringBefore(" - ").trim().ifBlank { cleanName }
                val artist = cleanName.substringAfter(" - ", "Goat Music").trim()
                val trackId = extractedId ?: ("local_" + cleanName.hashCode().toUInt().toString(16))

                val existingIdx = current.indexOfFirst {
                    it.id == trackId || it.title.equals(title, ignoreCase = true)
                }

                if (existingIdx >= 0) {
                    val ex = current[existingIdx]
                    val updated = if (ext == "m4a" && ex.localAudioPath.isNullOrBlank()) {
                        ex.copy(localAudioPath = f.absolutePath)
                    } else if (ext == "mp4" && ex.localVideoPath.isNullOrBlank()) {
                        ex.copy(localVideoPath = f.absolutePath)
                    } else ex
                    if (updated != ex) {
                        current[existingIdx] = updated
                        changed = true
                    }
                } else {
                    val thumb = if (extractedId != null) {
                        "https://i.ytimg.com/vi/$extractedId/hqdefault.jpg"
                    } else ""
                    current.add(
                        GoatTrack(
                            id = trackId,
                            title = title,
                            artist = artist,
                            durationText = "İndirildi",
                            durationSec = 0L,
                            thumbnailUrl = thumb,
                            localAudioPath = if (ext == "m4a") f.absolutePath else null,
                            localVideoPath = if (ext == "mp4") f.absolutePath else null
                        )
                    )
                    changed = true
                }
            }

            // 2. Android MediaStore uzerinden Music/GoatMusic icindeki ses dosyalarini tara
            runCatching {
                val projection = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.DURATION
                )
                context.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    null,
                    null,
                    null
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                    val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    while (cursor.moveToNext()) {
                        val displayName = cursor.getString(nameCol).orEmpty()
                        if (!displayName.endsWith(".m4a", ignoreCase = true)) continue
                        val mediaId = cursor.getLong(idCol)
                        val durMs = cursor.getLong(durCol)
                        val base = displayName.substringBeforeLast(".")
                        val extractedId = base.substringAfterLast("_", "").takeIf { it.length == 11 }
                        val cleanName = if (extractedId != null) base.substringBeforeLast("_") else base
                        if (!cleanName.contains(" - ") && extractedId == null) continue

                        val title = cleanName.substringBefore(" - ").trim()
                        val artist = cleanName.substringAfter(" - ", "Goat Music").trim()
                        val trackId = extractedId ?: ("ms_" + mediaId)

                        val existingIdx = current.indexOfFirst {
                            it.id == trackId || it.title.equals(title, ignoreCase = true)
                        }
                        if (existingIdx < 0) {
                            // Copy from MediaStore Uri into app offline dir so File playback works seamlessly
                            val contentUri = ContentUris.withAppendedId(
                                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                mediaId
                            )
                            val destDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "GoatMusic").apply { mkdirs() }
                            val restoredFile = File(destDir, displayName)
                            if (!restoredFile.exists()) {
                                runCatching {
                                    context.contentResolver.openInputStream(contentUri)?.use { input ->
                                        FileOutputStream(restoredFile).use { output ->
                                            input.copyTo(output)
                                        }
                                    }
                                }
                            }
                            if (restoredFile.exists() && restoredFile.length() > 10_000L) {
                                val dSec = (durMs / 1000L).coerceAtLeast(0L)
                                val dText = if (dSec > 0) "%d:%02d".format(dSec / 60, dSec % 60) else "İndirildi"
                                current.add(
                                    GoatTrack(
                                        id = trackId,
                                        title = title,
                                        artist = artist,
                                        durationText = dText,
                                        durationSec = dSec,
                                        thumbnailUrl = if (extractedId != null) "https://i.ytimg.com/vi/$extractedId/hqdefault.jpg" else "",
                                        localAudioPath = restoredFile.absolutePath
                                    )
                                )
                                changed = true
                            }
                        }
                    }
                }
            }

            if (changed) {
                saveAllTracks(current)
            }
        } catch (e: Exception) {
            Log.w(TAG, "recoverDownloadedFilesFromMediaStore note: ${e.message}")
        }
    }

    fun getSavedTracks(): List<GoatTrack> {
        val raw = prefs.getString("saved_tracks_json", "[]") ?: "[]"
        val list = mutableListOf<GoatTrack>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val audioPath = o.optString("localAudioPath").takeIf { it.isNotBlank() && File(it).exists() }
                val videoPath = o.optString("localVideoPath").takeIf { it.isNotBlank() && File(it).exists() }
                list.add(
                    GoatTrack(
                        id = o.optString("id"),
                        title = o.optString("title"),
                        artist = o.optString("artist"),
                        durationText = o.optString("durationText"),
                        durationSec = o.optLong("durationSec", 0L),
                        thumbnailUrl = o.optString("thumbnailUrl"),
                        localAudioPath = audioPath,
                        localVideoPath = videoPath,
                        isFavorite = o.optBoolean("isFavorite", false),
                        playCount = o.optInt("playCount", 0),
                        lastPlayedAt = o.optLong("lastPlayedAt", 0L),
                        addedAt = o.optLong("addedAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun recordTrackPlayed(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val now = System.currentTimeMillis()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(
                playCount = existing.playCount + 1,
                lastPlayedAt = now,
                localAudioPath = track.localAudioPath ?: existing.localAudioPath,
                localVideoPath = track.localVideoPath ?: existing.localVideoPath
            )
        } else {
            current.add(0, track.copy(playCount = 1, lastPlayedAt = now))
        }
        saveAllTracks(current)
        return current
    }

    fun upsertTrack(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(
                title = track.title,
                artist = track.artist,
                localAudioPath = track.localAudioPath ?: existing.localAudioPath,
                localVideoPath = track.localVideoPath ?: existing.localVideoPath,
                isFavorite = track.isFavorite || existing.isFavorite
            )
        } else {
            current.add(0, track)
        }
        saveAllTracks(current)
        return current
    }

    fun toggleFavorite(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(isFavorite = !existing.isFavorite)
        } else {
            current.add(0, track.copy(isFavorite = true))
        }
        saveAllTracks(current)
        return current
    }

    fun deleteDownloadedFiles(trackId: String): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == trackId }
        if (idx >= 0) {
            val target = current[idx]
            target.localAudioPath?.let { runCatching { File(it).delete() } }
            target.localVideoPath?.let { runCatching { File(it).delete() } }
            current[idx] = target.copy(localAudioPath = null, localVideoPath = null)
        }
        saveAllTracks(current)
        return current
    }

    private fun saveAllTracks(tracks: List<GoatTrack>) {
        val arr = JSONArray()
        tracks.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("artist", t.artist)
                put("durationText", t.durationText)
                put("durationSec", t.durationSec)
                put("thumbnailUrl", t.thumbnailUrl)
                put("localAudioPath", t.localAudioPath.orEmpty())
                put("localVideoPath", t.localVideoPath.orEmpty())
                put("isFavorite", t.isFavorite)
                put("playCount", t.playCount)
                put("lastPlayedAt", t.lastPlayedAt)
                put("addedAt", t.addedAt)
            })
        }
        prefs.edit().putString("saved_tracks_json", arr.toString()).apply()
        persistBackupToPublicStorage()
    }

    // --- PLAYLIST YONETIMI & SURUKLE-BIRAK SIRALAMA ---

    private fun getOrderList(prefKey: String): List<String> {
        val raw = prefs.getString(prefKey, "[]") ?: "[]"
        val list = mutableListOf<String>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val id = arr.optString(i)
                if (id.isNotBlank()) list.add(id)
            }
        }
        return list
    }

    private fun saveOrderList(prefKey: String, ids: List<String>) {
        val arr = JSONArray()
        ids.forEach { arr.put(it) }
        prefs.edit().putString(prefKey, arr.toString()).apply()
        persistBackupToPublicStorage()
    }

    fun getCustomPlaylists(): List<GoatPlaylist> {
        val raw = prefs.getString("custom_playlists_json", null) ?: return emptyList()
        val list = mutableListOf<GoatPlaylist>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val idsArr = o.optJSONArray("trackIds") ?: JSONArray()
                val ids = mutableListOf<String>()
                for (j in 0 until idsArr.length()) {
                    val tid = idsArr.optString(j)
                    if (tid.isNotBlank()) ids.add(tid)
                }
                list.add(
                    GoatPlaylist(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        trackIds = ids,
                        isSystemPlaylist = false
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun getAllPlaylistsWithSystem(tracks: List<GoatTrack>): List<GoatPlaylist> {
        val rawLikedIds = tracks.filter { it.isFavorite }.map { it.id }
        val savedLikedOrder = getOrderList("liked_order_json").filter { rawLikedIds.contains(it) }
        val finalLikedIds = savedLikedOrder + rawLikedIds.filterNot { savedLikedOrder.contains(it) }

        val rawDownloadedIds = tracks.filter { it.isDownloadedAny }.map { it.id }
        val savedDlOrder = getOrderList("downloaded_order_json").filter { rawDownloadedIds.contains(it) }
        val finalDownloadedIds = savedDlOrder + rawDownloadedIds.filterNot { savedDlOrder.contains(it) }

        val sysLiked = GoatPlaylist(
            id = PLAYLIST_LIKED_ID,
            name = "Beğenilen Şarkılar",
            trackIds = finalLikedIds,
            isSystemPlaylist = true
        )
        val sysDownloaded = GoatPlaylist(
            id = PLAYLIST_DOWNLOADED_ID,
            name = "İndirilen Şarkılar",
            trackIds = finalDownloadedIds,
            isSystemPlaylist = true
        )
        return listOf(sysLiked, sysDownloaded) + getCustomPlaylists()
    }

    fun createCustomPlaylist(name: String): List<GoatPlaylist> {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return getCustomPlaylists()
        val current = getCustomPlaylists().toMutableList()
        current.add(
            GoatPlaylist(
                id = "pl_" + UUID.randomUUID().toString().take(8),
                name = trimmed,
                trackIds = emptyList(),
                isSystemPlaylist = false
            )
        )
        saveCustomPlaylists(current)
        return current
    }

    fun deleteCustomPlaylist(playlistId: String): List<GoatPlaylist> {
        val current = getCustomPlaylists().filterNot { it.id == playlistId }
        saveCustomPlaylists(current)
        return current
    }

    fun toggleTrackInCustomPlaylist(playlistId: String, track: GoatTrack): List<GoatPlaylist> {
        upsertTrack(track)
        val current = getCustomPlaylists().toMutableList()
        val idx = current.indexOfFirst { it.id == playlistId }
        if (idx >= 0) {
            val pl = current[idx]
            val newIds = if (pl.trackIds.contains(track.id)) {
                pl.trackIds - track.id
            } else {
                pl.trackIds + track.id
            }
            current[idx] = pl.copy(trackIds = newIds)
            saveCustomPlaylists(current)
        }
        return current
    }

    fun addMultipleTracksToPlaylist(playlistId: String, tracksToAdd: List<GoatTrack>) {
        tracksToAdd.forEach { upsertTrack(it) }
        when (playlistId) {
            PLAYLIST_LIKED_ID -> {
                val current = getSavedTracks().toMutableList()
                val addIds = tracksToAdd.map { it.id }.toSet()
                for (i in current.indices) {
                    if (addIds.contains(current[i].id)) {
                        current[i] = current[i].copy(isFavorite = true)
                    }
                }
                saveAllTracks(current)
            }
            else -> {
                val current = getCustomPlaylists().toMutableList()
                val idx = current.indexOfFirst { it.id == playlistId }
                if (idx >= 0) {
                    val pl = current[idx]
                    val merged = (pl.trackIds + tracksToAdd.map { it.id }).distinct()
                    current[idx] = pl.copy(trackIds = merged)
                    saveCustomPlaylists(current)
                }
            }
        }
    }

    /**
     * Basili tutup surukleyerek sarki sirasini degistirir ve kalici olarak kaydeder.
     */
    fun reorderPlaylistTracks(playlistId: String, fromIndex: Int, toIndex: Int, currentTrackIds: List<String>) {
        if (fromIndex !in currentTrackIds.indices || toIndex !in currentTrackIds.indices || fromIndex == toIndex) return
        val mutable = currentTrackIds.toMutableList()
        val moved = mutable.removeAt(fromIndex)
        mutable.add(toIndex, moved)

        when (playlistId) {
            PLAYLIST_LIKED_ID -> saveOrderList("liked_order_json", mutable)
            PLAYLIST_DOWNLOADED_ID -> saveOrderList("downloaded_order_json", mutable)
            else -> {
                val custom = getCustomPlaylists().toMutableList()
                val idx = custom.indexOfFirst { it.id == playlistId }
                if (idx >= 0) {
                    custom[idx] = custom[idx].copy(trackIds = mutable)
                    saveCustomPlaylists(custom)
                }
            }
        }
    }

    private fun saveCustomPlaylists(playlists: List<GoatPlaylist>) {
        val arr = JSONArray()
        playlists.forEach { pl ->
            arr.put(JSONObject().apply {
                put("id", pl.id)
                put("name", pl.name)
                val ids = JSONArray()
                pl.trackIds.forEach { ids.put(it) }
                put("trackIds", ids)
            })
        }
        prefs.edit().putString("custom_playlists_json", arr.toString()).apply()
        persistBackupToPublicStorage()
    }
}
