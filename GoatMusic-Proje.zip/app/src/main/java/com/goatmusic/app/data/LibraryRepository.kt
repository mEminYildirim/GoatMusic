package com.goatmusic.app.data

import android.content.Context
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class LibraryRepository(context: Context) {

    private val prefs = context.getSharedPreferences("goat_music_library_v4", Context.MODE_PRIVATE)

    companion object {
        const val PLAYLIST_LIKED_ID = "sys_liked"
        const val PLAYLIST_DOWNLOADED_ID = "sys_downloaded"
    }

    fun getSavedTracks(): List<GoatTrack> {
        val raw = prefs.getString("saved_tracks_json", "[]") ?: "[]"
        val list = mutableListOf<GoatTrack>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val audioPath = o.optString("localAudioPath").takeIf { it.isNotBlank() && File(it).exists() }
                val videoPath = o.optString("localVideoPath").takeIf { it.isNotBlank() && File(it).exists() }
                list.add(
                    GoatTrack(
                        id = o.optString("id"),
                        title = o.optString("title"),
                        artist = o.optString("artist"),
                        durationText = o.optString("durationText"),
                        durationSec = o.optLong("durationSec", 0L),
                        thumbnailUrl = o.optString("thumbnailUrl"),
                        localAudioPath = audioPath,
                        localVideoPath = videoPath,
                        isFavorite = o.optBoolean("isFavorite", false),
                        playCount = o.optInt("playCount", 0),
                        lastPlayedAt = o.optLong("lastPlayedAt", 0L),
                        addedAt = o.optLong("addedAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun recordTrackPlayed(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val now = System.currentTimeMillis()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(
                playCount = existing.playCount + 1,
                lastPlayedAt = now,
                localAudioPath = track.localAudioPath ?: existing.localAudioPath,
                localVideoPath = track.localVideoPath ?: existing.localVideoPath
            )
        } else {
            current.add(0, track.copy(playCount = 1, lastPlayedAt = now))
        }
        saveAllTracks(current)
        return current
    }

    fun upsertTrack(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(
                title = track.title,
                artist = track.artist,
                localAudioPath = track.localAudioPath ?: existing.localAudioPath,
                localVideoPath = track.localVideoPath ?: existing.localVideoPath,
                isFavorite = track.isFavorite || existing.isFavorite
            )
        } else {
            current.add(0, track)
        }
        saveAllTracks(current)
        return current
    }

    /**
     * Begeni durumunu degistirir. Begeni kalktiginda Begenilen Sarkilar playlistinden otomatik kalkar.
     */
    fun toggleFavorite(track: GoatTrack): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == track.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(isFavorite = !existing.isFavorite)
        } else {
            current.add(0, track.copy(isFavorite = true))
        }
        saveAllTracks(current)
        return current
    }

    /**
     * Indirilen dosyayi siler. Silindiginde Indirilen Sarkilar playlistinden otomatik kalkar.
     */
    fun deleteDownloadedFiles(trackId: String): List<GoatTrack> {
        val current = getSavedTracks().toMutableList()
        val idx = current.indexOfFirst { it.id == trackId }
        if (idx >= 0) {
            val target = current[idx]
            target.localAudioPath?.let { runCatching { File(it).delete() } }
            target.localVideoPath?.let { runCatching { File(it).delete() } }
            current[idx] = target.copy(localAudioPath = null, localVideoPath = null)
        }
        saveAllTracks(current)
        return current
    }

    private fun saveAllTracks(tracks: List<GoatTrack>) {
        val arr = JSONArray()
        tracks.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("artist", t.artist)
                put("durationText", t.durationText)
                put("durationSec", t.durationSec)
                put("thumbnailUrl", t.thumbnailUrl)
                put("localAudioPath", t.localAudioPath.orEmpty())
                put("localVideoPath", t.localVideoPath.orEmpty())
                put("isFavorite", t.isFavorite)
                put("playCount", t.playCount)
                put("lastPlayedAt", t.lastPlayedAt)
                put("addedAt", t.addedAt)
            })
        }
        prefs.edit().putString("saved_tracks_json", arr.toString()).apply()
    }

    // --- PLAYLIST YONETIMI (Garanti Begenilenler + Indirilenler + Ozel Playlistler) ---

    fun getCustomPlaylists(): List<GoatPlaylist> {
        val raw = prefs.getString("custom_playlists_json", null)
        if (raw == null) {
            val defaultList = listOf(
                GoatPlaylist(
                    id = "pl_favori_mix",
                    name = "Favori Listem",
                    trackIds = emptyList(),
                    isSystemPlaylist = false
                )
            )
            saveCustomPlaylists(defaultList)
            return defaultList
        }
        val list = mutableListOf<GoatPlaylist>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val idsArr = o.optJSONArray("trackIds") ?: JSONArray()
                val ids = mutableListOf<String>()
                for (j in 0 until idsArr.length()) {
                    val tid = idsArr.optString(j)
                    if (tid.isNotBlank()) ids.add(tid)
                }
                list.add(
                    GoatPlaylist(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        trackIds = ids,
                        isSystemPlaylist = false
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun getAllPlaylistsWithSystem(tracks: List<GoatTrack>): List<GoatPlaylist> {
        val likedIds = tracks.filter { it.isFavorite }.map { it.id }
        val downloadedIds = tracks.filter { it.isDownloadedAny }.map { it.id }

        val sysLiked = GoatPlaylist(
            id = PLAYLIST_LIKED_ID,
            name = "Beğenilen Şarkılar",
            trackIds = likedIds,
            isSystemPlaylist = true
        )
        val sysDownloaded = GoatPlaylist(
            id = PLAYLIST_DOWNLOADED_ID,
            name = "İndirilen Şarkılar",
            trackIds = downloadedIds,
            isSystemPlaylist = true
        )
        return listOf(sysLiked, sysDownloaded) + getCustomPlaylists()
    }

    fun createCustomPlaylist(name: String): List<GoatPlaylist> {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return getCustomPlaylists()
        val current = getCustomPlaylists().toMutableList()
        current.add(
            GoatPlaylist(
                id = "pl_" + UUID.randomUUID().toString().take(8),
                name = trimmed,
                trackIds = emptyList(),
                isSystemPlaylist = false
            )
        )
        saveCustomPlaylists(current)
        return current
    }

    fun deleteCustomPlaylist(playlistId: String): List<GoatPlaylist> {
        val current = getCustomPlaylists().filterNot { it.id == playlistId }
        saveCustomPlaylists(current)
        return current
    }

    /**
     * Tek tusla sarkiyi playliste ekler veya playlistten cikarir.
     */
    fun toggleTrackInCustomPlaylist(playlistId: String, track: GoatTrack): List<GoatPlaylist> {
        upsertTrack(track)
        val current = getCustomPlaylists().toMutableList()
        val idx = current.indexOfFirst { it.id == playlistId }
        if (idx >= 0) {
            val pl = current[idx]
            val newIds = if (pl.trackIds.contains(track.id)) {
                pl.trackIds - track.id
            } else {
                listOf(track.id) + pl.trackIds
            }
            current[idx] = pl.copy(trackIds = newIds)
            saveCustomPlaylists(current)
        }
        return current
    }

    private fun saveCustomPlaylists(playlists: List<GoatPlaylist>) {
        val arr = JSONArray()
        playlists.forEach { pl ->
            arr.put(JSONObject().apply {
                put("id", pl.id)
                put("name", pl.name)
                val ids = JSONArray()
                pl.trackIds.forEach { ids.put(it) }
                put("trackIds", ids)
            })
        }
        prefs.edit().putString("custom_playlists_json", arr.toString()).apply()
    }
}
