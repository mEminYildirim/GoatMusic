@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.goatmusic.app.ui

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.goatmusic.app.R
import com.goatmusic.app.data.LibraryRepository
import com.goatmusic.app.model.DownloadTaskState
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.MediaFormatType
import com.goatmusic.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun GoatMusicApp(vm: GoatViewModel) {
    var showSplash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(2200)
        showSplash = false
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var isFullPlayerOpen by remember { mutableStateOf(false) }
    var showBotShieldDialog by remember { mutableStateOf(false) }
    var playlistSheetTrack by remember { mutableStateOf<GoatTrack?>(null) }

    val searchQuery by vm.searchQuery.collectAsState()
    val isSearching by vm.isSearching.collectAsState()
    val searchResults by vm.searchResults.collectAsState()
    val libraryTracks by vm.libraryTracks.collectAsState()
    val similarTracks by vm.similarTracks.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val currentTrack by vm.currentTrack.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val isBuffering by vm.isBuffering.collectAsState()
    val isVideoMode by vm.isVideoMode.collectAsState()
    val isShuffleEnabled by vm.isShuffleEnabled.collectAsState()
    val positionMs by vm.positionMs.collectAsState()
    val durationMs by vm.durationMs.collectAsState()
    val liveAudioBars by vm.liveAudioBars.collectAsState()
    val downloads by vm.downloads.collectAsState()
    val isBotShieldVerified by vm.isBotShieldVerified.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Scaffold(
            containerColor = ObsidianBlack,
            bottomBar = {
                Column(modifier = Modifier.background(ObsidianBlack)) {
                    if (currentTrack != null) {
                        MiniPlayerBar(
                            track = currentTrack!!,
                            isPlaying = isPlaying,
                            isBuffering = isBuffering,
                            positionMs = positionMs,
                            durationMs = durationMs,
                            onTogglePlay = { vm.togglePlayPause() },
                            onFavorite = { vm.toggleFavorite(currentTrack!!) },
                            onNext = { vm.playNextInQueue() },
                            onOpenFullPlayer = { isFullPlayerOpen = true }
                        )
                    }

                    // Gerçek Spotify Alt Sekme Çubuğu (Şeffaf İndikatörlü, İnce Çizgili)
                    HorizontalDivider(color = SurfaceSteelBlue.copy(alpha = 0.45f), thickness = 0.5.dp)
                    NavigationBar(
                        containerColor = ObsidianBlack,
                        tonalElevation = 0.dp,
                        modifier = Modifier.height(64.dp)
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Ana Sayfa", modifier = Modifier.size(24.dp)) },
                            label = { Text("Ana Sayfa", fontSize = 11.sp, fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PureIceWhite,
                                selectedTextColor = PureIceWhite,
                                unselectedIconColor = SubtleGray,
                                unselectedTextColor = SubtleGray,
                                indicatorColor = Color.Transparent
                            )
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.Search, contentDescription = "Ara", modifier = Modifier.size(24.dp)) },
                            label = { Text("Ara", fontSize = 11.sp, fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PureIceWhite,
                                selectedTextColor = PureIceWhite,
                                unselectedIconColor = SubtleGray,
                                unselectedTextColor = SubtleGray,
                                indicatorColor = Color.Transparent
                            )
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Kitaplığım", modifier = Modifier.size(24.dp)) },
                            label = { Text("Kitaplığım", fontSize = 11.sp, fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PureIceWhite,
                                selectedTextColor = PureIceWhite,
                                unselectedIconColor = SubtleGray,
                                unselectedTextColor = SubtleGray,
                                indicatorColor = Color.Transparent
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    0 -> HomeScreen(
                        isBotShieldVerified = isBotShieldVerified,
                        currentPlayingId = currentTrack?.id,
                        libraryTracks = libraryTracks,
                        similarTracks = similarTracks,
                        downloads = downloads,
                        onOpenBotShield = { showBotShieldDialog = true },
                        onPlayTrack = { track, queue -> vm.playTrack(track, false, queue) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onOpenPlaylistSheet = { playlistSheetTrack = it },
                        onGoToSearch = { selectedTab = 1 }
                    )
                    1 -> SearchAndDownloadScreen(
                        query = searchQuery,
                        isSearching = isSearching,
                        currentPlayingId = currentTrack?.id,
                        results = searchResults,
                        downloads = downloads,
                        onQueryChange = { vm.onSearchQueryChange(it) },
                        onSearchSubmit = { vm.performSearch(searchQuery) },
                        onPlayTrack = { track -> vm.playTrack(track, false, searchResults) },
                        onPlayVideo = { track ->
                            vm.playTrack(track, true, searchResults)
                            isFullPlayerOpen = true
                        },
                        onDownloadTrack = { track, fmt -> vm.downloadTrack(track, fmt) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onOpenPlaylistSheet = { playlistSheetTrack = it }
                    )
                    2 -> PlaylistsScreen(
                        playlists = playlists,
                        allTracks = libraryTracks,
                        currentPlayingId = currentTrack?.id,
                        isShuffleEnabled = isShuffleEnabled,
                        downloads = downloads,
                        onCreatePlaylist = { vm.createPlaylist(it) },
                        onDeletePlaylist = { vm.deleteCustomPlaylist(it) },
                        onPlayTrack = { track, queue -> vm.playTrack(track, false, queue) },
                        onShufflePlay = { queue -> vm.shufflePlayPlaylist(queue) },
                        onPlayInOrder = { queue -> vm.playPlaylistInOrder(queue) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onRemoveFromPlaylist = { plId, track -> vm.toggleTrackInPlaylist(plId, track) },
                        onAddMultipleToPlaylist = { plId, selectedTracks ->
                            vm.addMultipleTracksToPlaylist(plId, selectedTracks)
                        },
                        onReorderTracks = { plId, fromIdx, toIdx, ids ->
                            vm.reorderPlaylistTracks(plId, fromIdx, toIdx, ids)
                        }
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = isFullPlayerOpen && currentTrack != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            if (currentTrack != null) {
                FullScreenPlayerModal(
                    track = currentTrack!!,
                    vm = vm,
                    isPlaying = isPlaying,
                    isBuffering = isBuffering,
                    isVideoMode = isVideoMode,
                    isShuffleEnabled = isShuffleEnabled,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    liveAudioBars = liveAudioBars,
                    onOpenPlaylistSheet = { playlistSheetTrack = currentTrack },
                    onClose = { isFullPlayerOpen = false }
                )
            }
        }

        if (playlistSheetTrack != null) {
            QuickPlaylistDialog(
                track = playlistSheetTrack!!,
                playlists = playlists,
                onTogglePlaylist = { plId ->
                    vm.toggleTrackInPlaylist(plId, playlistSheetTrack!!)
                },
                onCreateNewPlaylist = { name ->
                    vm.createPlaylist(name)
                },
                onDismiss = { playlistSheetTrack = null }
            )
        }

        if (showBotShieldDialog) {
            BotShieldWebViewDialog(
                onDismiss = {
                    CookieManager.getInstance().flush()
                    vm.refreshBotShieldState()
                    showBotShieldDialog = false
                }
            )
        }

        AnimatedVisibility(
            visible = showSplash,
            enter = fadeIn(),
            exit = fadeOut(animationSpec = tween(450))
        ) {
            GoatIntroSplash()
        }
    }
}

@Composable
private fun GoatIntroSplash() {
    val infiniteTransition = rememberInfiniteTransition(label = "splash_wave")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.283f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(850, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logo_pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.goat_logo_upper),
                contentDescription = "Goat Music",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(104.dp)
                    .scale(pulse)
                    .clip(CircleShape)
                    .border(2.dp, NeonSapphire, CircleShape)
            )

            Spacer(modifier = Modifier.height(26.dp))

            Canvas(
                modifier = Modifier
                    .width(160.dp)
                    .height(34.dp)
            ) {
                val barCount = 19
                val spacing = size.width / barCount
                val barWidth = spacing * 0.55f
                for (i in 0 until barCount) {
                    val norm = 0.22f + 0.78f * abs(sin(phase + i * 0.42f))
                    val barH = size.height * norm
                    val topY = (size.height - barH) / 2f
                    drawRoundRect(
                        color = NeonSapphire,
                        topLeft = Offset(i * spacing, topY),
                        size = Size(barWidth, barH),
                        cornerRadius = CornerRadius(6f, 6f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Text(
                text = "Hoşgeldin Agam",
                color = PureIceWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.4.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "created by Mami",
                color = MutedSilver,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.2.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Gercek PCM ses siddetine (GoatAudioLevelSink) bagli olarak yumusakca yukselen ve alcalan
 * stüdyo tipi ses dalgasi cubugu.
 */
@Composable
fun RealAudioLoudnessSeekbar(
    progress: Float,
    liveBars: List<Float>,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val frac = (offset.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                    onSeek(frac)
                }
            }
    ) {
        val barCount = liveBars.size.coerceAtLeast(1)
        val slotWidth = size.width / barCount
        val barWidth = slotWidth * 0.56f
        val centerY = size.height / 2f

        for (i in 0 until barCount) {
            val barFrac = i.toFloat() / barCount.toFloat()
            val isPassed = barFrac <= progress
            val isPlayhead = abs(barFrac - progress) < (1.2f / barCount)

            val level = liveBars[i].coerceIn(0.06f, 0.96f)
            val barHeight = size.height * level

            val barColor = when {
                isPlayhead -> PureIceWhite
                isPassed -> NeonSapphire
                else -> SurfaceSteelBlue
            }

            drawRoundRect(
                color = barColor,
                topLeft = Offset(x = i * slotWidth, y = centerY - barHeight / 2f),
                size = Size(width = barWidth, height = barHeight),
                cornerRadius = CornerRadius(6f, 6f)
            )
        }
    }
}

@Composable
private fun HomeScreen(
    isBotShieldVerified: Boolean,
    currentPlayingId: String?,
    libraryTracks: List<GoatTrack>,
    similarTracks: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onOpenBotShield: () -> Unit,
    onPlayTrack: (GoatTrack, List<GoatTrack>) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onOpenPlaylistSheet: (GoatTrack) -> Unit,
    onGoToSearch: () -> Unit
) {
    val recentlyPlayed = remember(libraryTracks) {
        libraryTracks.filter { it.lastPlayedAt > 0L }.sortedByDescending { it.lastPlayedAt }.take(12)
    }
    val mostPlayed = remember(libraryTracks) {
        libraryTracks.filter { it.playCount > 0 }.sortedByDescending { it.playCount }.take(8)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        // Sade, gerçekçi Spotify tarzı üst başlık
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.goat_logo_upper),
                        contentDescription = "Goat Music",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Goat Music",
                        color = PureIceWhite,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(onClick = onOpenBotShield) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "Bağlantı Kalkanı",
                        tint = if (isBotShieldVerified) EmeraldSuccess else MutedSilver,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        if (recentlyPlayed.isEmpty() && mostPlayed.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = SubtleGray,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Henüz şarkı dinlemedin",
                        color = PureIceWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Dinlediğin şarkılar, en çok çaldıkların ve zevkine uygun öneriler burada listelenir.",
                        color = MutedSilver,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = onGoToSearch,
                        colors = ButtonDefaults.buttonColors(containerColor = PureIceWhite),
                        shape = RoundedCornerShape(24.dp),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp)
                    ) {
                        Text("Şarkı Ara", color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        // 1. Son Dinlenilenler
        if (recentlyPlayed.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 4.dp)) {
                    Text(
                        text = "Son dinlenilenler",
                        color = PureIceWhite,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(recentlyPlayed, key = { "rec_" + it.id }) { track ->
                            Column(
                                modifier = Modifier
                                    .width(128.dp)
                                    .clickable { onPlayTrack(track, recentlyPlayed) }
                            ) {
                                AsyncImage(
                                    model = track.thumbnailUrl,
                                    placeholder = painterResource(id = R.drawable.art_default_cover),
                                    error = painterResource(id = R.drawable.art_default_cover),
                                    contentDescription = track.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(128.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = track.title,
                                    color = if (track.id == currentPlayingId) NeonSapphire else PureIceWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = track.artist,
                                    color = MutedSilver,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. En Çok Dinlediklerin
        if (mostPlayed.isNotEmpty()) {
            item {
                Text(
                    text = "En çok dinlediklerin",
                    color = PureIceWhite,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 26.dp, bottom = 6.dp)
                )
            }
            items(mostPlayed, key = { "most_" + it.id }) { track ->
                CleanSpotifyTrackRow(
                    track = track,
                    isPlayingNow = track.id == currentPlayingId,
                    subtitlePrefix = "${track.playCount} dinleme",
                    activeDownload = downloads[track.id],
                    onRowClick = { onPlayTrack(track, mostPlayed) },
                    onFavoriteClick = { onToggleFavorite(track) },
                    onAddToPlaylistClick = { onOpenPlaylistSheet(track) },
                    onDownloadAudioClick = null,
                    onDownloadVideoClick = null,
                    onRemoveClick = null
                )
            }
        }

        // 3. Benzer Şarkılar
        if (similarTracks.isNotEmpty()) {
            item {
                Text(
                    text = "En çok dinlediklerine benzer",
                    color = PureIceWhite,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 26.dp, bottom = 6.dp)
                )
            }
            items(similarTracks, key = { "sim_" + it.id }) { track ->
                CleanSpotifyTrackRow(
                    track = track,
                    isPlayingNow = track.id == currentPlayingId,
                    subtitlePrefix = null,
                    activeDownload = downloads[track.id],
                    onRowClick = { onPlayTrack(track, similarTracks) },
                    onFavoriteClick = { onToggleFavorite(track) },
                    onAddToPlaylistClick = { onOpenPlaylistSheet(track) },
                    onDownloadAudioClick = null,
                    onDownloadVideoClick = null,
                    onRemoveClick = null
                )
            }
        }
    }
}

@Composable
private fun SearchAndDownloadScreen(
    query: String,
    isSearching: Boolean,
    currentPlayingId: String?,
    results: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onQueryChange: (String) -> Unit,
    onSearchSubmit: () -> Unit,
    onPlayTrack: (GoatTrack) -> Unit,
    onPlayVideo: (GoatTrack) -> Unit,
    onDownloadTrack: (GoatTrack, MediaFormatType) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onOpenPlaylistSheet: (GoatTrack) -> Unit
) {
    val focusManager = LocalFocusManager.current

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Ara",
            color = PureIceWhite,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)
        )

        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = {
                Text("Ne dinlemek istiyorsun?", color = SubtleGray, fontSize = 14.sp)
            },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = MutedSilver)
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Temizle", tint = MutedSilver)
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focusManager.clearFocus()
                onSearchSubmit()
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DeepSlateBlack,
                unfocusedContainerColor = DeepSlateBlack,
                focusedBorderColor = SurfaceSteelBlue,
                unfocusedBorderColor = Color.Transparent,
                focusedTextColor = PureIceWhite,
                unfocusedTextColor = PureIceWhite
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        )

        if (isSearching) {
            LinearProgressIndicator(
                color = NeonSapphire,
                trackColor = Color.Transparent,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .padding(horizontal = 16.dp)
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 6.dp, bottom = 24.dp)
        ) {
            items(results, key = { it.id }) { track ->
                CleanSpotifyTrackRow(
                    track = track,
                    isPlayingNow = track.id == currentPlayingId,
                    subtitlePrefix = track.durationText,
                    activeDownload = downloads[track.id],
                    onRowClick = { onPlayTrack(track) },
                    onFavoriteClick = { onToggleFavorite(track) },
                    onAddToPlaylistClick = { onOpenPlaylistSheet(track) },
                    onDownloadAudioClick = { onDownloadTrack(track, MediaFormatType.AUDIO_M4A) },
                    onDownloadVideoClick = { onDownloadTrack(track, MediaFormatType.VIDEO_MP4) },
                    onPlayVideoClick = { onPlayVideo(track) },
                    onRemoveClick = null
                )
            }
        }
    }
}

@Composable
private fun PlaylistsScreen(
    playlists: List<GoatPlaylist>,
    allTracks: List<GoatTrack>,
    currentPlayingId: String?,
    isShuffleEnabled: Boolean,
    downloads: Map<String, DownloadTaskState>,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onPlayTrack: (GoatTrack, List<GoatTrack>) -> Unit,
    onShufflePlay: (List<GoatTrack>) -> Unit,
    onPlayInOrder: (List<GoatTrack>) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onRemoveFromPlaylist: (String, GoatTrack) -> Unit,
    onAddMultipleToPlaylist: (String, List<GoatTrack>) -> Unit,
    onReorderTracks: (String, Int, Int, List<String>) -> Unit
) {
    var selectedPlaylistId by remember { mutableStateOf(LibraryRepository.PLAYLIST_LIKED_ID) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var showAddSongsPicker by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }

    val activePlaylist = playlists.find { it.id == selectedPlaylistId } ?: playlists.firstOrNull()
    val trackMap = remember(allTracks) { allTracks.associateBy { it.id } }

    // Sürükle-bırak (Drag & Drop) için yerel sıralı liste durumu
    var orderedTrackIds by remember(activePlaylist) {
        mutableStateOf(activePlaylist?.trackIds.orEmpty())
    }
    val activeTracks = remember(orderedTrackIds, trackMap) {
        orderedTrackIds.mapNotNull { trackMap[it] }
    }

    var draggedIndex by remember { mutableStateOf<Int?>(null) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    val rowHeightPx = with(LocalDensity.current) { 64.dp.toPx() }

    Column(modifier = Modifier.fillMaxSize()) {
        // Üst Başlık: Kitaplığım & Yeni Playlist
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 12.dp, top = 16.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Kitaplığım",
                color = PureIceWhite,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { showCreateDialog = true }) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Yeni Playlist Oluştur",
                    tint = PureIceWhite,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        // Spotify tarzı ince filtre/playlist hapları (Pills)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(playlists, key = { it.id }) { pl ->
                val isSelected = pl.id == activePlaylist?.id
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (isSelected) ElectricCobalt else DeepSlateBlack)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) ElectricCobalt else SurfaceSteelBlue,
                            shape = RoundedCornerShape(18.dp)
                        )
                        .clickable { selectedPlaylistId = pl.id }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = pl.name,
                        color = PureIceWhite,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }

        // Aktif Playlist Üst Kontrol Çubuğu (Şarkı Ekle + Rastgele Çal / Shuffle + Oynat)
        if (activePlaylist != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = activePlaylist.name,
                            color = PureIceWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (!activePlaylist.isSystemPlaylist) {
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = {
                                    onDeletePlaylist(activePlaylist.id)
                                    selectedPlaylistId = LibraryRepository.PLAYLIST_LIKED_ID
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Listeyi Sil",
                                    tint = SubtleGray,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = "${activeTracks.size} şarkı • Sıralamak için basılı tutup sürükle",
                        color = SubtleGray,
                        fontSize = 12.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Beğenilen / İndirilen Şarkılardan Seçip Ekle Butonu
                    if (activePlaylist.id != LibraryRepository.PLAYLIST_DOWNLOADED_ID) {
                        OutlinedButton(
                            onClick = { showAddSongsPicker = true },
                            shape = RoundedCornerShape(20.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceSteelBlue),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = PureIceWhite,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Şarkı Ekle", color = PureIceWhite, fontSize = 12.sp)
                        }
                    }

                    // Rastgele Çal (Shuffle) Butonu
                    IconButton(
                        onClick = { onShufflePlay(activeTracks) },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (isShuffleEnabled) CardMidnightBlue else Color.Transparent)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shuffle,
                            contentDescription = "Karışık Çal",
                            tint = if (isShuffleEnabled) NeonSapphire else PureIceWhite,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Sırayla Çal (Play) Butonu
                    IconButton(
                        onClick = { onPlayInOrder(activeTracks) },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(ElectricCobalt)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Oynat",
                            tint = PureIceWhite,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }

        HorizontalDivider(color = SurfaceSteelBlue.copy(alpha = 0.35f), thickness = 0.5.dp)

        if (activeTracks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Bu çalma listesi boş",
                        color = PureIceWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (activePlaylist?.id == LibraryRepository.PLAYLIST_DOWNLOADED_ID) {
                            "Ara sekmesinden indirdiğin şarkılar otomatik olarak burada yer alır."
                        } else {
                            "Üstteki 'Şarkı Ekle' butonuna dokunarak kayıtlı veya beğenilen şarkılarından seçim yapabilirsin."
                        },
                        color = MutedSilver,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 4.dp, bottom = 28.dp)
            ) {
                itemsIndexed(activeTracks, key = { _, item -> item.id }) { index, track ->
                    val isBeingDragged = draggedIndex == index
                    Box(
                        modifier = Modifier
                            .zIndex(if (isBeingDragged) 5f else 0f)
                            .graphicsLayer {
                                translationY = if (isBeingDragged) dragOffsetY else 0f
                                scaleX = if (isBeingDragged) 1.02f else 1f
                                scaleY = if (isBeingDragged) 1.02f else 1f
                            }
                            .background(if (isBeingDragged) CardMidnightBlue else Color.Transparent)
                            .pointerInput(orderedTrackIds.size, activePlaylist?.id) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = {
                                        draggedIndex = index
                                        dragOffsetY = 0f
                                    },
                                    onDragEnd = {
                                        draggedIndex = null
                                        dragOffsetY = 0f
                                    },
                                    onDragCancel = {
                                        draggedIndex = null
                                        dragOffsetY = 0f
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        dragOffsetY += dragAmount.y
                                        val curIdx = draggedIndex ?: return@detectDragGesturesAfterLongPress
                                        if (dragOffsetY > rowHeightPx * 0.7f && curIdx < orderedTrackIds.lastIndex) {
                                            val targetIdx = curIdx + 1
                                            val currentIdsCopy = orderedTrackIds
                                            val mut = currentIdsCopy.toMutableList()
                                            val item = mut.removeAt(curIdx)
                                            mut.add(targetIdx, item)
                                            orderedTrackIds = mut
                                            draggedIndex = targetIdx
                                            dragOffsetY -= rowHeightPx
                                            activePlaylist?.id?.let { plId ->
                                                onReorderTracks(plId, curIdx, targetIdx, currentIdsCopy)
                                            }
                                        } else if (dragOffsetY < -rowHeightPx * 0.7f && curIdx > 0) {
                                            val targetIdx = curIdx - 1
                                            val currentIdsCopy = orderedTrackIds
                                            val mut = currentIdsCopy.toMutableList()
                                            val item = mut.removeAt(curIdx)
                                            mut.add(targetIdx, item)
                                            orderedTrackIds = mut
                                            draggedIndex = targetIdx
                                            dragOffsetY += rowHeightPx
                                            activePlaylist?.id?.let { plId ->
                                                onReorderTracks(plId, curIdx, targetIdx, currentIdsCopy)
                                            }
                                        }
                                    }
                                )
                            }
                    ) {
                        CleanSpotifyTrackRow(
                            track = track,
                            isPlayingNow = track.id == currentPlayingId,
                            subtitlePrefix = null,
                            activeDownload = downloads[track.id],
                            showDragHandle = true,
                            onRowClick = { onPlayTrack(track, activeTracks) },
                            onFavoriteClick = { onToggleFavorite(track) },
                            onAddToPlaylistClick = null,
                            onDownloadAudioClick = null,
                            onDownloadVideoClick = null,
                            onRemoveClick = {
                                activePlaylist?.id?.let { plId ->
                                    onRemoveFromPlaylist(plId, track)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Beğenilen veya İndirilen Şarkılardan Seçip Playliste Ekleme Penceresi
    if (showAddSongsPicker && activePlaylist != null) {
        MultiSelectSongsDialog(
            playlistName = activePlaylist.name,
            availableTracks = allTracks,
            alreadyInPlaylistIds = activePlaylist.trackIds.toSet(),
            onConfirmSelection = { chosenTracks ->
                onAddMultipleToPlaylist(activePlaylist.id, chosenTracks)
                showAddSongsPicker = false
            },
            onDismiss = { showAddSongsPicker = false }
        )
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = DeepSlateBlack,
            title = { Text("Yeni چalma listesi", color = PureIceWhite, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    placeholder = { Text("Çalma listesi adı", color = SubtleGray) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = PureIceWhite,
                        unfocusedTextColor = PureIceWhite,
                        focusedBorderColor = NeonSapphire,
                        unfocusedBorderColor = SurfaceSteelBlue
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            onCreatePlaylist(newPlaylistName)
                            newPlaylistName = ""
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                ) {
                    Text("Oluştur", color = PureIceWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("İptal", color = MutedSilver)
                }
            }
        )
    }
}

@Composable
private fun MultiSelectSongsDialog(
    playlistName: String,
    availableTracks: List<GoatTrack>,
    alreadyInPlaylistIds: Set<String>,
    onConfirmSelection: (List<GoatTrack>) -> Unit,
    onDismiss: () -> Unit
) {
    val candidateTracks = remember(availableTracks, alreadyInPlaylistIds) {
        availableTracks.filterNot { alreadyInPlaylistIds.contains(it.id) }
    }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepSlateBlack,
        title = {
            Column {
                Text(
                    text = "$playlistName listesine şarkı ekle",
                    color = PureIceWhite,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Beğenilen ve indirilen şarkılarından seç",
                    color = MutedSilver,
                    fontSize = 12.sp
                )
            }
        },
        text = {
            if (candidateTracks.isEmpty()) {
                Text(
                    text = "Kütüphanendeki tüm şarkılar zaten bu listede yer alıyor veya henüz şarkı kaydetmedin.",
                    color = MutedSilver,
                    fontSize = 13.sp
                )
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                    items(candidateTracks, key = { it.id }) { track ->
                        val isChecked = selectedIds.contains(track.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedIds = if (isChecked) selectedIds - track.id else selectedIds + track.id
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = {
                                    selectedIds = if (isChecked) selectedIds - track.id else selectedIds + track.id
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = ElectricCobalt,
                                    uncheckedColor = SubtleGray
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = track.title,
                                    color = PureIceWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = buildString {
                                        if (track.isFavorite) append("Beğenilen • ")
                                        if (track.isDownloadedAny) append("İndirilen • ")
                                        append(track.artist)
                                    },
                                    color = MutedSilver,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val chosen = candidateTracks.filter { selectedIds.contains(it.id) }
                    onConfirmSelection(chosen)
                },
                enabled = selectedIds.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
            ) {
                Text("Seçilenleri Ekle (${selectedIds.size})", color = PureIceWhite)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Kapat", color = MutedSilver)
            }
        }
    )
}

/**
 * Gercek Spotify / Apple Music duzeyinde temiz, kutusuz, insan yapimi gorunumlu sarki satiri.
 */
@Composable
private fun CleanSpotifyTrackRow(
    track: GoatTrack,
    isPlayingNow: Boolean,
    subtitlePrefix: String?,
    activeDownload: DownloadTaskState?,
    showDragHandle: Boolean = false,
    onRowClick: () -> Unit,
    onFavoriteClick: (() -> Unit)?,
    onAddToPlaylistClick: (() -> Unit)?,
    onDownloadAudioClick: (() -> Unit)?,
    onDownloadVideoClick: (() -> Unit)?,
    onPlayVideoClick: (() -> Unit)? = null,
    onRemoveClick: (() -> Unit)? = null
) {
    var showMoreMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onRowClick() }
            .padding(horizontal = 16.dp, vertical = 7.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (showDragHandle) {
                Icon(
                    imageVector = Icons.Default.DragHandle,
                    contentDescription = "Sürükle",
                    tint = SubtleGray,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .size(20.dp)
                )
            }

            AsyncImage(
                model = track.thumbnailUrl,
                placeholder = painterResource(id = R.drawable.art_default_cover),
                error = painterResource(id = R.drawable.art_default_cover),
                contentDescription = track.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    color = if (isPlayingNow) NeonSapphire else PureIceWhite,
                    fontSize = 15.sp,
                    fontWeight = if (isPlayingNow) FontWeight.SemiBold else FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // İndirilmişse gerçek Spotify gibi sadece zarif küçük ikon göster
                    if (track.isDownloadedAny) {
                        Icon(
                            imageVector = Icons.Default.DownloadDone,
                            contentDescription = "İndirildi",
                            tint = NeonSapphire,
                            modifier = Modifier
                                .size(14.dp)
                                .padding(end = 4.dp)
                        )
                    }
                    val sub = if (!subtitlePrefix.isNullOrBlank()) {
                        "${track.artist} • $subtitlePrefix"
                    } else {
                        track.artist
                    }
                    Text(
                        text = sub,
                        color = MutedSilver,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Kalp (Beğeni) İkonu
            if (onFavoriteClick != null) {
                IconButton(
                    onClick = onFavoriteClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Beğen",
                        tint = if (track.isFavorite) NeonSapphire else SubtleGray,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }

            // Arama ekranında hızlı ses indirme ikonu
            if (onDownloadAudioClick != null && !track.isDownloadedAudio) {
                IconButton(
                    onClick = onDownloadAudioClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Ses İndir",
                        tint = MutedSilver,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }

            // Üç Nokta (Diğer Seçenekler: Playliste Ekle, Video İndir, Klibi Aç, Listeden Kaldır)
            Box {
                IconButton(
                    onClick = { showMoreMenu = true },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Seçenekler",
                        tint = SubtleGray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMoreMenu,
                    onDismissRequest = { showMoreMenu = false },
                    modifier = Modifier.background(CardMidnightBlue)
                ) {
                    if (onAddToPlaylistClick != null) {
                        DropdownMenuItem(
                            text = { Text("Çalma listesine ekle", color = PureIceWhite) },
                            leadingIcon = { Icon(Icons.Default.PlaylistAdd, null, tint = PureIceWhite) },
                            onClick = {
                                showMoreMenu = false
                                onAddToPlaylistClick()
                            }
                        )
                    }
                    if (onDownloadAudioClick != null) {
                        DropdownMenuItem(
                            text = { Text("Sesi indir (M4A)", color = PureIceWhite) },
                            leadingIcon = { Icon(Icons.Default.Download, null, tint = NeonSapphire) },
                            onClick = {
                                showMoreMenu = false
                                onDownloadAudioClick()
                            }
                        )
                    }
                    if (onDownloadVideoClick != null) {
                        DropdownMenuItem(
                            text = { Text("Videoyu indir (MP4)", color = PureIceWhite) },
                            leadingIcon = { Icon(Icons.Default.Videocam, null, tint = NeonSapphire) },
                            onClick = {
                                showMoreMenu = false
                                onDownloadVideoClick()
                            }
                        )
                    }
                    if (onPlayVideoClick != null) {
                        DropdownMenuItem(
                            text = { Text("Video klibi oynat", color = PureIceWhite) },
                            leadingIcon = { Icon(Icons.Default.OndemandVideo, null, tint = PureIceWhite) },
                            onClick = {
                                showMoreMenu = false
                                onPlayVideoClick()
                            }
                        )
                    }
                    if (onRemoveClick != null) {
                        DropdownMenuItem(
                            text = { Text("Listeden / İndirilenlerden kaldır", color = CrimsonAccent) },
                            leadingIcon = { Icon(Icons.Default.DeleteOutline, null, tint = CrimsonAccent) },
                            onClick = {
                                showMoreMenu = false
                                onRemoveClick()
                            }
                        )
                    }
                }
            }
        }

        // Yalnızca aktif indirme devam ederken (%1..%99) ince ilerleme çubuğu gösterilir
        if (activeDownload != null && !activeDownload.isCompleted && !activeDownload.isFailed) {
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { activeDownload.progressPercent / 100f },
                color = NeonSapphire,
                trackColor = SurfaceSteelBlue,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
            )
        }
    }
}

@Composable
private fun QuickPlaylistDialog(
    track: GoatTrack,
    playlists: List<GoatPlaylist>,
    onTogglePlaylist: (String) -> Unit,
    onCreateNewPlaylist: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var newPlName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepSlateBlack,
        title = {
            Column {
                Text(
                    text = "Çalma listesine ekle",
                    color = PureIceWhite,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = track.title,
                    color = MutedSilver,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                playlists.forEach { pl ->
                    val inPlaylist = pl.trackIds.contains(track.id)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (inPlaylist) CardMidnightBlue else ObsidianBlack)
                            .clickable { onTogglePlaylist(pl.id) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = pl.name,
                            color = PureIceWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Icon(
                            imageVector = if (inPlaylist) Icons.Default.CheckCircle else Icons.Default.AddCircleOutline,
                            contentDescription = null,
                            tint = if (inPlaylist) NeonSapphire else SubtleGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newPlName,
                        onValueChange = { newPlName = it },
                        placeholder = { Text("Yeni liste adı...", color = SubtleGray, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = PureIceWhite,
                            unfocusedTextColor = PureIceWhite,
                            focusedBorderColor = NeonSapphire,
                            unfocusedBorderColor = SurfaceSteelBlue
                        )
                    )
                    Button(
                        onClick = {
                            if (newPlName.isNotBlank()) {
                                onCreateNewPlaylist(newPlName)
                                newPlName = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                    ) {
                        Text("Ekle", color = PureIceWhite, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Bitti", color = PureIceWhite, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun MiniPlayerBar(
    track: GoatTrack,
    isPlaying: Boolean,
    isBuffering: Boolean,
    positionMs: Long,
    durationMs: Long,
    onTogglePlay: () -> Unit,
    onFavorite: () -> Unit,
    onNext: () -> Unit,
    onOpenFullPlayer: () -> Unit
) {
    val progress = (positionMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(CardMidnightBlue)
            .clickable { onOpenFullPlayer() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = track.thumbnailUrl,
                placeholder = painterResource(id = R.drawable.art_default_cover),
                error = painterResource(id = R.drawable.art_default_cover),
                contentDescription = track.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(4.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    color = PureIceWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = track.artist,
                    color = MutedSilver,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onFavorite, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Beğen",
                    tint = if (track.isFavorite) NeonSapphire else PureIceWhite,
                    modifier = Modifier.size(20.dp)
                )
            }
            IconButton(onClick = onTogglePlay, modifier = Modifier.size(38.dp)) {
                if (isBuffering) {
                    CircularProgressIndicator(
                        color = PureIceWhite,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                } else {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Oynat/Duraklat",
                        tint = PureIceWhite,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
            IconButton(onClick = onNext, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Sonraki",
                    tint = PureIceWhite,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        LinearProgressIndicator(
            progress = { progress },
            color = PureIceWhite,
            trackColor = SurfaceSteelBlue,
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
        )
    }
}

@Composable
private fun FullScreenPlayerModal(
    track: GoatTrack,
    vm: GoatViewModel,
    isPlaying: Boolean,
    isBuffering: Boolean,
    isVideoMode: Boolean,
    isShuffleEnabled: Boolean,
    positionMs: Long,
    durationMs: Long,
    liveAudioBars: List<Float>,
    onOpenPlaylistSheet: () -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(CardMidnightBlue, DeepSlateBlack, ObsidianBlack)
                )
            )
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Küçült",
                        tint = PureIceWhite,
                        modifier = Modifier.size(30.dp)
                    )
                }
                Text(
                    text = if (isVideoMode) "VİDEO KLİP" else "ŞİMDİ ÇALIYOR",
                    color = MutedSilver,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
                TextButton(onClick = { vm.toggleVideoMode() }) {
                    Text(
                        text = if (isVideoMode) "Sese Geç" else "Klibi Aç",
                        color = PureIceWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ObsidianBlack),
                contentAlignment = Alignment.Center
            ) {
                if (isVideoMode) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                player = vm.exoPlayer
                                useController = false
                            }
                        },
                        update = { view ->
                            view.player = vm.exoPlayer
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    AsyncImage(
                        model = track.thumbnailUrl,
                        placeholder = painterResource(id = R.drawable.art_default_cover),
                        error = painterResource(id = R.drawable.art_default_cover),
                        contentDescription = track.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        color = PureIceWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = track.artist,
                        color = MutedSilver,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onOpenPlaylistSheet) {
                    Icon(
                        imageVector = Icons.Default.PlaylistAdd,
                        contentDescription = "Listeye Ekle",
                        tint = PureIceWhite,
                        modifier = Modifier.size(26.dp)
                    )
                }
                IconButton(onClick = { vm.toggleFavorite(track) }) {
                    Icon(
                        imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Beğen",
                        tint = if (track.isFavorite) NeonSapphire else PureIceWhite,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            // Şarkının gerçek ses yüksekliğine (RMS Loudness) göre yavaşça yükselip alçalan dalga çubuğu
            val sliderPos = (positionMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
            RealAudioLoudnessSeekbar(
                progress = sliderPos,
                liveBars = liveAudioBars,
                onSeek = { frac ->
                    vm.seekTo((frac * durationMs).toLong())
                }
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = formatMillis(positionMs), color = SubtleGray, fontSize = 12.sp)
                Text(text = formatMillis(durationMs), color = SubtleGray, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.toggleShuffleMode() }) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Karışık Çal",
                        tint = if (isShuffleEnabled) NeonSapphire else MutedSilver,
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(onClick = { vm.playPreviousInQueue() }) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Önceki",
                        tint = PureIceWhite,
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(
                    onClick = { vm.togglePlayPause() },
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(PureIceWhite)
                ) {
                    if (isBuffering) {
                        CircularProgressIndicator(
                            color = ObsidianBlack,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(30.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Oynat/Duraklat",
                            tint = ObsidianBlack,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                IconButton(onClick = { vm.playNextInQueue() }) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Sonraki",
                        tint = PureIceWhite,
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(onClick = onOpenPlaylistSheet) {
                    Icon(
                        imageVector = Icons.Default.QueueMusic,
                        contentDescription = "Liste",
                        tint = MutedSilver,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun BotShieldWebViewDialog(onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBlack)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepSlateBlack)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Bağlantı Doğrulama",
                        color = PureIceWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Sayfa açıldığında çerezler otomatik kaydedilir.",
                        color = MutedSilver,
                        fontSize = 11.sp
                    )
                }
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                ) {
                    Text("Tamam", color = PureIceWhite, fontSize = 12.sp)
                }
            }

            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, url: String?) {
                                CookieManager.getInstance().flush()
                            }
                        }
                        loadUrl("https://m.youtube.com")
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private fun formatMillis(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "%d:%02d".format(min, sec)
}
