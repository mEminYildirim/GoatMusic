@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.goatmusic.app.ui

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.goatmusic.app.R
import com.goatmusic.app.data.LibraryRepository
import com.goatmusic.app.model.DownloadTaskState
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.MediaFormatType
import com.goatmusic.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun GoatMusicApp(vm: GoatViewModel) {
    // Acilis animasyonu ("Hosgeldin Agam" / "created by Mami")
    var showSplash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(2400)
        showSplash = false
    }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Ana Sayfa, 1: Ara & İndir, 2: Playlistlerim
    var isFullPlayerOpen by remember { mutableStateOf(false) }
    var showBotShieldDialog by remember { mutableStateOf(false) }
    var playlistSheetTrack by remember { mutableStateOf<GoatTrack?>(null) }

    val searchQuery by vm.searchQuery.collectAsState()
    val isSearching by vm.isSearching.collectAsState()
    val searchResults by vm.searchResults.collectAsState()
    val libraryTracks by vm.libraryTracks.collectAsState()
    val similarTracks by vm.similarTracks.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val currentTrack by vm.currentTrack.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val isBuffering by vm.isBuffering.collectAsState()
    val isVideoMode by vm.isVideoMode.collectAsState()
    val positionMs by vm.positionMs.collectAsState()
    val durationMs by vm.durationMs.collectAsState()
    val downloads by vm.downloads.collectAsState()
    val engineStatus by vm.engineStatus.collectAsState()
    val isBotShieldVerified by vm.isBotShieldVerified.collectAsState()
    val statusBanner by vm.statusBanner.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Scaffold(
            containerColor = ObsidianBlack,
            bottomBar = {
                Column {
                    if (currentTrack != null) {
                        MiniPlayerBar(
                            track = currentTrack!!,
                            isPlaying = isPlaying,
                            isBuffering = isBuffering,
                            positionMs = positionMs,
                            durationMs = durationMs,
                            onTogglePlay = { vm.togglePlayPause() },
                            onFavorite = { vm.toggleFavorite(currentTrack!!) },
                            onNext = { vm.playNextInLibrary() },
                            onOpenFullPlayer = { isFullPlayerOpen = true }
                        )
                    }

                    NavigationBar(
                        containerColor = DeepSlateBlack,
                        tonalElevation = 8.dp
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Ana Sayfa") },
                            label = { Text("Ana Sayfa", fontWeight = FontWeight.SemiBold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonSapphire,
                                selectedTextColor = NeonSapphire,
                                unselectedIconColor = MutedSilver,
                                unselectedTextColor = MutedSilver,
                                indicatorColor = CardMidnightBlue
                            )
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.Search, contentDescription = "Ara & İndir") },
                            label = { Text("Ara & İndir", fontWeight = FontWeight.SemiBold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonSapphire,
                                selectedTextColor = NeonSapphire,
                                unselectedIconColor = MutedSilver,
                                unselectedTextColor = MutedSilver,
                                indicatorColor = CardMidnightBlue
                            )
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Playlistler") },
                            label = { Text("Playlistler", fontWeight = FontWeight.SemiBold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonSapphire,
                                selectedTextColor = NeonSapphire,
                                unselectedIconColor = MutedSilver,
                                unselectedTextColor = MutedSilver,
                                indicatorColor = CardMidnightBlue
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!statusBanner.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CardMidnightBlue)
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = statusBanner!!,
                            color = NeonSapphire,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                when (selectedTab) {
                    0 -> HomeScreen(
                        engineStatus = engineStatus,
                        isBotShieldVerified = isBotShieldVerified,
                        libraryTracks = libraryTracks,
                        similarTracks = similarTracks,
                        downloads = downloads,
                        onOpenBotShield = { showBotShieldDialog = true },
                        onPlayTrack = { track, video -> vm.playTrack(track, video) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onOpenPlaylistSheet = { playlistSheetTrack = it },
                        onGoToSearch = { selectedTab = 1 }
                    )
                    1 -> SearchAndDownloadScreen(
                        query = searchQuery,
                        isSearching = isSearching,
                        results = searchResults,
                        downloads = downloads,
                        onQueryChange = { vm.onSearchQueryChange(it) },
                        onSearchSubmit = { vm.performSearch(searchQuery) },
                        onPlayTrack = { track, video -> vm.playTrack(track, video) },
                        onDownloadTrack = { track, fmt -> vm.downloadTrack(track, fmt) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onOpenPlaylistSheet = { playlistSheetTrack = it }
                    )
                    2 -> PlaylistsScreen(
                        playlists = playlists,
                        allTracks = libraryTracks,
                        downloads = downloads,
                        onCreatePlaylist = { vm.createPlaylist(it) },
                        onDeletePlaylist = { vm.deleteCustomPlaylist(it) },
                        onPlayTrack = { track, video -> vm.playTrack(track, video) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onRemoveFromPlaylist = { plId, track -> vm.toggleTrackInPlaylist(plId, track) }
                    )
                }
            }
        }

        // Tam Ekran Çalar (İndirme butonları kaldırıldı, dinamik şiddetli ses dalgası çubuğu eklendi)
        AnimatedVisibility(
            visible = isFullPlayerOpen && currentTrack != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            if (currentTrack != null) {
                FullScreenPlayerModal(
                    track = currentTrack!!,
                    vm = vm,
                    isPlaying = isPlaying,
                    isBuffering = isBuffering,
                    isVideoMode = isVideoMode,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    onOpenPlaylistSheet = { playlistSheetTrack = currentTrack },
                    onClose = { isFullPlayerOpen = false }
                )
            }
        }

        // Tek Tuşla Playliste Ekle / Çıkar Penceresi
        if (playlistSheetTrack != null) {
            QuickPlaylistDialog(
                track = playlistSheetTrack!!,
                playlists = playlists,
                onTogglePlaylist = { plId ->
                    vm.toggleTrackInPlaylist(plId, playlistSheetTrack!!)
                },
                onCreateNewPlaylist = { name ->
                    vm.createPlaylist(name)
                },
                onDismiss = { playlistSheetTrack = null }
            )
        }

        if (showBotShieldDialog) {
            BotShieldWebViewDialog(
                onDismiss = {
                    CookieManager.getInstance().flush()
                    vm.refreshBotShieldState()
                    showBotShieldDialog = false
                }
            )
        }

        // Açılış Müzik Animasyonu: "Hoşgeldin Agam" / "created by Mami"
        AnimatedVisibility(
            visible = showSplash,
            enter = fadeIn(),
            exit = fadeOut(animationSpec = tween(550))
        ) {
            GoatIntroSplash()
        }
    }
}

@Composable
private fun GoatIntroSplash() {
    val infiniteTransition = rememberInfiniteTransition(label = "splash_wave")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.283f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logo_pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(CardMidnightBlue, DeepSlateBlack, ObsidianBlack),
                    radius = 900f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Image(
                    painter = painterResource(id = R.drawable.goat_logo_upper),
                    contentDescription = "Goat Music",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(116.dp)
                        .scale(pulse)
                        .clip(CircleShape)
                        .border(3.dp, NeonSapphire, CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Dinamik Ekolayzer Barları Animasyonu
            Canvas(
                modifier = Modifier
                    .width(200.dp)
                    .height(44.dp)
            ) {
                val barCount = 21
                val spacing = size.width / barCount
                val barWidth = spacing * 0.58f
                for (i in 0 until barCount) {
                    val norm = 0.25f + 0.75f * abs(sin(phase + i * 0.45f))
                    val barH = size.height * norm
                    val topY = (size.height - barH) / 2f
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(NeonSapphire, ElectricCobalt)
                        ),
                        topLeft = Offset(i * spacing, topY),
                        size = Size(barWidth, barH),
                        cornerRadius = CornerRadius(8f, 8f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Hoşgeldin Agam",
                color = PureIceWhite,
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.8.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "created by Mami",
                color = NeonSapphire,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.6.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Sarki siddetine ve ritmine gore canli dalgalanan interaktif ses cubugu (Waveform Seekbar)
 */
@Composable
fun AudioReactiveWaveSeekbar(
    progress: Float,
    isPlaying: Boolean,
    trackSeed: Int,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "audio_reactive")
    val animPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 680, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val frac = (offset.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                    onSeek(frac)
                }
            }
    ) {
        val barCount = 46
        val slotWidth = size.width / barCount
        val barWidth = slotWidth * 0.62f
        val centerY = size.height / 2f

        for (i in 0 until barCount) {
            val barPositionFrac = i.toFloat() / barCount.toFloat()
            val isPassed = barPositionFrac <= progress
            val isNearPlayhead = abs(barPositionFrac - progress) < 0.045f

            // Sarkinin frekans zarfi + canli calma anindaki siddet dalgalanmasi
            val baseEnvelope = 0.25f + 0.55f * abs(sin((i * 0.37f) + (trackSeed % 17)))
            val liveEnergy = if (isPlaying) {
                0.35f + 0.65f * abs(sin(animPhase * 2f + i * 0.55f) * sin(animPhase - i * 0.23f))
            } else {
                0.28f
            }

            val boost = if (isNearPlayhead && isPlaying) 1.28f else 1.0f
            val finalRatio = (baseEnvelope * liveEnergy * boost).coerceIn(0.14f, 1.0f)
            val barHeight = size.height * finalRatio

            val color = when {
                isNearPlayhead -> PureIceWhite
                isPassed -> NeonSapphire
                else -> SurfaceSteelBlue
            }

            drawRoundRect(
                color = color,
                topLeft = Offset(x = i * slotWidth, y = centerY - barHeight / 2f),
                size = Size(width = barWidth, height = barHeight),
                cornerRadius = CornerRadius(6f, 6f)
            )
        }
    }
}

@Composable
private fun HomeScreen(
    engineStatus: String,
    isBotShieldVerified: Boolean,
    libraryTracks: List<GoatTrack>,
    similarTracks: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onOpenBotShield: () -> Unit,
    onPlayTrack: (GoatTrack, Boolean) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onOpenPlaylistSheet: (GoatTrack) -> Unit,
    onGoToSearch: () -> Unit
) {
    val recentlyPlayed = remember(libraryTracks) {
        libraryTracks.filter { it.lastPlayedAt > 0L }.sortedByDescending { it.lastPlayedAt }.take(12)
    }
    val mostPlayed = remember(libraryTracks) {
        libraryTracks.filter { it.playCount > 0 }.sortedByDescending { it.playCount }.take(10)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        // Modern ve sade üst başlık
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(CardMidnightBlue, ObsidianBlack)
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.goat_logo_upper),
                            contentDescription = "Goat Music Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .border(2.dp, NeonSapphire, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "GOAT MUSIC",
                                color = PureIceWhite,
                                fontSize = 21.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = engineStatus,
                                color = NeonSapphire,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onOpenBotShield,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Bot Kalkanı",
                            tint = if (isBotShieldVerified) EmeraldSuccess else NeonSapphire,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isBotShieldVerified) "Kalkan Aktif" else "Bot Kalkanı",
                            color = PureIceWhite,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Eğer kullanıcı henüz hiçbir şarkı dinlemediyse sade karşılama kartı
        if (recentlyPlayed.isEmpty() && mostPlayed.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 32.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(DeepSlateBlack)
                        .border(1.dp, SurfaceSteelBlue, RoundedCornerShape(16.dp))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = NeonSapphire,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Dinleme Geçmişin Burada Şekillenecek",
                        color = PureIceWhite,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Şarkı dinledikçe Son Dinlenilenler, En Çok Dinlediklerin ve Sana Özel Benzer Şarkılar otomatik olarak burada listelenir.",
                        color = MutedSilver,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onGoToSearch,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = PureIceWhite)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("İlk Şarkını Ara", color = PureIceWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 1. BÖLÜM: Son Dinlenilenler
        if (recentlyPlayed.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    Text(
                        text = "Son Dinlenilenler",
                        color = PureIceWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(recentlyPlayed, key = { "rec_" + it.id }) { track ->
                            Column(
                                modifier = Modifier
                                    .width(138.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DeepSlateBlack)
                                    .clickable { onPlayTrack(track, false) }
                                    .padding(8.dp)
                            ) {
                                AsyncImage(
                                    model = track.thumbnailUrl,
                                    placeholder = painterResource(id = R.drawable.art_default_cover),
                                    error = painterResource(id = R.drawable.art_default_cover),
                                    contentDescription = track.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(122.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = track.title,
                                    color = PureIceWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = track.artist,
                                    color = MutedSilver,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. BÖLÜM: En Çok Dinlediklerin
        if (mostPlayed.isNotEmpty()) {
            item {
                Text(
                    text = "En Çok Dinlediklerin",
                    color = PureIceWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 6.dp)
                )
            }
            items(mostPlayed.take(6), key = { "most_" + it.id }) { track ->
                TrackRowItem(
                    track = track,
                    badgeText = "${track.playCount} kez dinlendi",
                    downloadState = downloads[track.id],
                    onPlayAudio = { onPlayTrack(track, false) },
                    onPlayVideo = { onPlayTrack(track, true) },
                    onDownloadAudio = null,
                    onDownloadVideo = null,
                    onFavoriteClick = { onToggleFavorite(track) },
                    onPlaylistAddClick = { onOpenPlaylistSheet(track) }
                )
            }
        }

        // 3. BÖLÜM: En Çok Dinlediğin Şarkılara Benzer Şarkılar
        if (similarTracks.isNotEmpty()) {
            item {
                Text(
                    text = "Zevkine Göre Benzer Şarkılar",
                    color = PureIceWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 6.dp)
                )
            }
            items(similarTracks, key = { "sim_" + it.id }) { track ->
                TrackRowItem(
                    track = track,
                    badgeText = null,
                    downloadState = downloads[track.id],
                    onPlayAudio = { onPlayTrack(track, false) },
                    onPlayVideo = { onPlayTrack(track, true) },
                    onDownloadAudio = null,
                    onDownloadVideo = null,
                    onFavoriteClick = { onToggleFavorite(track) },
                    onPlaylistAddClick = { onOpenPlaylistSheet(track) }
                )
            }
        }
    }
}

@Composable
private fun SearchAndDownloadScreen(
    query: String,
    isSearching: Boolean,
    results: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onQueryChange: (String) -> Unit,
    onSearchSubmit: () -> Unit,
    onPlayTrack: (GoatTrack, Boolean) -> Unit,
    onDownloadTrack: (GoatTrack, MediaFormatType) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onOpenPlaylistSheet: (GoatTrack) -> Unit
) {
    val focusManager = LocalFocusManager.current

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = {
                Text("YouTube'da şarkı, sanatçı veya klip ara...", color = MutedSilver)
            },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = NeonSapphire)
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Temizle", tint = MutedSilver)
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focusManager.clearFocus()
                onSearchSubmit()
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CardMidnightBlue,
                unfocusedContainerColor = DeepSlateBlack,
                focusedBorderColor = ElectricCobalt,
                unfocusedBorderColor = SurfaceSteelBlue,
                focusedTextColor = PureIceWhite,
                unfocusedTextColor = PureIceWhite
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        )

        if (isSearching) {
            LinearProgressIndicator(
                color = NeonSapphire,
                trackColor = CardMidnightBlue,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(results, key = { it.id }) { track ->
                TrackRowItem(
                    track = track,
                    badgeText = null,
                    downloadState = downloads[track.id],
                    onPlayAudio = { onPlayTrack(track, false) },
                    onPlayVideo = { onPlayTrack(track, true) },
                    onDownloadAudio = { onDownloadTrack(track, MediaFormatType.AUDIO_M4A) },
                    onDownloadVideo = { onDownloadTrack(track, MediaFormatType.VIDEO_MP4) },
                    onFavoriteClick = { onToggleFavorite(track) },
                    onPlaylistAddClick = { onOpenPlaylistSheet(track) }
                )
            }
        }
    }
}

@Composable
private fun PlaylistsScreen(
    playlists: List<GoatPlaylist>,
    allTracks: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onPlayTrack: (GoatTrack, Boolean) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onRemoveFromPlaylist: (String, GoatTrack) -> Unit
) {
    var selectedPlaylistId by remember { mutableStateOf(LibraryRepository.PLAYLIST_LIKED_ID) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }

    val activePlaylist = playlists.find { it.id == selectedPlaylistId } ?: playlists.firstOrNull()
    val trackMap = remember(allTracks) { allTracks.associateBy { it.id } }
    val activeTracks = remember(activePlaylist, trackMap) {
        activePlaylist?.trackIds?.mapNotNull { trackMap[it] }.orEmpty()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Playlistlerim",
                color = PureIceWhite,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = PureIceWhite, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Yeni Playlist", color = PureIceWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Playlist Seçim Kartları (Beğenilen Şarkılar ve İndirilen Şarkılar garantili sabit + Özel Playlistler)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(playlists, key = { it.id }) { pl ->
                val isSelected = pl.id == activePlaylist?.id
                val icon = when (pl.id) {
                    LibraryRepository.PLAYLIST_LIKED_ID -> Icons.Default.Favorite
                    LibraryRepository.PLAYLIST_DOWNLOADED_ID -> Icons.Default.DownloadDone
                    else -> Icons.Default.QueueMusic
                }
                val iconTint = when (pl.id) {
                    LibraryRepository.PLAYLIST_LIKED_ID -> CrimsonAccent
                    LibraryRepository.PLAYLIST_DOWNLOADED_ID -> EmeraldSuccess
                    else -> NeonSapphire
                }

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) ElectricCobalt else CardMidnightBlue)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) NeonSapphire else SurfaceSteelBlue,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { selectedPlaylistId = pl.id }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isSelected) PureIceWhite else iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = pl.name,
                            color = PureIceWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${pl.trackIds.size} şarkı",
                            color = if (isSelected) PureIceWhite.copy(alpha = 0.8f) else MutedSilver,
                            fontSize = 11.sp
                        )
                    }
                    if (!pl.isSystemPlaylist) {
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                onDeletePlaylist(pl.id)
                                selectedPlaylistId = LibraryRepository.PLAYLIST_LIKED_ID
                            },
                            modifier = Modifier.size(22.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Playlisti Sil",
                                tint = PureIceWhite.copy(alpha = 0.7f),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (activeTracks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.QueueMusic,
                        contentDescription = null,
                        tint = NeonSapphire,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "${activePlaylist?.name ?: "Bu liste"} şu an boş",
                        color = PureIceWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = when (activePlaylist?.id) {
                            LibraryRepository.PLAYLIST_LIKED_ID -> "Beğendiğin (kalp attığın) tüm şarkılar anında buraya eklenir; beğeniyi çektiğinde buradan kalkar."
                            LibraryRepository.PLAYLIST_DOWNLOADED_ID -> "İndirdiğin tüm şarkılar ve videolar anında buraya eklenir; sildiğinde buradan kalkar."
                            else -> "Herhangi bir şarkının yanındaki (+) Playlist ikonuna dokunarak tek tuşla bu listeye ekleyebilirsin."
                        },
                        color = MutedSilver,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(activeTracks, key = { it.id }) { track ->
                    TrackRowItem(
                        track = track,
                        badgeText = null,
                        downloadState = downloads[track.id],
                        onPlayAudio = { onPlayTrack(track, false) },
                        onPlayVideo = { onPlayTrack(track, true) },
                        onDownloadAudio = null,
                        onDownloadVideo = null,
                        onFavoriteClick = { onToggleFavorite(track) },
                        onPlaylistAddClick = null,
                        onDeleteClick = {
                            activePlaylist?.id?.let { plId ->
                                onRemoveFromPlaylist(plId, track)
                            }
                        }
                    )
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = DeepSlateBlack,
            title = { Text("Yeni Playlist Oluştur", color = PureIceWhite, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    placeholder = { Text("Playlist adı (Örn: Gece Sürüşü)", color = MutedSilver) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = PureIceWhite,
                        unfocusedTextColor = PureIceWhite,
                        focusedBorderColor = NeonSapphire,
                        unfocusedBorderColor = SurfaceSteelBlue
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            onCreatePlaylist(newPlaylistName)
                            newPlaylistName = ""
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                ) {
                    Text("Oluştur", color = PureIceWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("İptal", color = MutedSilver)
                }
            }
        )
    }
}

@Composable
private fun QuickPlaylistDialog(
    track: GoatTrack,
    playlists: List<GoatPlaylist>,
    onTogglePlaylist: (String) -> Unit,
    onCreateNewPlaylist: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var newPlName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepSlateBlack,
        title = {
            Column {
                Text(
                    text = "Playlist'e Ekle veya Çıkar",
                    color = PureIceWhite,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = track.title,
                    color = NeonSapphire,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                playlists.forEach { pl ->
                    val inPlaylist = pl.trackIds.contains(track.id)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (inPlaylist) CardMidnightBlue else ObsidianBlack)
                            .clickable { onTogglePlaylist(pl.id) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = pl.name,
                            color = PureIceWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(
                            imageVector = if (inPlaylist) Icons.Default.CheckCircle else Icons.Default.AddCircleOutline,
                            contentDescription = null,
                            tint = if (inPlaylist) EmeraldSuccess else NeonSapphire
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newPlName,
                        onValueChange = { newPlName = it },
                        placeholder = { Text("Yeni liste adı...", color = MutedSilver, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = PureIceWhite,
                            unfocusedTextColor = PureIceWhite,
                            focusedBorderColor = NeonSapphire,
                            unfocusedBorderColor = SurfaceSteelBlue
                        )
                    )
                    Button(
                        onClick = {
                            if (newPlName.isNotBlank()) {
                                onCreateNewPlaylist(newPlName)
                                newPlName = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                    ) {
                        Text("Ekle", color = PureIceWhite, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
            ) {
                Text("Tamam", color = PureIceWhite)
            }
        }
    )
}

@Composable
private fun TrackRowItem(
    track: GoatTrack,
    badgeText: String?,
    downloadState: DownloadTaskState?,
    onPlayAudio: () -> Unit,
    onPlayVideo: () -> Unit,
    onDownloadAudio: (() -> Unit)?,
    onDownloadVideo: (() -> Unit)?,
    onFavoriteClick: (() -> Unit)?,
    onPlaylistAddClick: (() -> Unit)?,
    onDeleteClick: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(DeepSlateBlack)
            .clickable { onPlayAudio() }
            .padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(58.dp)) {
                AsyncImage(
                    model = track.thumbnailUrl,
                    placeholder = painterResource(id = R.drawable.art_default_cover),
                    error = painterResource(id = R.drawable.art_default_cover),
                    contentDescription = track.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(8.dp))
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .background(ObsidianBlack.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = track.durationText,
                        color = PureIceWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    color = PureIceWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!badgeText.isNullOrBlank()) {
                        Text(
                            text = "$badgeText • ",
                            color = NeonSapphire,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (track.isDownloadedAudio) {
                        Text(
                            text = "M4A • ",
                            color = EmeraldSuccess,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (track.isDownloadedVideo) {
                        Text(
                            text = "MP4 • ",
                            color = NeonSapphire,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = track.artist,
                        color = MutedSilver,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Tek Tuşla Beğen (Beğenilen Şarkılar listesine otomatik ekler/çıkarır)
            if (onFavoriteClick != null) {
                IconButton(
                    onClick = onFavoriteClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Beğen",
                        tint = if (track.isFavorite) CrimsonAccent else MutedSilver,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Tek Tuşla Playlist'e Ekle/Çıkar
            if (onPlaylistAddClick != null) {
                IconButton(
                    onClick = onPlaylistAddClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlaylistAdd,
                        contentDescription = "Playliste Ekle",
                        tint = NeonSapphire,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            IconButton(
                onClick = onPlayVideo,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.OndemandVideo,
                    contentDescription = "Klibi Oynat",
                    tint = NeonSapphire,
                    modifier = Modifier.size(20.dp)
                )
            }

            if (onDeleteClick != null) {
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RemoveCircleOutline,
                        contentDescription = "Listeden / İndirilenlerden Kaldır",
                        tint = CrimsonAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        if (onDownloadAudio != null || onDownloadVideo != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { onDownloadAudio?.invoke() },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        tint = NeonSapphire,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (track.isDownloadedAudio) "Ses İndirildi" else "Ses İndir (M4A)",
                        color = PureIceWhite,
                        fontSize = 12.sp
                    )
                }

                OutlinedButton(
                    onClick = { onDownloadVideo?.invoke() },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = null,
                        tint = ElectricCobalt,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (track.isDownloadedVideo) "Video İndirildi" else "Video İndir (MP4)",
                        color = PureIceWhite,
                        fontSize = 12.sp
                    )
                }
            }
        }

        if (downloadState != null) {
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { downloadState.progressPercent / 100f },
                color = if (downloadState.isFailed) CrimsonAccent else NeonSapphire,
                trackColor = CardMidnightBlue,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = downloadState.statusText,
                color = if (downloadState.isFailed) CrimsonAccent else NeonSapphire,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun MiniPlayerBar(
    track: GoatTrack,
    isPlaying: Boolean,
    isBuffering: Boolean,
    positionMs: Long,
    durationMs: Long,
    onTogglePlay: () -> Unit,
    onFavorite: () -> Unit,
    onNext: () -> Unit,
    onOpenFullPlayer: () -> Unit
) {
    val progress = (positionMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(CardMidnightBlue)
            .clickable { onOpenFullPlayer() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = track.thumbnailUrl,
                placeholder = painterResource(id = R.drawable.art_default_cover),
                error = painterResource(id = R.drawable.art_default_cover),
                contentDescription = track.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    color = PureIceWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (isBuffering) "48kHz Hi-Res bağlanıyor..." else track.artist,
                    color = NeonSapphire,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onFavorite) {
                Icon(
                    imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Beğen",
                    tint = if (track.isFavorite) CrimsonAccent else PureIceWhite,
                    modifier = Modifier.size(22.dp)
                )
            }
            IconButton(onClick = onTogglePlay) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                    contentDescription = "Oynat/Duraklat",
                    tint = PureIceWhite,
                    modifier = Modifier.size(34.dp)
                )
            }
            IconButton(onClick = onNext) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Sonraki",
                    tint = PureIceWhite
                )
            }
        }
        LinearProgressIndicator(
            progress = { progress },
            color = NeonSapphire,
            trackColor = DeepSlateBlack,
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
        )
    }
}

@Composable
private fun FullScreenPlayerModal(
    track: GoatTrack,
    vm: GoatViewModel,
    isPlaying: Boolean,
    isBuffering: Boolean,
    isVideoMode: Boolean,
    positionMs: Long,
    durationMs: Long,
    onOpenPlaylistSheet: () -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(CardMidnightBlue, DeepSlateBlack, ObsidianBlack)
                )
            )
            .padding(horizontal = 22.dp, vertical = 16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Küçült",
                        tint = PureIceWhite,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (isVideoMode) "GOAT VIDEO ÇALAR" else "GOAT 48kHz HI-RES",
                        color = NeonSapphire,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }
                TextButton(onClick = { vm.toggleVideoMode() }) {
                    Text(
                        text = if (isVideoMode) "Sese Geç" else "Klibi Aç",
                        color = PureIceWhite,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(ObsidianBlack)
                    .border(1.dp, SurfaceSteelBlue, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (isVideoMode) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                player = vm.exoPlayer
                                useController = false
                            }
                        },
                        update = { view ->
                            view.player = vm.exoPlayer
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    AsyncImage(
                        model = track.thumbnailUrl,
                        placeholder = painterResource(id = R.drawable.art_default_cover),
                        error = painterResource(id = R.drawable.art_default_cover),
                        contentDescription = track.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Şarkı Başlığı, Tek Tuşla Playlist'e Ekle ve Beğen (Kalp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        color = PureIceWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = track.artist,
                        color = NeonSapphire,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                IconButton(onClick = onOpenPlaylistSheet) {
                    Icon(
                        imageVector = Icons.Default.PlaylistAdd,
                        contentDescription = "Playliste Ekle",
                        tint = NeonSapphire,
                        modifier = Modifier.size(28.dp)
                    )
                }
                IconButton(onClick = { vm.toggleFavorite(track) }) {
                    Icon(
                        imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Beğen",
                        tint = if (track.isFavorite) CrimsonAccent else PureIceWhite,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Şarkı Şiddetine Göre Canlı Hareketli Ses Dalgası Çubuğu (Audio-Reactive Waveform Bar)
            val sliderPos = (positionMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
            AudioReactiveWaveSeekbar(
                progress = sliderPos,
                isPlaying = isPlaying,
                trackSeed = track.id.hashCode(),
                onSeek = { frac ->
                    vm.seekTo((frac * durationMs).toLong())
                }
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = formatMillis(positionMs), color = MutedSilver, fontSize = 12.sp)
                Text(text = formatMillis(durationMs), color = MutedSilver, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(22.dp))

            // Oynatma Kontrolleri (Alt kısımdaki indirme butonları tamamen kaldırıldı)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.playPreviousInLibrary() }) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Önceki",
                        tint = PureIceWhite,
                        modifier = Modifier.size(42.dp)
                    )
                }

                IconButton(
                    onClick = { vm.togglePlayPause() },
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(ElectricCobalt)
                ) {
                    if (isBuffering) {
                        CircularProgressIndicator(
                            color = PureIceWhite,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(34.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Oynat/Duraklat",
                            tint = PureIceWhite,
                            modifier = Modifier.size(42.dp)
                        )
                    }
                }

                IconButton(onClick = { vm.playNextInLibrary() }) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Sonraki",
                        tint = PureIceWhite,
                        modifier = Modifier.size(42.dp)
                    )
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun BotShieldWebViewDialog(onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBlack)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardMidnightBlue)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "YouTube Anti-Bot Kalkanı",
                        color = PureIceWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Sayfa açıldığında çerezler otomatik kaydedilir.",
                        color = NeonSapphire,
                        fontSize = 11.sp
                    )
                }
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                ) {
                    Text("Kaydet & Kapat", color = PureIceWhite, fontSize = 12.sp)
                }
            }

            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, url: String?) {
                                CookieManager.getInstance().flush()
                            }
                        }
                        loadUrl("https://m.youtube.com")
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private fun formatMillis(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "%d:%02d".format(min, sec)
}
