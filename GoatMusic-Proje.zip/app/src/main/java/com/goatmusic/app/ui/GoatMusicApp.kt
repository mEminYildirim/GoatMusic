@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.goatmusic.app.ui

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.goatmusic.app.R
import com.goatmusic.app.model.DownloadTaskState
import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.MediaFormatType
import com.goatmusic.app.ui.theme.*

@Composable
fun GoatMusicApp(vm: GoatViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var isFullPlayerOpen by remember { mutableStateOf(false) }
    var showBotShieldDialog by remember { mutableStateOf(false) }

    val searchQuery by vm.searchQuery.collectAsState()
    val isSearching by vm.isSearching.collectAsState()
    val searchResults by vm.searchResults.collectAsState()
    val libraryTracks by vm.libraryTracks.collectAsState()
    val currentTrack by vm.currentTrack.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val isBuffering by vm.isBuffering.collectAsState()
    val isVideoMode by vm.isVideoMode.collectAsState()
    val positionMs by vm.positionMs.collectAsState()
    val durationMs by vm.durationMs.collectAsState()
    val downloads by vm.downloads.collectAsState()
    val engineStatus by vm.engineStatus.collectAsState()
    val isBotShieldVerified by vm.isBotShieldVerified.collectAsState()
    val statusBanner by vm.statusBanner.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Scaffold(
            containerColor = ObsidianBlack,
            bottomBar = {
                Column {
                    if (currentTrack != null) {
                        MiniPlayerBar(
                            track = currentTrack!!,
                            isPlaying = isPlaying,
                            isBuffering = isBuffering,
                            positionMs = positionMs,
                            durationMs = durationMs,
                            onTogglePlay = { vm.togglePlayPause() },
                            onNext = { vm.playNextInLibrary() },
                            onOpenFullPlayer = { isFullPlayerOpen = true }
                        )
                    }

                    NavigationBar(
                        containerColor = DeepSlateBlack,
                        tonalElevation = 8.dp
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Ana Sayfa") },
                            label = { Text("Ana Sayfa", fontWeight = FontWeight.SemiBold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonSapphire,
                                selectedTextColor = NeonSapphire,
                                unselectedIconColor = MutedSilver,
                                unselectedTextColor = MutedSilver,
                                indicatorColor = CardMidnightBlue
                            )
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.Search, contentDescription = "Ara & İndir") },
                            label = { Text("Ara & İndir", fontWeight = FontWeight.SemiBold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonSapphire,
                                selectedTextColor = NeonSapphire,
                                unselectedIconColor = MutedSilver,
                                unselectedTextColor = MutedSilver,
                                indicatorColor = CardMidnightBlue
                            )
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Kitaplığım") },
                            label = { Text("Kitaplığım", fontWeight = FontWeight.SemiBold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonSapphire,
                                selectedTextColor = NeonSapphire,
                                unselectedIconColor = MutedSilver,
                                unselectedTextColor = MutedSilver,
                                indicatorColor = CardMidnightBlue
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!statusBanner.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CardMidnightBlue)
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = statusBanner!!,
                            color = NeonSapphire,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                when (selectedTab) {
                    0 -> HomeScreen(
                        engineStatus = engineStatus,
                        isBotShieldVerified = isBotShieldVerified,
                        libraryTracks = libraryTracks,
                        searchResults = searchResults,
                        downloads = downloads,
                        onOpenBotShield = { showBotShieldDialog = true },
                        onPlayTrack = { track, video -> vm.playTrack(track, video) },
                        onDownloadTrack = { track, fmt -> vm.downloadTrack(track, fmt) },
                        onQuickCategoryClick = { categoryQuery ->
                            vm.onSearchQueryChange(categoryQuery)
                            vm.performSearch(categoryQuery)
                            selectedTab = 1
                        }
                    )
                    1 -> SearchAndDownloadScreen(
                        query = searchQuery,
                        isSearching = isSearching,
                        results = searchResults,
                        downloads = downloads,
                        onQueryChange = { vm.onSearchQueryChange(it) },
                        onSearchSubmit = { vm.performSearch(searchQuery) },
                        onPlayTrack = { track, video -> vm.playTrack(track, video) },
                        onDownloadTrack = { track, fmt -> vm.downloadTrack(track, fmt) },
                        onToggleFavorite = { vm.toggleFavorite(it) }
                    )
                    2 -> LibraryScreen(
                        tracks = libraryTracks,
                        downloads = downloads,
                        onPlayTrack = { track, video -> vm.playTrack(track, video) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onDeleteTrack = { vm.deleteFromLibrary(it.id) }
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = isFullPlayerOpen && currentTrack != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            if (currentTrack != null) {
                FullScreenPlayerModal(
                    track = currentTrack!!,
                    vm = vm,
                    isPlaying = isPlaying,
                    isBuffering = isBuffering,
                    isVideoMode = isVideoMode,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    downloadState = downloads[currentTrack!!.id],
                    onClose = { isFullPlayerOpen = false }
                )
            }
        }

        if (showBotShieldDialog) {
            BotShieldWebViewDialog(
                onDismiss = {
                    CookieManager.getInstance().flush()
                    vm.refreshBotShieldState()
                    showBotShieldDialog = false
                }
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun BotShieldWebViewDialog(onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBlack)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardMidnightBlue)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "YouTube Anti-Bot Kalkanı",
                        color = PureIceWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Sayfa açıldığında çerezler otomatik kaydedilir. İsterseniz giriş de yapabilirsiniz.",
                        color = NeonSapphire,
                        fontSize = 11.sp
                    )
                }
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                ) {
                    Text("Kaydet & Kapat", color = PureIceWhite, fontSize = 12.sp)
                }
            }

            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, url: String?) {
                                CookieManager.getInstance().flush()
                            }
                        }
                        loadUrl("https://m.youtube.com")
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun HomeScreen(
    engineStatus: String,
    isBotShieldVerified: Boolean,
    libraryTracks: List<GoatTrack>,
    searchResults: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onOpenBotShield: () -> Unit,
    onPlayTrack: (GoatTrack, Boolean) -> Unit,
    onDownloadTrack: (GoatTrack, MediaFormatType) -> Unit,
    onQuickCategoryClick: (String) -> Unit
) {
    val quickCategories = listOf(
        "Türkçe Rap Trend",
        "Gym Phonk Bass",
        "Türkçe Pop 2026",
        "Gece Sürüş Müzikleri",
        "Yabancı Hit Remix",
        "Akustik & Chill"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(215.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.art_hero_banner),
                    contentDescription = "Goat Music Hand-Painted Artwork",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    ObsidianBlack.copy(alpha = 0.65f),
                                    ObsidianBlack
                                )
                            )
                        )
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomStart)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.goat_logo_upper),
                            contentDescription = "Goat Music Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(62.dp)
                                .clip(CircleShape)
                                .border(2.dp, NeonSapphire, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "GOAT MUSIC",
                                color = PureIceWhite,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.1.sp
                            )
                            Text(
                                text = engineStatus,
                                color = NeonSapphire,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onOpenBotShield,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Bot Kalkanı",
                            tint = if (isBotShieldVerified) EmeraldSuccess else NeonSapphire,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isBotShieldVerified) "Kalkan Aktif" else "Bot Kalkanı",
                            color = PureIceWhite,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = "Hızlı Frekanslar",
                    color = PureIceWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
                for (rowIdx in 0 until 3) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (colIdx in 0..1) {
                            val title = quickCategories[rowIdx * 2 + colIdx]
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(54.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CardMidnightBlue)
                                    .clickable { onQuickCategoryClick(title) },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.art_default_cover),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(54.dp)
                                )
                                Text(
                                    text = title,
                                    color = PureIceWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 10.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (libraryTracks.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Text(
                        text = "Çevrimdışı & Son Dinlenenler",
                        color = PureIceWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(libraryTracks.take(10), key = { it.id }) { track ->
                            Column(
                                modifier = Modifier
                                    .width(136.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DeepSlateBlack)
                                    .clickable { onPlayTrack(track, false) }
                                    .padding(8.dp)
                            ) {
                                AsyncImage(
                                    model = track.thumbnailUrl,
                                    placeholder = painterResource(id = R.drawable.art_default_cover),
                                    error = painterResource(id = R.drawable.art_default_cover),
                                    contentDescription = track.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(120.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = track.title,
                                    color = PureIceWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = track.artist,
                                    color = MutedSilver,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Keşfet & Hemen İndir",
                color = PureIceWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 6.dp)
            )
        }

        items(searchResults.take(12), key = { it.id }) { track ->
            TrackRowItem(
                track = track,
                downloadState = downloads[track.id],
                onPlayAudio = { onPlayTrack(track, false) },
                onPlayVideo = { onPlayTrack(track, true) },
                onDownloadAudio = { onDownloadTrack(track, MediaFormatType.AUDIO_M4A) },
                onDownloadVideo = { onDownloadTrack(track, MediaFormatType.VIDEO_MP4) },
                onFavoriteClick = null
            )
        }
    }
}

@Composable
private fun SearchAndDownloadScreen(
    query: String,
    isSearching: Boolean,
    results: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onQueryChange: (String) -> Unit,
    onSearchSubmit: () -> Unit,
    onPlayTrack: (GoatTrack, Boolean) -> Unit,
    onDownloadTrack: (GoatTrack, MediaFormatType) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit
) {
    val focusManager = LocalFocusManager.current

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = {
                Text("YouTube'da şarkı, sanatçı veya klip ara...", color = MutedSilver)
            },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = NeonSapphire)
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Temizle", tint = MutedSilver)
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focusManager.clearFocus()
                onSearchSubmit()
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CardMidnightBlue,
                unfocusedContainerColor = DeepSlateBlack,
                focusedBorderColor = ElectricCobalt,
                unfocusedBorderColor = SurfaceSteelBlue,
                focusedTextColor = PureIceWhite,
                unfocusedTextColor = PureIceWhite
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        )

        if (isSearching) {
            LinearProgressIndicator(
                color = NeonSapphire,
                trackColor = CardMidnightBlue,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(results, key = { it.id }) { track ->
                TrackRowItem(
                    track = track,
                    downloadState = downloads[track.id],
                    onPlayAudio = { onPlayTrack(track, false) },
                    onPlayVideo = { onPlayTrack(track, true) },
                    onDownloadAudio = { onDownloadTrack(track, MediaFormatType.AUDIO_M4A) },
                    onDownloadVideo = { onDownloadTrack(track, MediaFormatType.VIDEO_MP4) },
                    onFavoriteClick = { onToggleFavorite(track) }
                )
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    tracks: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onPlayTrack: (GoatTrack, Boolean) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onDeleteTrack: (GoatTrack) -> Unit
) {
    var filterMode by remember { mutableIntStateOf(0) }

    val filtered = remember(tracks, filterMode) {
        when (filterMode) {
            1 -> tracks.filter { it.isDownloadedAudio || it.isDownloadedVideo }
            2 -> tracks.filter { it.isFavorite }
            else -> tracks
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Kitaplığım (${filtered.size})",
                color = PureIceWhite,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filterMode == 0,
                onClick = { filterMode = 0 },
                label = { Text("Tümü") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ElectricCobalt,
                    selectedLabelColor = PureIceWhite
                )
            )
            FilterChip(
                selected = filterMode == 1,
                onClick = { filterMode = 1 },
                label = { Text("İndirilenler (Çevrimdışı)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ElectricCobalt,
                    selectedLabelColor = PureIceWhite
                )
            )
            FilterChip(
                selected = filterMode == 2,
                onClick = { filterMode = 2 },
                label = { Text("Favoriler") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ElectricCobalt,
                    selectedLabelColor = PureIceWhite
                )
            )
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.art_default_cover),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(150.dp)
                            .clip(RoundedCornerShape(18.dp))
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Henüz kaydedilmiş şarkı yok",
                        color = PureIceWhite,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Ara & İndir sekmesinden istediğin şarkıyı M4A ses veya MP4 video olarak telefonuna indirebilirsin.",
                        color = MutedSilver,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(filtered, key = { it.id }) { track ->
                    TrackRowItem(
                        track = track,
                        downloadState = downloads[track.id],
                        onPlayAudio = { onPlayTrack(track, false) },
                        onPlayVideo = { onPlayTrack(track, true) },
                        onDownloadAudio = null,
                        onDownloadVideo = null,
                        onFavoriteClick = { onToggleFavorite(track) },
                        onDeleteClick = { onDeleteTrack(track) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TrackRowItem(
    track: GoatTrack,
    downloadState: DownloadTaskState?,
    onPlayAudio: () -> Unit,
    onPlayVideo: () -> Unit,
    onDownloadAudio: (() -> Unit)?,
    onDownloadVideo: (() -> Unit)?,
    onFavoriteClick: (() -> Unit)?,
    onDeleteClick: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(DeepSlateBlack)
            .clickable { onPlayAudio() }
            .padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(60.dp)) {
                AsyncImage(
                    model = track.thumbnailUrl,
                    placeholder = painterResource(id = R.drawable.art_default_cover),
                    error = painterResource(id = R.drawable.art_default_cover),
                    contentDescription = track.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(8.dp))
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .background(ObsidianBlack.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = track.durationText,
                        color = PureIceWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    color = PureIceWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (track.isDownloadedAudio) {
                        Text(
                            text = "M4A İNDİRİLDİ • ",
                            color = EmeraldSuccess,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (track.isDownloadedVideo) {
                        Text(
                            text = "MP4 İNDİRİLDİ • ",
                            color = NeonSapphire,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = track.artist,
                        color = MutedSilver,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(onClick = onPlayVideo) {
                Icon(
                    imageVector = Icons.Default.OndemandVideo,
                    contentDescription = "Klibi Oynat",
                    tint = NeonSapphire
                )
            }

            if (onFavoriteClick != null) {
                IconButton(onClick = onFavoriteClick) {
                    Icon(
                        imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favori",
                        tint = if (track.isFavorite) CrimsonAccent else MutedSilver
                    )
                }
            }

            if (onDeleteClick != null) {
                IconButton(onClick = onDeleteClick) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Sil",
                        tint = MutedSilver
                    )
                }
            }
        }

        if (onDownloadAudio != null || onDownloadVideo != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { onDownloadAudio?.invoke() },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        tint = NeonSapphire,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (track.isDownloadedAudio) "Ses Hazır (M4A)" else "Ses İndir (M4A)",
                        color = PureIceWhite,
                        fontSize = 12.sp
                    )
                }

                OutlinedButton(
                    onClick = { onDownloadVideo?.invoke() },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = null,
                        tint = ElectricCobalt,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (track.isDownloadedVideo) "Video Hazır (MP4)" else "Video İndir (MP4)",
                        color = PureIceWhite,
                        fontSize = 12.sp
                    )
                }
            }
        }

        if (downloadState != null) {
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { downloadState.progressPercent / 100f },
                color = if (downloadState.isFailed) CrimsonAccent else NeonSapphire,
                trackColor = CardMidnightBlue,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = downloadState.statusText,
                color = if (downloadState.isFailed) CrimsonAccent else NeonSapphire,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun MiniPlayerBar(
    track: GoatTrack,
    isPlaying: Boolean,
    isBuffering: Boolean,
    positionMs: Long,
    durationMs: Long,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onOpenFullPlayer: () -> Unit
) {
    val progress = (positionMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(CardMidnightBlue)
            .clickable { onOpenFullPlayer() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = track.thumbnailUrl,
                placeholder = painterResource(id = R.drawable.art_default_cover),
                error = painterResource(id = R.drawable.art_default_cover),
                contentDescription = track.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    color = PureIceWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (isBuffering) "Akış bağlanıyor..." else track.artist,
                    color = NeonSapphire,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onTogglePlay) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                    contentDescription = "Oynat/Duraklat",
                    tint = PureIceWhite,
                    modifier = Modifier.size(34.dp)
                )
            }
            IconButton(onClick = onNext) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Sonraki",
                    tint = PureIceWhite
                )
            }
        }
        LinearProgressIndicator(
            progress = { progress },
            color = NeonSapphire,
            trackColor = DeepSlateBlack,
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
        )
    }
}

@Composable
private fun FullScreenPlayerModal(
    track: GoatTrack,
    vm: GoatViewModel,
    isPlaying: Boolean,
    isBuffering: Boolean,
    isVideoMode: Boolean,
    positionMs: Long,
    durationMs: Long,
    downloadState: DownloadTaskState?,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(CardMidnightBlue, DeepSlateBlack, ObsidianBlack)
                )
            )
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Küçült",
                        tint = PureIceWhite,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Text(
                    text = if (isVideoMode) "GOAT VIDEO ÇALAR" else "GOAT MUSIC ÇALAR",
                    color = NeonSapphire,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                TextButton(onClick = { vm.toggleVideoMode() }) {
                    Text(
                        text = if (isVideoMode) "Sese Geç" else "Klibi Aç",
                        color = PureIceWhite,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(310.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(ObsidianBlack)
                    .border(1.dp, SurfaceSteelBlue, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (isVideoMode) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                player = vm.exoPlayer
                                useController = false
                            }
                        },
                        update = { view ->
                            view.player = vm.exoPlayer
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    AsyncImage(
                        model = track.thumbnailUrl,
                        placeholder = painterResource(id = R.drawable.art_default_cover),
                        error = painterResource(id = R.drawable.art_default_cover),
                        contentDescription = track.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        color = PureIceWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = track.artist,
                        color = NeonSapphire,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                IconButton(onClick = { vm.toggleFavorite(track) }) {
                    Icon(
                        imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favori",
                        tint = if (track.isFavorite) CrimsonAccent else PureIceWhite,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            val sliderPos = (positionMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
            Slider(
                value = sliderPos,
                onValueChange = { frac ->
                    vm.seekTo((frac * durationMs).toLong())
                },
                colors = SliderDefaults.colors(
                    thumbColor = NeonSapphire,
                    activeTrackColor = ElectricCobalt,
                    inactiveTrackColor = SurfaceSteelBlue
                )
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = formatMillis(positionMs), color = MutedSilver, fontSize = 12.sp)
                Text(text = formatMillis(durationMs), color = MutedSilver, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.playPreviousInLibrary() }) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Önceki",
                        tint = PureIceWhite,
                        modifier = Modifier.size(40.dp)
                    )
                }

                IconButton(
                    onClick = { vm.togglePlayPause() },
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(ElectricCobalt)
                ) {
                    if (isBuffering) {
                        CircularProgressIndicator(
                            color = PureIceWhite,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(32.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Oynat/Duraklat",
                            tint = PureIceWhite,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                IconButton(onClick = { vm.playNextInLibrary() }) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Sonraki",
                        tint = PureIceWhite,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { vm.downloadTrack(track, MediaFormatType.AUDIO_M4A) },
                    colors = ButtonDefaults.buttonColors(containerColor = CardMidnightBlue),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = NeonSapphire)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ses İndir (M4A)", color = PureIceWhite, fontSize = 13.sp)
                }
                Button(
                    onClick = { vm.downloadTrack(track, MediaFormatType.VIDEO_MP4) },
                    colors = ButtonDefaults.buttonColors(containerColor = CardMidnightBlue),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Videocam, contentDescription = null, tint = ElectricCobalt)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Video İndir (MP4)", color = PureIceWhite, fontSize = 13.sp)
                }
            }

            if (downloadState != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = downloadState.statusText,
                    color = NeonSapphire,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

private fun formatMillis(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "%d:%02d".format(min, sec)
}
