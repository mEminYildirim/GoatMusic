@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class
)

package com.goatmusic.app.ui

import android.annotation.SuppressLint
import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.ui.platform.LocalContext
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import com.goatmusic.app.model.LyricLine
import java.util.Calendar
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.goatmusic.app.R
import com.goatmusic.app.data.LibraryRepository
import com.goatmusic.app.model.DownloadTaskState
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.MediaFormatType
import com.goatmusic.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun GoatMusicApp(vm: GoatViewModel) {
    var showSplash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(2200)
        showSplash = false
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var isFullPlayerOpen by remember { mutableStateOf(false) }
    var showBotShieldDialog by remember { mutableStateOf(false) }
    var playlistSheetTrack by remember { mutableStateOf<GoatTrack?>(null) }

    val searchQuery by vm.searchQuery.collectAsState()
    val activeCategoryTitle by vm.activeCategoryTitle.collectAsState()
    val isSearching by vm.isSearching.collectAsState()
    val searchResults by vm.searchResults.collectAsState()
    val libraryTracks by vm.libraryTracks.collectAsState()
    val similarTracks by vm.similarTracks.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val currentTrack by vm.currentTrack.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val isBuffering by vm.isBuffering.collectAsState()
    val isShuffleEnabled by vm.isShuffleEnabled.collectAsState()
    val isRepeatOneEnabled by vm.isRepeatOneEnabled.collectAsState()
    val currentLyrics by vm.currentLyrics.collectAsState()
    val isLoadingLyrics by vm.isLoadingLyrics.collectAsState()
    val lyricsOffsetMs by vm.lyricsOffsetMs.collectAsState()
    val context = LocalContext.current

    // Uygulama içindeyken geri tuşuna basıldığında uygulamayı öldürmek yerine arka plana al;
    // dinleme ekranındayken geri tuşuna basıldığında ise müziği alt çubuğa küçültüp uygulamada kal.
    BackHandler(enabled = !isFullPlayerOpen) {
        (context as? Activity)?.moveTaskToBack(true)
    }
    BackHandler(enabled = isFullPlayerOpen) {
        isFullPlayerOpen = false
    }
    val positionMs by vm.positionMs.collectAsState()
    val durationMs by vm.durationMs.collectAsState()
    val audioIntensity by vm.audioIntensity.collectAsState()
    val downloads by vm.downloads.collectAsState()
    val isBotShieldVerified by vm.isBotShieldVerified.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Scaffold(
            containerColor = ObsidianBlack,
            bottomBar = {
                Column(modifier = Modifier.background(ObsidianBlack)) {
                    if (currentTrack != null) {
                        MiniPlayerBar(
                            track = currentTrack!!,
                            isPlaying = isPlaying,
                            isBuffering = isBuffering,
                            positionMs = positionMs,
                            durationMs = durationMs,
                            onTogglePlay = { vm.togglePlayPause() },
                            onFavorite = { vm.toggleFavorite(currentTrack!!) },
                            onNext = { vm.playNextInQueue() },
                            onOpenFullPlayer = { isFullPlayerOpen = true }
                        )
                    }

                    // Gerçek Spotify Alt Sekme Çubuğu (Şeffaf İndikatörlü, İnce Çizgili)
                    HorizontalDivider(color = SurfaceSteelBlue.copy(alpha = 0.45f), thickness = 0.5.dp)
                    NavigationBar(
                        containerColor = ObsidianBlack,
                        tonalElevation = 0.dp,
                        modifier = Modifier.height(64.dp)
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Ana Sayfa", modifier = Modifier.size(24.dp)) },
                            label = { Text("Ana Sayfa", fontSize = 11.sp, fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SoftSkyBlue,
                                selectedTextColor = SoftSkyBlue,
                                unselectedIconColor = SubtleGray,
                                unselectedTextColor = SubtleGray,
                                indicatorColor = CardMidnightBlue
                            )
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.Search, contentDescription = "Ara", modifier = Modifier.size(24.dp)) },
                            label = { Text("Ara", fontSize = 11.sp, fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SoftSkyBlue,
                                selectedTextColor = SoftSkyBlue,
                                unselectedIconColor = SubtleGray,
                                unselectedTextColor = SubtleGray,
                                indicatorColor = CardMidnightBlue
                            )
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Kitaplığım", modifier = Modifier.size(24.dp)) },
                            label = { Text("Kitaplığım", fontSize = 11.sp, fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SoftSkyBlue,
                                selectedTextColor = SoftSkyBlue,
                                unselectedIconColor = SubtleGray,
                                unselectedTextColor = SubtleGray,
                                indicatorColor = CardMidnightBlue
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    0 -> HomeScreen(
                        isBotShieldVerified = isBotShieldVerified,
                        currentPlayingId = currentTrack?.id,
                        libraryTracks = libraryTracks,
                        similarTracks = similarTracks,
                        downloads = downloads,
                        onOpenBotShield = { showBotShieldDialog = true },
                        onPlayTrack = {
                            track, queue ->
                            vm.playTrack(track, false, queue)
                            isFullPlayerOpen = true
                        },
                        onDownloadTrack = { track, fmt -> vm.downloadTrack(track, fmt) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onOpenPlaylistSheet = { playlistSheetTrack = it },
                        onGoToSearch = { selectedTab = 1 }
                    )
                    1 -> SearchAndDownloadScreen(
                        query = searchQuery,
                        activeCategoryTitle = activeCategoryTitle,
                        isSearching = isSearching,
                        currentPlayingId = currentTrack?.id,
                        results = searchResults,
                        downloads = downloads,
                        onQueryChange = { vm.onSearchQueryChange(it) },
                        onSearchSubmit = { vm.performSearch(searchQuery) },
                        onSelectCategory = { title, q -> vm.selectSearchCategory(title, q) },
                        onClearCategory = { vm.clearSelectedCategory() },
                        onPlayTrack = {
                            track ->
                            vm.playTrack(track, false, searchResults)
                            isFullPlayerOpen = true
                        },
                        onPlayVideo = { track ->
                            vm.playTrack(track, true, searchResults)
                            isFullPlayerOpen = true
                        },
                        onDownloadTrack = { track, fmt -> vm.downloadTrack(track, fmt) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onOpenPlaylistSheet = { playlistSheetTrack = it }
                    )
                    2 -> PlaylistsScreen(
                        playlists = playlists,
                        allTracks = libraryTracks,
                        currentPlayingId = currentTrack?.id,
                        isShuffleEnabled = isShuffleEnabled,
                        downloads = downloads,
                        onCreatePlaylist = { vm.createPlaylist(it) },
                        onDeletePlaylist = { vm.deleteCustomPlaylist(it) },
                        onPlayTrack = {
                            track, queue ->
                            vm.playTrack(track, false, queue)
                            isFullPlayerOpen = true
                        },
                        onShufflePlay = {
                            queue ->
                            vm.shufflePlayPlaylist(queue)
                            isFullPlayerOpen = true
                        },
                        onPlayInOrder = {
                            queue ->
                            vm.playPlaylistInOrder(queue)
                            isFullPlayerOpen = true
                        },
                        onDownloadTrack = { track, fmt -> vm.downloadTrack(track, fmt) },
                        onToggleFavorite = { vm.toggleFavorite(it) },
                        onRemoveFromPlaylist = { plId, track -> vm.toggleTrackInPlaylist(plId, track) },
                        onAddMultipleToPlaylist = { plId, selectedTracks ->
                            vm.addMultipleTracksToPlaylist(plId, selectedTracks)
                        },
                        onReorderTracks = { plId, fromIdx, toIdx, ids ->
                            vm.reorderPlaylistTracks(plId, fromIdx, toIdx, ids)
                        }
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = isFullPlayerOpen && currentTrack != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            if (currentTrack != null) {
                FullScreenPlayerModal(
                    track = currentTrack!!,
                    vm = vm,
                    isPlaying = isPlaying,
                    isBuffering = isBuffering,
                    isRepeatOneEnabled = isRepeatOneEnabled,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    audioIntensity = audioIntensity,
                    lyrics = currentLyrics,
                    isLoadingLyrics = isLoadingLyrics,
                    lyricsOffsetMs = lyricsOffsetMs,
                    onAdjustLyricsOffset = { vm.adjustLyricsOffset(it) },
                    onResetLyricsOffset = { vm.resetLyricsOffset() },
                    onOpenPlaylistSheet = { playlistSheetTrack = currentTrack },
                    onClose = { isFullPlayerOpen = false }
                )
            }
        }

        if (playlistSheetTrack != null) {
            QuickPlaylistDialog(
                track = playlistSheetTrack!!,
                playlists = playlists,
                onTogglePlaylist = { plId ->
                    vm.toggleTrackInPlaylist(plId, playlistSheetTrack!!)
                },
                onCreateNewPlaylist = { name ->
                    vm.createPlaylist(name)
                },
                onDismiss = { playlistSheetTrack = null }
            )
        }

        if (showBotShieldDialog) {
            BotShieldWebViewDialog(
                onDismiss = {
                    CookieManager.getInstance().flush()
                    vm.refreshBotShieldState()
                    showBotShieldDialog = false
                }
            )
        }

        AnimatedVisibility(
            visible = showSplash,
            enter = fadeIn(),
            exit = fadeOut(animationSpec = tween(450))
        ) {
            GoatIntroSplash()
        }
    }
}

@Composable
private fun GoatIntroSplash() {
    val infiniteTransition = rememberInfiniteTransition(label = "splash_wave")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.283f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(850, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logo_pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.goat_logo_upper),
                contentDescription = "Goat Music",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(104.dp)
                    .scale(pulse)
                    .clip(CircleShape)
                    .border(2.dp, NeonSapphire, CircleShape)
            )

            Spacer(modifier = Modifier.height(26.dp))

            Canvas(
                modifier = Modifier
                    .width(160.dp)
                    .height(34.dp)
            ) {
                val barCount = 19
                val spacing = size.width / barCount
                val barWidth = spacing * 0.55f
                for (i in 0 until barCount) {
                    val norm = 0.22f + 0.78f * abs(sin(phase + i * 0.42f))
                    val barH = size.height * norm
                    val topY = (size.height - barH) / 2f
                    drawRoundRect(
                        color = NeonSapphire,
                        topLeft = Offset(i * spacing, topY),
                        size = Size(barWidth, barH),
                        cornerRadius = CornerRadius(6f, 6f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Text(
                text = "Hoşgeldin Agam",
                color = PureIceWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.4.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "created by Mami",
                color = MutedSilver,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.2.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Gercek PCM ses siddetine (GoatAudioLevelSink) bagli olarak yumusakca yukselen ve alcalan
 * stüdyo tipi ses dalgasi cubugu.
 */
/**
 * İlerleme çubuğundaki MEVCUT GÖSTERGENİN (playhead / aktif uç) o anki sesin şiddetine göre
 * yükselip alçaldığı, ses sakinleştiğinde küçülüp ses yükseldiğinde büyüyüp dalgalandığı
 * özel müzik ilerleme çubuğu.
 */
@Composable
fun RealAudioLoudnessSeekbar(
    progress: Float,
    audioIntensity: Float,
    onSeek: (Float) -> Unit,
    onScrubPreview: ((Float?) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubFraction by remember { mutableFloatStateOf(progress.coerceIn(0f, 1f)) }
    var lastCommitTimeMs by remember { mutableLongStateOf(0L) }

    // Kullanıcı elini çubuktan çektiğinde ExoPlayer yeni saniyeye odaklanana kadar (280ms)
    // göstergenin eski konuma sıçramasını engelle:
    val nowMs = System.currentTimeMillis()
    val effectiveProgress = if (isScrubbing || (nowMs - lastCommitTimeMs) < 280L) {
        scrubFraction.coerceIn(0f, 1f)
    } else {
        progress.coerceIn(0f, 1f)
    }

    val animatedIntensity by animateFloatAsState(
        targetValue = audioIntensity.coerceIn(0f, 1f),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "indicator_intensity"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    isScrubbing = true
                    var currentFrac = (down.position.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                    scrubFraction = currentFrac
                    onScrubPreview?.invoke(currentFrac)

                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull() ?: break
                        if (change.pressed) {
                            currentFrac = (change.position.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                            scrubFraction = currentFrac
                            onScrubPreview?.invoke(currentFrac)
                            change.consume()
                        }
                    } while (event.changes.any { it.pressed })

                    lastCommitTimeMs = System.currentTimeMillis()
                    isScrubbing = false
                    onScrubPreview?.invoke(null)
                    onSeek(currentFrac)
                }
            }
    ) {
        val centerY = size.height / 2f
        val baseStroke = 4.dp.toPx()
        val activeStroke = baseStroke + (3.dp.toPx() * animatedIntensity)
        val thumbX = (size.width * effectiveProgress)

        // 1. Sağ taraf (henüz çalınmamış kısım) — İnce koyu mavi-gri iz
        drawRoundRect(
            color = SurfaceSteelBlue,
            topLeft = Offset(x = thumbX, y = centerY - baseStroke / 2f),
            size = Size(width = (size.width - thumbX).coerceAtLeast(0f), height = baseStroke),
            cornerRadius = CornerRadius(baseStroke, baseStroke)
        )

        // 2. Sol taraf (çalınmış kısım) — Ritimle hafifçe parlayan ve kalınlaşan mavi bar
        if (thumbX > 0f) {
            if (animatedIntensity > 0.08f) {
                val glowStroke = activeStroke + (8.dp.toPx() * animatedIntensity)
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            ElectricCobalt.copy(alpha = 0.22f * animatedIntensity),
                            SoftSkyBlue.copy(alpha = 0.45f * animatedIntensity)
                        ),
                        startX = 0f,
                        endX = thumbX.coerceAtLeast(1f)
                    ),
                    topLeft = Offset(x = 0f, y = centerY - glowStroke / 2f),
                    size = Size(width = thumbX, height = glowStroke),
                    cornerRadius = CornerRadius(glowStroke, glowStroke)
                )
            }

            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(ElectricCobalt, NeonSapphire, SoftSkyBlue),
                    startX = 0f,
                    endX = thumbX.coerceAtLeast(1f)
                ),
                topLeft = Offset(x = 0f, y = centerY - activeStroke / 2f),
                size = Size(width = thumbX, height = activeStroke),
                cornerRadius = CornerRadius(activeStroke, activeStroke)
            )
        }

        // 3. MEVCUT GÖSTERGE (Playhead): Ritimle ve ses şiddetiyle büyüyüp küçülen pürüzsüz ışıklı gösterge
        val baseThumbRadius = 6.dp.toPx()
        val pulseThumbRadius = baseThumbRadius + (5.dp.toPx() * animatedIntensity)
        val outerRingRadius = pulseThumbRadius + (11.dp.toPx() * animatedIntensity)

        // Dış ses şiddeti halkası (Ritim vurdukça genişler)
        if (animatedIntensity > 0.04f) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        SoftSkyBlue.copy(alpha = 0.55f * animatedIntensity),
                        NeonSapphire.copy(alpha = 0.20f * animatedIntensity),
                        Color.Transparent
                    ),
                    center = Offset(thumbX, centerY),
                    radius = outerRingRadius.coerceAtLeast(1f)
                ),
                radius = outerRingRadius,
                center = Offset(thumbX, centerY)
            )
        }

        // Gösterge üzerindeki dikey ritim kapsülü (Ses yükseldikçe zarifçe uzar)
        val capsuleHeight = (pulseThumbRadius * 2f) + (16.dp.toPx() * animatedIntensity)
        val capsuleWidth = (pulseThumbRadius * 1.35f).coerceAtLeast(10.dp.toPx())
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(SoftSkyBlue, PureIceWhite, SoftSkyBlue),
                startY = centerY - capsuleHeight / 2f,
                endY = centerY + capsuleHeight / 2f
            ),
            topLeft = Offset(
                x = (thumbX - capsuleWidth / 2f).coerceIn(0f, (size.width - capsuleWidth).coerceAtLeast(0f)),
                y = centerY - capsuleHeight / 2f
            ),
            size = Size(width = capsuleWidth, height = capsuleHeight),
            cornerRadius = CornerRadius(capsuleWidth, capsuleWidth)
        )
    }
}

@Composable
private fun HomeScreen(
    isBotShieldVerified: Boolean,
    currentPlayingId: String?,
    libraryTracks: List<GoatTrack>,
    similarTracks: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onOpenBotShield: () -> Unit,
    onPlayTrack: (GoatTrack, List<GoatTrack>) -> Unit,
    onDownloadTrack: (GoatTrack, MediaFormatType) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onOpenPlaylistSheet: (GoatTrack) -> Unit,
    onGoToSearch: () -> Unit
) {
    val recentlyPlayed = remember(libraryTracks) {
        libraryTracks.filter { it.lastPlayedAt > 0L }.sortedByDescending { it.lastPlayedAt }.take(12)
    }
    val mostPlayed = remember(libraryTracks) {
        libraryTracks.filter { it.playCount > 0 }.sortedByDescending { it.playCount }.take(8)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        // Mevcut saate göre Spotify tarzı karşılama ve saatin temasına uygun koyu-mavi atmosfer
        item {
            val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
            val greetingText = when (hour) {
                in 5..10 -> "Hayırlı Sabahlar"
                in 11..16 -> "Hayırlı Günler"
                in 17..21 -> "Hayırlı Akşamlar"
                else -> "Hayırlı Geceler"
            }
            val greetingGlowColor = when (hour) {
                in 5..10 -> Color(0xFF1A3158) // Sabah: yumuşak şafak mavisi
                in 11..16 -> Color(0xFF153468) // Gündüz: canlı safir mavisi
                in 17..21 -> Color(0xFF1D2452) // Akşam: alacakaranlık indigo-mavi
                else -> Color(0xFF0D1A36)      // Gece: derin gece mavisi
            }
            val greetingAccentColor = when (hour) {
                in 5..10 -> Color(0xFF7DD3FC)
                in 11..16 -> Color(0xFF60A5FA)
                in 17..21 -> Color(0xFF93C5FD)
                else -> Color(0xFF38BDF8)
            }

            var greetingEntered by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                greetingEntered = true
            }
            val entranceAlpha by animateFloatAsState(
                targetValue = if (greetingEntered) 1f else 0f,
                animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
                label = "greeting_enter_alpha"
            )
            val entranceOffsetX by animateFloatAsState(
                targetValue = if (greetingEntered) 0f else -18f,
                animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
                label = "greeting_enter_offset"
            )
            val shimmerTransition = rememberInfiniteTransition(label = "greeting_shimmer")
            val shimmerPhase by shimmerTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1000f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 3200, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "shimmer_phase"
            )
            val glowAlpha by shimmerTransition.animateFloat(
                initialValue = 0.55f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 1900, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "glow_alpha"
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(greetingGlowColor, DeepSlateBlack.copy(alpha = 0.65f), ObsidianBlack)
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.goat_logo_upper),
                            contentDescription = "Goat Music",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .border(1.dp, greetingAccentColor.copy(alpha = 0.6f), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Goat Music",
                            color = PureIceWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = onOpenBotShield) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Bağlantı Kalkanı",
                            tint = if (isBotShieldVerified) EmeraldSuccess else MutedSilver,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Biraz daha aşağıda ve biraz sağa kaydırılmış, girişte ve sonrasında optimize şekilde parlayan karşılama başlığı
                Spacer(modifier = Modifier.height(28.dp))

                Column(
                    modifier = Modifier
                        .padding(start = 12.dp)
                        .graphicsLayer {
                            alpha = entranceAlpha
                            translationX = entranceOffsetX
                        }
                ) {
                    Text(
                        text = greetingText,
                        style = androidx.compose.ui.text.TextStyle(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    greetingAccentColor,
                                    PureIceWhite.copy(alpha = glowAlpha),
                                    greetingAccentColor
                                ),
                                start = Offset(shimmerPhase - 260f, 0f),
                                end = Offset(shimmerPhase + 260f, 40f)
                            ),
                            fontSize = 30.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.4.sp
                        )
                    )

                }

                Spacer(modifier = Modifier.height(14.dp))
            }
        }

        if (recentlyPlayed.isEmpty() && mostPlayed.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = SubtleGray,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Henüz şarkı dinlemedin",
                        color = PureIceWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Dinlediğin şarkılar, en çok çaldıkların ve zevkine uygun öneriler burada listelenir.",
                        color = MutedSilver,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = onGoToSearch,
                        colors = ButtonDefaults.buttonColors(containerColor = PureIceWhite),
                        shape = RoundedCornerShape(24.dp),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp)
                    ) {
                        Text("Şarkı Ara", color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        // 1. Son Dinlenilenler
        if (recentlyPlayed.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 4.dp)) {
                    Text(
                        text = "Son dinlenilenler",
                        color = PureIceWhite,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(recentlyPlayed, key = { "rec_" + it.id }) { track ->
                            Column(
                                modifier = Modifier
                                    .width(128.dp)
                                    .clickable { onPlayTrack(track, recentlyPlayed) }
                            ) {
                                AsyncImage(
                                    model = track.thumbnailUrl,
                                    placeholder = painterResource(id = R.drawable.art_default_cover),
                                    error = painterResource(id = R.drawable.art_default_cover),
                                    contentDescription = track.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(128.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = track.title,
                                    color = if (track.id == currentPlayingId) NeonSapphire else PureIceWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = track.artist,
                                    color = MutedSilver,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. En Çok Dinlediklerin
        if (mostPlayed.isNotEmpty()) {
            item {
                Text(
                    text = "En çok dinlediklerin",
                    color = PureIceWhite,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 26.dp, bottom = 6.dp)
                )
            }
            items(mostPlayed, key = { "most_" + it.id }) { track ->
                CleanSpotifyTrackRow(
                    track = track,
                    isPlayingNow = track.id == currentPlayingId,
                    subtitlePrefix = "${track.playCount} dinleme",
                    activeDownload = downloads[track.id],
                    onRowClick = { onPlayTrack(track, mostPlayed) },
                    onFavoriteClick = { onToggleFavorite(track) },
                    onAddToPlaylistClick = { onOpenPlaylistSheet(track) },
                    onDownloadAudioClick = { onDownloadTrack(track, MediaFormatType.AUDIO_M4A) },
                    onDownloadVideoClick = null,
                    onRemoveClick = null
                )
            }
        }

        // 3. Benzer Şarkılar
        if (similarTracks.isNotEmpty()) {
            item {
                Text(
                    text = "Son dinlediklerine benzer",
                    color = PureIceWhite,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 26.dp, bottom = 6.dp)
                )
            }
            items(similarTracks, key = { "sim_" + it.id }) { track ->
                CleanSpotifyTrackRow(
                    track = track,
                    isPlayingNow = track.id == currentPlayingId,
                    subtitlePrefix = null,
                    activeDownload = downloads[track.id],
                    onRowClick = { onPlayTrack(track, similarTracks) },
                    onFavoriteClick = { onToggleFavorite(track) },
                    onAddToPlaylistClick = { onOpenPlaylistSheet(track) },
                    onDownloadAudioClick = { onDownloadTrack(track, MediaFormatType.AUDIO_M4A) },
                    onDownloadVideoClick = null,
                    onRemoveClick = null
                )
            }
        }
    }
}

private data class GoatCatalogCategory(
    val title: String,
    val searchQuery: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val badgeText: String
)

private val GOAT_SEARCH_CATEGORIES = listOf(
    GoatCatalogCategory(
        title = "Şu An Popüler",
        searchQuery = "2026 güncel popüler hit şarkılar",
        primaryColor = Color(0xFF1D4ED8),
        secondaryColor = Color(0xFF38BDF8),
        badgeText = "TOP"
    ),
    GoatCatalogCategory(
        title = "Rahat",
        searchQuery = "chill rahatlatıcı şarkılar mix",
        primaryColor = Color(0xFF0F766E),
        secondaryColor = Color(0xFF2DD4BF),
        badgeText = "CHILL"
    ),
    GoatCatalogCategory(
        title = "Pop",
        searchQuery = "popüler türkçe ve yabancı pop hit şarkılar",
        primaryColor = Color(0xFF9333EA),
        secondaryColor = Color(0xFFC084FC),
        badgeText = "POP"
    ),
    GoatCatalogCategory(
        title = "Rap",
        searchQuery = "türkçe rap popüler hit parçalar",
        primaryColor = Color(0xFFB91C1C),
        secondaryColor = Color(0xFFF87171),
        badgeText = "RAP"
    ),
    GoatCatalogCategory(
        title = "Odaklanmak\nİçin",
        searchQuery = "odaklanma ders çalışma müzikleri lofi focus",
        primaryColor = Color(0xFF3730A3),
        secondaryColor = Color(0xFF818CF8),
        badgeText = "FOCUS"
    ),
    GoatCatalogCategory(
        title = "Anime",
        searchQuery = "popular anime openings ost songs",
        primaryColor = Color(0xFFBE185D),
        secondaryColor = Color(0xFFF472B6),
        badgeText = "ANIME"
    ),
    GoatCatalogCategory(
        title = "Uyku",
        searchQuery = "uyurken dinlemelik sakin uyku müziği",
        primaryColor = Color(0xFF1E293B),
        secondaryColor = Color(0xFF60A5FA),
        badgeText = "SLEEP"
    ),
    GoatCatalogCategory(
        title = "Antrenman",
        searchQuery = "gym workout phonk yüksek enerjili müzikler",
        primaryColor = Color(0xFFB45309),
        secondaryColor = Color(0xFFFBBF24),
        badgeText = "GYM"
    ),
    GoatCatalogCategory(
        title = "Gece Sürüşü",
        searchQuery = "gece sürüş müzikleri night drive mix",
        primaryColor = Color(0xFF0369A1),
        secondaryColor = Color(0xFF38BDF8),
        badgeText = "DRIVE"
    ),
    GoatCatalogCategory(
        title = "Akustik",
        searchQuery = "akustik şarkılar duygusal cover",
        primaryColor = Color(0xFF047857),
        secondaryColor = Color(0xFF34D399),
        badgeText = "LIVE"
    ),
    GoatCatalogCategory(
        title = "Rock",
        searchQuery = "rock klasikleri ve alternatif rock şarkılar",
        primaryColor = Color(0xFF7F1D1D),
        secondaryColor = Color(0xFFEF4444),
        badgeText = "ROCK"
    ),
    GoatCatalogCategory(
        title = "Elektronik",
        searchQuery = "electronic dance music club remix hit",
        primaryColor = Color(0xFF4C1D95),
        secondaryColor = Color(0xFFA78BFA),
        badgeText = "EDM"
    )
)

@Composable
private fun SearchAndDownloadScreen(
    query: String,
    activeCategoryTitle: String?,
    isSearching: Boolean,
    currentPlayingId: String?,
    results: List<GoatTrack>,
    downloads: Map<String, DownloadTaskState>,
    onQueryChange: (String) -> Unit,
    onSearchSubmit: () -> Unit,
    onSelectCategory: (String, String) -> Unit,
    onClearCategory: () -> Unit,
    onPlayTrack: (GoatTrack) -> Unit,
    onPlayVideo: (GoatTrack) -> Unit,
    onDownloadTrack: (GoatTrack, MediaFormatType) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onOpenPlaylistSheet: (GoatTrack) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val showCatalogGrid = query.isBlank() && activeCategoryTitle == null
    BackHandler(enabled = !showCatalogGrid) {
        onQueryChange("")
        onClearCategory()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Ara",
            color = PureIceWhite,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)
        )

        // Spotify tarzı belirgin arama çubuğu
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = {
                Text("Ne dinlemek istiyorsun?", color = ObsidianBlack.copy(alpha = 0.65f), fontSize = 15.sp, fontWeight = FontWeight.Medium)
            },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = ObsidianBlack)
            },
            trailingIcon = {
                if (query.isNotEmpty() || activeCategoryTitle != null) {
                    IconButton(
                        onClick = {
                            onQueryChange("")
                            onClearCategory()
                        }
                    ) {
                        Icon(Icons.Default.Clear, contentDescription = "Temizle", tint = ObsidianBlack)
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focusManager.clearFocus()
                onSearchSubmit()
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = PureIceWhite,
                unfocusedContainerColor = PureIceWhite,
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent,
                focusedTextColor = ObsidianBlack,
                unfocusedTextColor = ObsidianBlack,
                cursorColor = ElectricCobalt
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        )

        if (isSearching) {
            LinearProgressIndicator(
                color = SoftSkyBlue,
                trackColor = Color.Transparent,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .padding(horizontal = 16.dp)
            )
        }

        if (showCatalogGrid) {
            // --- SPOTIFY TARZI 2 SÜTUNLU KARE/DİKDÖRTGEN KATEGORİ KATALOĞU ---
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "Hepsine göz at",
                        color = PureIceWhite,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }

                val rowPairs = GOAT_SEARCH_CATEGORIES.chunked(2)
                items(rowPairs.size, key = { "cat_row_$it" }) { rowIdx ->
                    val pair = rowPairs[rowIdx]
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (cat in pair) {
                            SpotifyCategoryCard(
                                category = cat,
                                onClick = {
                                    focusManager.clearFocus()
                                    onSelectCategory(cat.title.replace("\n", " "), cat.searchQuery)
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        } else {
            // Seçilen kategori başlığı (tıklanınca geri dönülebilir)
            if (activeCategoryTitle != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onClearCategory() }
                            .padding(vertical = 4.dp, horizontal = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Kategorilere Dön",
                            tint = SoftSkyBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = activeCategoryTitle,
                            color = PureIceWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    TextButton(onClick = onClearCategory) {
                        Text("Kategoriler", color = SoftSkyBlue, fontSize = 13.sp)
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp)
            ) {
                items(results, key = { it.id }) { track ->
                    CleanSpotifyTrackRow(
                        track = track,
                        isPlayingNow = track.id == currentPlayingId,
                        subtitlePrefix = track.durationText,
                        activeDownload = downloads[track.id],
                        onRowClick = { onPlayTrack(track) },
                        onFavoriteClick = { onToggleFavorite(track) },
                        onAddToPlaylistClick = { onOpenPlaylistSheet(track) },
                        onDownloadAudioClick = { onDownloadTrack(track, MediaFormatType.AUDIO_M4A) },
                        onDownloadVideoClick = { onDownloadTrack(track, MediaFormatType.VIDEO_MP4) },
                        onPlayVideoClick = { onPlayVideo(track) },
                        onRemoveClick = null
                    )
                }
            }
        }
    }
}

@Composable
private fun SpotifyCategoryCard(
    category: GoatCatalogCategory,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(102.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(category.primaryColor, category.primaryColor.copy(alpha = 0.82f))
                )
            )
            .clickable { onClick() }
    ) {
        // Sağ alt köşede Spotify tarzı 24 derece eğimli albüm/katalog plağı
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = 14.dp, y = 12.dp)
                .size(68.dp)
                .graphicsLayer {
                    rotationZ = 24f
                }
                .clip(RoundedCornerShape(6.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(category.secondaryColor, ObsidianBlack.copy(alpha = 0.88f))
                    )
                )
                .border(1.dp, PureIceWhite.copy(alpha = 0.22f), RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Album,
                    contentDescription = null,
                    tint = PureIceWhite.copy(alpha = 0.85f),
                    modifier = Modifier.size(26.dp)
                )
                Text(
                    text = category.badgeText,
                    color = PureIceWhite,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.8.sp
                )
            }
        }

        // Sol üst: Kategori Başlığı (Kelimelerin ortadan bölünmemesi için geniş üst alan)
        Text(
            text = category.title,
            color = PureIceWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.ExtraBold,
            lineHeight = 19.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 12.dp, top = 12.dp, end = 14.dp)
        )
    }
}

@Composable
private fun PlaylistsScreen(
    playlists: List<GoatPlaylist>,
    allTracks: List<GoatTrack>,
    currentPlayingId: String?,
    isShuffleEnabled: Boolean,
    downloads: Map<String, DownloadTaskState>,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onPlayTrack: (GoatTrack, List<GoatTrack>) -> Unit,
    onShufflePlay: (List<GoatTrack>) -> Unit,
    onPlayInOrder: (List<GoatTrack>) -> Unit,
    onDownloadTrack: (GoatTrack, MediaFormatType) -> Unit,
    onToggleFavorite: (GoatTrack) -> Unit,
    onRemoveFromPlaylist: (String, GoatTrack) -> Unit,
    onAddMultipleToPlaylist: (String, List<GoatTrack>) -> Unit,
    onReorderTracks: (String, Int, Int, List<String>) -> Unit
) {
    // null ise Spotify tarzı aşağı doğru büyük kare/dikdörtgen Playlist Kartları listesi gösterilir;
    // bir playliste tıklandığında o playlistin tam ekran detay sayfası açılır.
    var openedPlaylistId by remember { mutableStateOf<String?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var showAddSongsPicker by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }

    val activePlaylist = playlists.find { it.id == openedPlaylistId }
    BackHandler(enabled = activePlaylist != null) {
        openedPlaylistId = null
    }
    val trackMap = remember(allTracks) { allTracks.associateBy { it.id } }

    var orderedTrackIds by remember(activePlaylist) {
        mutableStateOf(activePlaylist?.trackIds.orEmpty())
    }
    val activeTracks = remember(orderedTrackIds, trackMap) {
        orderedTrackIds.mapNotNull { trackMap[it] }
    }

    var draggedIndex by remember { mutableStateOf<Int?>(null) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    val rowHeightPx = with(LocalDensity.current) { 64.dp.toPx() }

    if (activePlaylist == null) {
        // --- EKRAN 1: SPOTIFY TARZI AŞAĞI DOĞRU BÜYÜK KARE / DİKDÖRTGEN PLAYLİST KARTLARI ---
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(AmbientBlueGlow.copy(alpha = 0.7f), ObsidianBlack)
                        )
                    )
                    .padding(start = 16.dp, end = 12.dp, top = 18.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.goat_logo_upper),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Kitaplığım",
                        color = PureIceWhite,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CardMidnightBlue),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceSteelBlue),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = SoftSkyBlue, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Yeni Liste", color = PureIceWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(playlists, key = { it.id }) { pl ->
                    val plTracks = pl.trackIds.mapNotNull { trackMap[it] }
                    val firstThumb = plTracks.firstOrNull()?.thumbnailUrl

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DeepSlateBlack)
                            .border(1.dp, SurfaceSteelBlue.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
                            .clickable { openedPlaylistId = pl.id }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Sol Büyük Kare Kapak (Spotify Tarzı 74x74 dp)
                        Box(
                            modifier = Modifier
                                .size(74.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    when (pl.id) {
                                        LibraryRepository.PLAYLIST_LIKED_ID -> Brush.linearGradient(
                                            colors = listOf(ElectricCobalt, NeonSapphire, SoftSkyBlue)
                                        )
                                        LibraryRepository.PLAYLIST_DOWNLOADED_ID -> Brush.linearGradient(
                                            colors = listOf(AmbientBlueGlow, ElectricCobalt, EmeraldSuccess)
                                        )
                                        else -> Brush.linearGradient(
                                            colors = listOf(CardMidnightBlue, SurfaceSteelBlue)
                                        )
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (pl.id == LibraryRepository.PLAYLIST_LIKED_ID) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = null,
                                    tint = PureIceWhite,
                                    modifier = Modifier.size(34.dp)
                                )
                            } else if (pl.id == LibraryRepository.PLAYLIST_DOWNLOADED_ID) {
                                Icon(
                                    imageVector = Icons.Default.DownloadDone,
                                    contentDescription = null,
                                    tint = PureIceWhite,
                                    modifier = Modifier.size(34.dp)
                                )
                            } else if (!firstThumb.isNullOrBlank()) {
                                AsyncImage(
                                    model = firstThumb,
                                    placeholder = painterResource(id = R.drawable.art_default_cover),
                                    error = painterResource(id = R.drawable.art_default_cover),
                                    contentDescription = pl.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.QueueMusic,
                                    contentDescription = null,
                                    tint = SoftSkyBlue,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Orta: Tam Playlist Adı (Asla yarım kesilmez!) ve Şarkı Sayısı
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = pl.name,
                                color = PureIceWhite,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Çalma Listesi • ${plTracks.size} şarkı",
                                color = MutedSilver,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Sağ: Hızlı Karışık Çal / Oynat Butonu
                        if (plTracks.isNotEmpty()) {
                            IconButton(
                                onClick = { onPlayInOrder(plTracks) },
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(ElectricCobalt)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Oynat",
                                    tint = PureIceWhite,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        } else {
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Aç",
                                tint = SubtleGray,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Text(
                text = "created by Mami",
                color = MutedSilver.copy(alpha = 0.65f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp, top = 8.dp)
            )
        }
    } else {
        // --- EKRAN 2: SEÇİLEN PLAYLİSTİN DETAY EKRANI (Tam Başlık, Rastgele Çal, Şarkı Ekle, Sürükle-Bırak) ---
        val removeMenuLabel = if (activePlaylist.id == LibraryRepository.PLAYLIST_DOWNLOADED_ID) {
            "Şarkıyı sil"
        } else {
            "Listeden kaldır"
        }

        Column(modifier = Modifier.fillMaxSize()) {
            // Üst Geri Dönüş ve Başlık Alanı (Tam genişlikte olduğu için isim asla kesilmez!)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(AmbientBlueGlow, DeepSlateBlack, ObsidianBlack)
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { openedPlaylistId = null }
                            .padding(vertical = 4.dp, horizontal = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Kitaplığa Dön",
                            tint = PureIceWhite,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Kitaplığım",
                            color = SoftSkyBlue,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (!activePlaylist.isSystemPlaylist) {
                        IconButton(
                            onClick = {
                                onDeletePlaylist(activePlaylist.id)
                                openedPlaylistId = null
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Listeyi Sil",
                                tint = MutedSilver
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tam Genişlikte Playlist İsmi ("Beğenilen Şarkılar" eksiksiz görünür)
                Text(
                    text = activePlaylist.name,
                    color = PureIceWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${activeTracks.size} şarkı • Sıralamak için basılı tutup sürükle",
                    color = MutedSilver,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Ayrı Aksiyon Çubuğu (Sol: + Şarkı Ekle, Sağ: Karışık Çal & Oynat)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (activePlaylist.id != LibraryRepository.PLAYLIST_DOWNLOADED_ID) {
                        OutlinedButton(
                            onClick = { showAddSongsPicker = true },
                            shape = RoundedCornerShape(20.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SoftSkyBlue.copy(alpha = 0.6f)),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = SoftSkyBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Şarkı Ekle", color = PureIceWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Rastgele Çal (Shuffle) Butonu
                        OutlinedButton(
                            onClick = { onShufflePlay(activeTracks) },
                            shape = RoundedCornerShape(20.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isShuffleEnabled) SoftSkyBlue else SurfaceSteelBlue
                            ),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isShuffleEnabled) CardMidnightBlue else Color.Transparent
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shuffle,
                                contentDescription = "Karışık Çal",
                                tint = if (isShuffleEnabled) SoftSkyBlue else PureIceWhite,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Rastgele Çal",
                                color = if (isShuffleEnabled) SoftSkyBlue else PureIceWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Sırayla Oynat Butonu
                        IconButton(
                            onClick = { onPlayInOrder(activeTracks) },
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(ElectricCobalt)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Oynat",
                                tint = PureIceWhite,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = SurfaceSteelBlue.copy(alpha = 0.4f), thickness = 0.5.dp)

            if (activeTracks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Bu çalma listesi boş",
                            color = PureIceWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (activePlaylist.id == LibraryRepository.PLAYLIST_DOWNLOADED_ID) {
                                "Ara sekmesinden indirdiğin şarkılar otomatik olarak burada yer alır."
                            } else {
                                "Üstteki 'Şarkı Ekle' butonuna dokunarak kayıtlı veya beğenilen şarkılarından seçim yapabilirsin."
                            },
                            color = MutedSilver,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 28.dp)
                ) {
                    itemsIndexed(activeTracks, key = { _, item -> item.id }) { index, track ->
                        val isBeingDragged = draggedIndex == index
                        Box(
                            modifier = Modifier
                                .zIndex(if (isBeingDragged) 5f else 0f)
                                .graphicsLayer {
                                    translationY = if (isBeingDragged) dragOffsetY else 0f
                                    scaleX = if (isBeingDragged) 1.02f else 1f
                                    scaleY = if (isBeingDragged) 1.02f else 1f
                                }
                                .background(if (isBeingDragged) CardMidnightBlue else Color.Transparent)
                                .pointerInput(orderedTrackIds.size, activePlaylist.id) {
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = {
                                            draggedIndex = index
                                            dragOffsetY = 0f
                                        },
                                        onDragEnd = {
                                            draggedIndex = null
                                            dragOffsetY = 0f
                                        },
                                        onDragCancel = {
                                            draggedIndex = null
                                            dragOffsetY = 0f
                                        },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            dragOffsetY += dragAmount.y
                                            val curIdx = draggedIndex ?: return@detectDragGesturesAfterLongPress
                                            if (dragOffsetY > rowHeightPx * 0.7f && curIdx < orderedTrackIds.lastIndex) {
                                                val targetIdx = curIdx + 1
                                                val currentIdsCopy = orderedTrackIds
                                                val mut = currentIdsCopy.toMutableList()
                                                val item = mut.removeAt(curIdx)
                                                mut.add(targetIdx, item)
                                                orderedTrackIds = mut
                                                draggedIndex = targetIdx
                                                dragOffsetY -= rowHeightPx
                                                onReorderTracks(activePlaylist.id, curIdx, targetIdx, currentIdsCopy)
                                            } else if (dragOffsetY < -rowHeightPx * 0.7f && curIdx > 0) {
                                                val targetIdx = curIdx - 1
                                                val currentIdsCopy = orderedTrackIds
                                                val mut = currentIdsCopy.toMutableList()
                                                val item = mut.removeAt(curIdx)
                                                mut.add(targetIdx, item)
                                                orderedTrackIds = mut
                                                draggedIndex = targetIdx
                                                dragOffsetY += rowHeightPx
                                                onReorderTracks(activePlaylist.id, curIdx, targetIdx, currentIdsCopy)
                                            }
                                        }
                                    )
                                }
                        ) {
                            CleanSpotifyTrackRow(
                                track = track,
                                isPlayingNow = track.id == currentPlayingId,
                                subtitlePrefix = null,
                                activeDownload = downloads[track.id],
                                showDragHandle = true,
                                removeActionLabel = removeMenuLabel,
                                onRowClick = { onPlayTrack(track, activeTracks) },
                                onFavoriteClick = { onToggleFavorite(track) },
                                onAddToPlaylistClick = null,
                                onDownloadAudioClick = if (activePlaylist.id != LibraryRepository.PLAYLIST_DOWNLOADED_ID) {
                                    { onDownloadTrack(track, MediaFormatType.AUDIO_M4A) }
                                } else null,
                                onDownloadVideoClick = null,
                                onRemoveClick = {
                                    onRemoveFromPlaylist(activePlaylist.id, track)
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddSongsPicker && activePlaylist != null) {
        MultiSelectSongsDialog(
            playlistName = activePlaylist.name,
            availableTracks = allTracks,
            alreadyInPlaylistIds = activePlaylist.trackIds.toSet(),
            onConfirmSelection = { chosenTracks ->
                onAddMultipleToPlaylist(activePlaylist.id, chosenTracks)
                showAddSongsPicker = false
            },
            onDismiss = { showAddSongsPicker = false }
        )
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = DeepSlateBlack,
            title = { Text("Yeni çalma listesi", color = PureIceWhite, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    placeholder = { Text("Çalma listesi adı", color = SubtleGray) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = PureIceWhite,
                        unfocusedTextColor = PureIceWhite,
                        focusedBorderColor = NeonSapphire,
                        unfocusedBorderColor = SurfaceSteelBlue
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            onCreatePlaylist(newPlaylistName)
                            newPlaylistName = ""
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                ) {
                    Text("Oluştur", color = PureIceWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("İptal", color = MutedSilver)
                }
            }
        )
    }
}

@Composable
private fun MultiSelectSongsDialog(
    playlistName: String,
    availableTracks: List<GoatTrack>,
    alreadyInPlaylistIds: Set<String>,
    onConfirmSelection: (List<GoatTrack>) -> Unit,
    onDismiss: () -> Unit
) {
    val candidateTracks = remember(availableTracks, alreadyInPlaylistIds) {
        availableTracks.filterNot { alreadyInPlaylistIds.contains(it.id) }
    }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepSlateBlack,
        title = {
            Column {
                Text(
                    text = "$playlistName listesine şarkı ekle",
                    color = PureIceWhite,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Beğenilen ve indirilen şarkılarından seç",
                    color = MutedSilver,
                    fontSize = 12.sp
                )
            }
        },
        text = {
            if (candidateTracks.isEmpty()) {
                Text(
                    text = "Kütüphanendeki tüm şarkılar zaten bu listede yer alıyor veya henüz şarkı kaydetmedin.",
                    color = MutedSilver,
                    fontSize = 13.sp
                )
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                    items(candidateTracks, key = { it.id }) { track ->
                        val isChecked = selectedIds.contains(track.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedIds = if (isChecked) selectedIds - track.id else selectedIds + track.id
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = {
                                    selectedIds = if (isChecked) selectedIds - track.id else selectedIds + track.id
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = ElectricCobalt,
                                    uncheckedColor = SubtleGray
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = track.title,
                                    color = PureIceWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = buildString {
                                        if (track.isFavorite) append("Beğenilen • ")
                                        if (track.isDownloadedAny) append("İndirilen • ")
                                        append(track.artist)
                                    },
                                    color = MutedSilver,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val chosen = candidateTracks.filter { selectedIds.contains(it.id) }
                    onConfirmSelection(chosen)
                },
                enabled = selectedIds.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
            ) {
                Text("Seçilenleri Ekle (${selectedIds.size})", color = PureIceWhite)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Kapat", color = MutedSilver)
            }
        }
    )
}

/**
 * Gercek Spotify / Apple Music duzeyinde temiz, kutusuz, insan yapimi gorunumlu sarki satiri.
 */
@Composable
private fun CleanSpotifyTrackRow(
    track: GoatTrack,
    isPlayingNow: Boolean,
    subtitlePrefix: String?,
    activeDownload: DownloadTaskState?,
    showDragHandle: Boolean = false,
    removeActionLabel: String = "Listeden kaldır",
    onRowClick: () -> Unit,
    onFavoriteClick: (() -> Unit)?,
    onAddToPlaylistClick: (() -> Unit)?,
    onDownloadAudioClick: (() -> Unit)?,
    onDownloadVideoClick: (() -> Unit)?,
    onPlayVideoClick: (() -> Unit)? = null,
    onRemoveClick: (() -> Unit)? = null
) {
    var showMoreMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onRowClick() }
            .padding(horizontal = 16.dp, vertical = 7.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (showDragHandle) {
                Icon(
                    imageVector = Icons.Default.DragHandle,
                    contentDescription = "Sürükle",
                    tint = SubtleGray,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .size(20.dp)
                )
            }

            AsyncImage(
                model = track.thumbnailUrl,
                placeholder = painterResource(id = R.drawable.art_default_cover),
                error = painterResource(id = R.drawable.art_default_cover),
                contentDescription = track.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    color = if (isPlayingNow) NeonSapphire else PureIceWhite,
                    fontSize = 15.sp,
                    fontWeight = if (isPlayingNow) FontWeight.SemiBold else FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // İndirilmişse gerçek Spotify gibi sadece zarif küçük ikon göster
                    if (track.isDownloadedAny) {
                        Icon(
                            imageVector = Icons.Default.DownloadDone,
                            contentDescription = "İndirildi",
                            tint = NeonSapphire,
                            modifier = Modifier
                                .size(14.dp)
                                .padding(end = 4.dp)
                        )
                    }
                    val sub = if (!subtitlePrefix.isNullOrBlank()) {
                        "${track.artist} • $subtitlePrefix"
                    } else {
                        track.artist
                    }
                    Text(
                        text = sub,
                        color = MutedSilver,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Kalp (Beğeni) İkonu
            if (onFavoriteClick != null) {
                IconButton(
                    onClick = onFavoriteClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Beğen",
                        tint = if (track.isFavorite) NeonSapphire else SubtleGray,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }

            // Arama ekranında hızlı ses indirme ikonu
            if (onDownloadAudioClick != null && !track.isDownloadedAudio) {
                IconButton(
                    onClick = onDownloadAudioClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Ses İndir",
                        tint = MutedSilver,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }

            // Üç Nokta (Diğer Seçenekler: Playliste Ekle, Video İndir, Klibi Aç, Listeden Kaldır)
            Box {
                IconButton(
                    onClick = { showMoreMenu = true },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Seçenekler",
                        tint = SubtleGray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMoreMenu,
                    onDismissRequest = { showMoreMenu = false },
                    modifier = Modifier.background(CardMidnightBlue)
                ) {
                    if (onAddToPlaylistClick != null) {
                        DropdownMenuItem(
                            text = { Text("Çalma listesine ekle", color = PureIceWhite) },
                            leadingIcon = { Icon(Icons.Default.PlaylistAdd, null, tint = PureIceWhite) },
                            onClick = {
                                showMoreMenu = false
                                onAddToPlaylistClick()
                            }
                        )
                    }
                    if (onDownloadAudioClick != null && !track.isDownloadedAny) {
                        DropdownMenuItem(
                            text = { Text("Şarkıyı indir", color = PureIceWhite) },
                            leadingIcon = { Icon(Icons.Default.Download, null, tint = SoftSkyBlue) },
                            onClick = {
                                showMoreMenu = false
                                onDownloadAudioClick()
                            }
                        )
                    }
                    if (onDownloadVideoClick != null) {
                        DropdownMenuItem(
                            text = { Text("Videoyu indir (MP4)", color = PureIceWhite) },
                            leadingIcon = { Icon(Icons.Default.Videocam, null, tint = NeonSapphire) },
                            onClick = {
                                showMoreMenu = false
                                onDownloadVideoClick()
                            }
                        )
                    }
                    if (onPlayVideoClick != null) {
                        DropdownMenuItem(
                            text = { Text("Video klibi oynat", color = PureIceWhite) },
                            leadingIcon = { Icon(Icons.Default.OndemandVideo, null, tint = PureIceWhite) },
                            onClick = {
                                showMoreMenu = false
                                onPlayVideoClick()
                            }
                        )
                    }
                    if (onRemoveClick != null) {
                        DropdownMenuItem(
                            text = { Text(removeActionLabel, color = CrimsonAccent) },
                            leadingIcon = { Icon(Icons.Default.DeleteOutline, null, tint = CrimsonAccent) },
                            onClick = {
                                showMoreMenu = false
                                onRemoveClick()
                            }
                        )
                    }
                }
            }
        }

        // Yalnızca aktif indirme devam ederken (%1..%99) ince ilerleme çubuğu gösterilir
        if (activeDownload != null && !activeDownload.isCompleted && !activeDownload.isFailed) {
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { activeDownload.progressPercent / 100f },
                color = NeonSapphire,
                trackColor = SurfaceSteelBlue,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
            )
        }
    }
}

@Composable
private fun QuickPlaylistDialog(
    track: GoatTrack,
    playlists: List<GoatPlaylist>,
    onTogglePlaylist: (String) -> Unit,
    onCreateNewPlaylist: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var newPlName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepSlateBlack,
        title = {
            Column {
                Text(
                    text = "Çalma listesine ekle",
                    color = PureIceWhite,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = track.title,
                    color = MutedSilver,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                playlists.forEach { pl ->
                    val inPlaylist = pl.trackIds.contains(track.id)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (inPlaylist) CardMidnightBlue else ObsidianBlack)
                            .clickable { onTogglePlaylist(pl.id) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = pl.name,
                            color = PureIceWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Icon(
                            imageVector = if (inPlaylist) Icons.Default.CheckCircle else Icons.Default.AddCircleOutline,
                            contentDescription = null,
                            tint = if (inPlaylist) NeonSapphire else SubtleGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newPlName,
                        onValueChange = { newPlName = it },
                        placeholder = { Text("Yeni liste adı...", color = SubtleGray, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = PureIceWhite,
                            unfocusedTextColor = PureIceWhite,
                            focusedBorderColor = NeonSapphire,
                            unfocusedBorderColor = SurfaceSteelBlue
                        )
                    )
                    Button(
                        onClick = {
                            if (newPlName.isNotBlank()) {
                                onCreateNewPlaylist(newPlName)
                                newPlName = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                    ) {
                        Text("Ekle", color = PureIceWhite, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Bitti", color = PureIceWhite, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun MiniPlayerBar(
    track: GoatTrack,
    isPlaying: Boolean,
    isBuffering: Boolean,
    positionMs: Long,
    durationMs: Long,
    onTogglePlay: () -> Unit,
    onFavorite: () -> Unit,
    onNext: () -> Unit,
    onOpenFullPlayer: () -> Unit
) {
    val progress = (positionMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(CardMidnightBlue, AmbientBlueGlow, CardMidnightBlue)
                )
            )
            .border(1.dp, SurfaceSteelBlue, RoundedCornerShape(10.dp))
            .clickable { onOpenFullPlayer() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = track.thumbnailUrl,
                placeholder = painterResource(id = R.drawable.art_default_cover),
                error = painterResource(id = R.drawable.art_default_cover),
                contentDescription = track.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(4.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    color = PureIceWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    modifier = Modifier
                        .fillMaxWidth()
                        .basicMarquee(iterations = Int.MAX_VALUE, velocity = 26.dp)
                )
                Text(
                    text = track.artist,
                    color = MutedSilver,
                    fontSize = 12.sp,
                    maxLines = 1,
                    modifier = Modifier
                        .fillMaxWidth()
                        .basicMarquee(iterations = Int.MAX_VALUE, velocity = 22.dp)
                )
            }
            IconButton(onClick = onFavorite, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Beğen",
                    tint = if (track.isFavorite) NeonSapphire else PureIceWhite,
                    modifier = Modifier.size(20.dp)
                )
            }
            IconButton(onClick = onTogglePlay, modifier = Modifier.size(38.dp)) {
                if (isBuffering) {
                    CircularProgressIndicator(
                        color = PureIceWhite,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                } else {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Oynat/Duraklat",
                        tint = PureIceWhite,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
            IconButton(onClick = onNext, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Sonraki",
                    tint = PureIceWhite,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        LinearProgressIndicator(
            progress = { progress },
            color = PureIceWhite,
            trackColor = SurfaceSteelBlue,
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
        )
    }
}

@Composable
private fun FullScreenPlayerModal(
    track: GoatTrack,
    vm: GoatViewModel,
    isPlaying: Boolean,
    isBuffering: Boolean,
    isRepeatOneEnabled: Boolean,
    positionMs: Long,
    durationMs: Long,
    audioIntensity: Float,
    lyrics: List<LyricLine>,
    isLoadingLyrics: Boolean,
    lyricsOffsetMs: Long,
    onAdjustLyricsOffset: (Long) -> Unit,
    onResetLyricsOffset: () -> Unit,
    onOpenPlaylistSheet: () -> Unit,
    onClose: () -> Unit
) {
    var showLyricsSection by remember { mutableStateOf(false) }
    var scrubPreviewFraction by remember { mutableStateOf<Float?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(CardMidnightBlue, DeepSlateBlack, ObsidianBlack)
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Üst Bar: Box yapısı sayesinde sağdaki buton ne kadar geniş olursa olsun "ŞİMDİ ÇALIYOR" ekranın tam ortasında durur!
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.align(Alignment.CenterStart)
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Küçült",
                        tint = PureIceWhite,
                        modifier = Modifier.size(30.dp)
                    )
                }

                Text(
                    text = "ŞİMDİ ÇALIYOR",
                    color = PureIceWhite.copy(alpha = 0.85f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center)
                )

                TextButton(
                    onClick = { showLyricsSection = !showLyricsSection },
                    modifier = Modifier.align(Alignment.CenterEnd),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (showLyricsSection) "Sözleri Kapat" else "Sözleri Aç",
                        color = SoftSkyBlue,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (!showLyricsSection) {
                Spacer(modifier = Modifier.height(14.dp))

                // Tam Boy Albüm Kapağı (Sözler kapalıyken)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(310.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(ObsidianBlack),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = track.thumbnailUrl,
                        placeholder = painterResource(id = R.drawable.art_default_cover),
                        error = painterResource(id = R.drawable.art_default_cover),
                        contentDescription = track.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                // Şarkı Başlığı (Spotify tarzı kayan yazı animasyonlu) ve Beğeni (Kalp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 12.dp)
                    ) {
                        Text(
                            text = track.title,
                            color = PureIceWhite,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(iterations = Int.MAX_VALUE, velocity = 28.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = track.artist,
                            color = MutedSilver,
                            fontSize = 15.sp,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(iterations = Int.MAX_VALUE, velocity = 24.dp)
                        )
                    }
                    IconButton(onClick = { vm.toggleFavorite(track) }) {
                        Icon(
                            imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Beğen",
                            tint = if (track.isFavorite) NeonSapphire else PureIceWhite,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
            } else {
                Spacer(modifier = Modifier.height(8.dp))

                // Sözler açıkken Spotify tarzı kompakt kapak + başlık satırı (Böylece çubuk ve sözler asla kaydırma çakışması yaşamaz!)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = track.thumbnailUrl,
                        placeholder = painterResource(id = R.drawable.art_default_cover),
                        error = painterResource(id = R.drawable.art_default_cover),
                        contentDescription = track.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    ) {
                        Text(
                            text = track.title,
                            color = PureIceWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(iterations = Int.MAX_VALUE, velocity = 28.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = track.artist,
                            color = MutedSilver,
                            fontSize = 14.sp,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(iterations = Int.MAX_VALUE, velocity = 24.dp)
                        )
                    }
                    IconButton(onClick = { vm.toggleFavorite(track) }) {
                        Icon(
                            imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Beğen",
                            tint = if (track.isFavorite) NeonSapphire else PureIceWhite,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }

            // Ritim ve Ses Şiddetine Duyarlı, Basılı Tutup Sürüklenebilen Pürüzsüz İlerleme Çubuğu
            val sliderPos = (positionMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
            RealAudioLoudnessSeekbar(
                progress = sliderPos,
                audioIntensity = audioIntensity,
                onSeek = { frac ->
                    vm.seekTo((frac * durationMs.coerceAtLeast(1L)).toLong())
                },
                onScrubPreview = { previewFrac ->
                    scrubPreviewFraction = previewFrac
                }
            )

            Spacer(modifier = Modifier.height(4.dp))

            val displayedPositionMs = scrubPreviewFraction?.let {
                (it * durationMs.coerceAtLeast(1L)).toLong()
            } ?: positionMs

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatMillis(displayedPositionMs),
                    color = if (scrubPreviewFraction != null) SoftSkyBlue else SubtleGray,
                    fontWeight = if (scrubPreviewFraction != null) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 12.sp
                )
                Text(text = formatMillis(durationMs), color = SubtleGray, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(if (showLyricsSection) 10.dp else 16.dp))

            // Alt Oynatma Kontrolleri (Birebir Simetrik 46.dp Yan Butonlar ve Parlak Tekrarlama İkonu):
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Sol: Playliste Ekle
                IconButton(
                    onClick = onOpenPlaylistSheet,
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(CardMidnightBlue.copy(alpha = 0.75f))
                        .border(1.dp, SurfaceSteelBlue.copy(alpha = 0.9f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlaylistAdd,
                        contentDescription = "Playliste Ekle",
                        tint = PureIceWhite.copy(alpha = 0.95f),
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(
                    onClick = { vm.playPreviousInQueue() },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Önceki",
                        tint = PureIceWhite,
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(
                    onClick = { vm.togglePlayPause() },
                    modifier = Modifier
                        .size(if (showLyricsSection) 60.dp else 68.dp)
                        .clip(CircleShape)
                        .background(ElectricCobalt)
                        .border(1.5.dp, SoftSkyBlue, CircleShape)
                ) {
                    if (isBuffering) {
                        CircularProgressIndicator(
                            color = PureIceWhite,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(28.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Oynat/Duraklat",
                            tint = PureIceWhite,
                            modifier = Modifier.size(if (showLyricsSection) 32.dp else 36.dp)
                        )
                    }
                }

                IconButton(
                    onClick = { vm.playNextInQueue() },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Sonraki",
                        tint = PureIceWhite,
                        modifier = Modifier.size(38.dp)
                    )
                }

                // Sağ: Şarkıyı Tekrara Al
                IconButton(
                    onClick = { vm.toggleRepeatOneMode() },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            if (isRepeatOneEnabled) ElectricCobalt.copy(alpha = 0.38f)
                            else CardMidnightBlue.copy(alpha = 0.75f)
                        )
                        .border(
                            width = if (isRepeatOneEnabled) 1.5.dp else 1.dp,
                            color = if (isRepeatOneEnabled) SoftSkyBlue else SurfaceSteelBlue.copy(alpha = 0.9f),
                            shape = CircleShape
                        )
                ) {
                    Icon(
                        imageVector = if (isRepeatOneEnabled) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        contentDescription = "Şarkıyı Tekrara Al",
                        tint = if (isRepeatOneEnabled) SoftSkyBlue else PureIceWhite.copy(alpha = 0.95f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Spotify Tarzı Senkronize Şarkı Sözleri Kartı (Sadece sade başlık ve tam senkronize akış)
            if (showLyricsSection) {
                Spacer(modifier = Modifier.height(14.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(AmbientBlueGlow, CardMidnightBlue, DeepSlateBlack)
                            )
                        )
                        .border(1.dp, SurfaceSteelBlue, RoundedCornerShape(16.dp))
                        .padding(horizontal = 18.dp, vertical = 14.dp)
                ) {
                    Text(
                        text = "ŞARKI SÖZLERİ",
                        color = SoftSkyBlue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (isLoadingLyrics) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = SoftSkyBlue, strokeWidth = 2.5.dp)
                        }
                    } else if (lyrics.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Bu parça için senkronize şarkı sözü bulunamadı.",
                                color = MutedSilver,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        WordByWordGlowingLyricsList(
                            lyrics = lyrics,
                            positionMs = displayedPositionMs,
                            onLineTap = { seekMs -> vm.seekTo(seekMs) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WordByWordGlowingLyricsList(
    lyrics: List<LyricLine>,
    positionMs: Long,
    onLineTap: (Long) -> Unit
) {
    val listState = rememberLazyListState()
    // Şarkının enstrümantal giriş kısmındayken (ilk söz henüz başlamamışken) -1 döner, böylece sözler vokalden önce parlamaz!
    val activeLineIndex = remember(lyrics, positionMs) {
        lyrics.indexOfLast { positionMs >= it.startMs }
    }

    LaunchedEffect(activeLineIndex) {
        if (activeLineIndex >= 0) {
            val targetScroll = (activeLineIndex - 1).coerceAtLeast(0)
            runCatching {
                listState.animateScrollToItem(targetScroll)
            }
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        itemsIndexed(lyrics, key = { idx, line -> "${idx}_${line.startMs}" }) { index, line ->
            val isCurrentLine = index == activeLineIndex
            val isPastLine = activeLineIndex >= 0 && index < activeLineIndex

            if (isCurrentLine && line.words.isNotEmpty()) {
                val lineDuration = (line.endMs - line.startMs).coerceAtLeast(500L)
                val elapsedInLine = (positionMs - line.startMs).coerceAtLeast(0L)
                val lineProgress = (elapsedInLine.toFloat() / lineDuration.toFloat()).coerceIn(0f, 1f)

                // Kelime uzunluklarına göre ağırlıklı zamanlama (Kısa kelimeler hızlı, uzun kelimeler doğal sürede parlar)
                val wordWeights = remember(line.words) {
                    line.words.map { (it.length + 2).coerceAtLeast(3).toFloat() }
                }
                val totalWeight = remember(wordWeights) { wordWeights.sum().coerceAtLeast(1f) }
                val currentWeightPos = lineProgress * totalWeight

                val styledText = buildAnnotatedString {
                    var cumulativeWeight = 0f
                    line.words.forEachIndexed { wIdx, word ->
                        val wWeight = wordWeights[wIdx]
                        val wordStart = cumulativeWeight
                        val wordEnd = cumulativeWeight + wWeight
                        cumulativeWeight = wordEnd

                        val wordColor = when {
                            currentWeightPos >= wordEnd -> PureIceWhite
                            currentWeightPos >= wordStart -> SoftSkyBlue
                            else -> MutedSilver.copy(alpha = 0.55f)
                        }
                        withStyle(
                            style = SpanStyle(
                                color = wordColor,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 20.sp
                            )
                        ) {
                            append(word)
                            if (wIdx < line.words.lastIndex) append(" ")
                        }
                    }
                }

                Text(
                    text = styledText,
                    lineHeight = 27.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onLineTap(line.startMs) }
                )
            } else {
                Text(
                    text = line.fullText,
                    color = if (isPastLine) PureIceWhite.copy(alpha = 0.45f) else MutedSilver.copy(alpha = 0.35f),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 24.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onLineTap(line.startMs) }
                )
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun BotShieldWebViewDialog(onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBlack)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepSlateBlack)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Bağlantı Doğrulama",
                        color = PureIceWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Sayfa açıldığında çerezler otomatik kaydedilir.",
                        color = MutedSilver,
                        fontSize = 11.sp
                    )
                }
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCobalt)
                ) {
                    Text("Tamam", color = PureIceWhite, fontSize = 12.sp)
                }
            }

            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, url: String?) {
                                CookieManager.getInstance().flush()
                            }
                        }
                        loadUrl("https://m.youtube.com")
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private fun formatMillis(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "%d:%02d".format(min, sec)
}
