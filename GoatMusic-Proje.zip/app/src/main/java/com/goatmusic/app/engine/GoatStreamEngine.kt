package com.goatmusic.app.engine

import android.content.Context
import android.util.Log
import android.webkit.CookieManager
import com.goatmusic.app.data.LibraryRepository
import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.MediaFormatType
import com.goatmusic.app.model.ResolvedStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

object GoatStreamEngine {

    private const val TAG = "GoatStreamEngine"

    const val VR_USER_AGENT =
        "com.google.android.apps.youtube.vr.oculus/1.56.21 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
    const val VISIONOS_USER_AGENT =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15"
    const val IOS_USER_AGENT =
        "com.google.ios.youtube/19.29.1 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X;)"
    const val ANDROID_TESTSUITE_UA =
        "com.google.android.youtube/19.30.36 (Linux; U; Android 14; en_US) gzip"
    const val WEB_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    @Volatile
    var activePlaybackUserAgent: String = VR_USER_AGENT

    @Volatile
    var activePlaybackReferer: String = "https://www.youtube.com/"

    @Volatile
    private var cachedVisitorData: String? = null

    fun getCurrentVisitorData(): String? = cachedVisitorData

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    suspend fun initEngine(context: Context): String = withContext(Dispatchers.IO) {
        val vd = fetchFreshVisitorData()
        if (!vd.isNullOrBlank()) {
            "48kHz Hi-Res Ses Motoru Aktif"
        } else {
            "Hi-Res Ses Motoru Hazır"
        }
    }

    fun getYouTubeCookies(): String {
        return try {
            CookieManager.getInstance().getCookie("https://www.youtube.com").orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    fun hasVerifiedBotCookies(): Boolean {
        val c = getYouTubeCookies()
        return c.contains("VISITOR_INFO1_LIVE") || c.contains("SAPISID") || c.contains("LOGIN_INFO")
    }

    private fun buildSapisidAuthorizationHeader(cookies: String): String? {
        if (!cookies.contains("SAPISID=")) return null
        val sapisid = cookies.substringAfter("SAPISID=").substringBefore(";").trim()
        if (sapisid.isBlank()) return null
        val origin = "https://www.youtube.com"
        val timestamp = System.currentTimeMillis() / 1000L
        val input = "$timestamp $sapisid $origin"
        val sha1 = MessageDigest.getInstance("SHA-1")
            .digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return "SAPISIDHASH ${timestamp}_$sha1"
    }

    private fun fetchFreshVisitorData(): String? {
        cachedVisitorData?.let { if (it.isNotBlank()) return it }
        try {
            val reqBuilder = Request.Builder()
                .url("https://www.youtube.com/sw.js_data")
                .header("User-Agent", WEB_USER_AGENT)
            val cookies = getYouTubeCookies()
            if (cookies.isNotBlank()) {
                reqBuilder.header("Cookie", cookies)
            }
            httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                if (resp.isSuccessful) {
                    val raw = resp.body?.string().orEmpty().trimStart()
                    val regex = Regex("Cgt[A-Za-z0-9_\\-]+(?:%3D%3D|==)?")
                    val match = regex.find(raw)?.value?.trim('"')
                    if (!match.isNullOrBlank()) {
                        cachedVisitorData = match
                        return match
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "fetchFreshVisitorData warning: ${e.message}")
        }
        return null
    }

    suspend fun searchYouTube(query: String): List<GoatTrack> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()

        try {
            val clientContext = JSONObject().apply {
                put("clientName", "WEB")
                put("clientVersion", "2.20240726.00.00")
                put("hl", "tr")
                put("gl", "TR")
                cachedVisitorData?.let { put("visitorData", it) }
            }
            val payload = JSONObject().apply {
                put("query", query)
                put("context", JSONObject().apply {
                    put("client", clientContext)
                })
            }

            val reqBuilder = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/search?prettyPrint=false")
                .header("User-Agent", WEB_USER_AGENT)
                .header("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))

            val cookies = getYouTubeCookies()
            if (cookies.isNotBlank()) {
                reqBuilder.header("Cookie", cookies)
            }

            httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                if (resp.isSuccessful) {
                    val bodyStr = resp.body?.string().orEmpty()
                    val parsed = parseInnerTubeSearchResponse(bodyStr)
                    if (parsed.isNotEmpty()) return@withContext parsed
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "InnerTube search error, trying fallback", e)
        }

        return@withContext searchViaPipedAndInvidiousFallback(query)
    }

    private fun parseInnerTubeSearchResponse(jsonStr: String): List<GoatTrack> {
        val results = mutableListOf<GoatTrack>()
        val seenIds = mutableSetOf<String>()

        try {
            val rootObj = JSONObject(jsonStr)
            val vd = rootObj.optJSONObject("responseContext")?.optString("visitorData")
            if (!vd.isNullOrBlank()) {
                cachedVisitorData = vd
            }

            fun walkJson(node: Any?) {
                when (node) {
                    is JSONObject -> {
                        if (node.has("videoRenderer")) {
                            val vr = node.optJSONObject("videoRenderer")
                            val videoId = vr?.optString("videoId").orEmpty()
                            if (videoId.length == 11 && seenIds.add(videoId)) {
                                val title = extractRunsText(vr?.optJSONObject("title"))
                                val artist = extractRunsText(
                                    vr?.optJSONObject("ownerText") ?: vr?.optJSONObject("longBylineText")
                                ).ifBlank { "YouTube Müzik" }
                                val lengthText = vr?.optJSONObject("lengthText")?.optString("simpleText")
                                    ?: extractRunsText(vr?.optJSONObject("lengthText"))
                                if (title.isNotBlank() && lengthText.isNotBlank()) {
                                    val durationSec = parseDurationToSeconds(lengthText)
                                    val thumb = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"
                                    results.add(
                                        GoatTrack(
                                            id = videoId,
                                            title = title,
                                            artist = artist,
                                            durationText = lengthText,
                                            durationSec = durationSec,
                                            thumbnailUrl = thumb
                                        )
                                    )
                                }
                            }
                        } else {
                            val keys = node.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                walkJson(node.opt(k))
                            }
                        }
                    }
                    is JSONArray -> {
                        for (i in 0 until node.length()) {
                            walkJson(node.opt(i))
                        }
                    }
                }
            }

            walkJson(rootObj)
        } catch (e: Exception) {
            Log.e(TAG, "parseInnerTubeSearchResponse failed", e)
        }
        return results.take(25)
    }

    private fun extractRunsText(obj: JSONObject?): String {
        if (obj == null) return ""
        val simple = obj.optString("simpleText")
        if (simple.isNotBlank()) return simple
        val runs = obj.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) {
            sb.append(runs.optJSONObject(i)?.optString("text").orEmpty())
        }
        return sb.toString()
    }

    private fun parseDurationToSeconds(text: String): Long {
        val parts = text.trim().split(":").mapNotNull { it.toLongOrNull() }
        return when (parts.size) {
            3 -> parts[0] * 3600 + parts[1] * 60 + parts[2]
            2 -> parts[0] * 60 + parts[1]
            1 -> parts[0]
            else -> 0L
        }
    }

    private fun searchViaPipedAndInvidiousFallback(query: String): List<GoatTrack> {
        val pipedInstances = listOf(
            "https://pipedapi.kavin.rocks",
            "https://pipedapi.tokhmi.xyz",
            "https://pipedapi.moomoo.me",
            "https://api.piped.private.coffee"
        )
        val encoded = java.net.URLEncoder.encode(query, "UTF-8")
        for (base in pipedInstances) {
            try {
                val url = "$base/search?q=$encoded&filter=videos"
                val req = Request.Builder().url(url).header("User-Agent", WEB_USER_AGENT).build()
                httpClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val root = JSONObject(resp.body?.string().orEmpty())
                        val items = root.optJSONArray("items") ?: return@use
                        val list = mutableListOf<GoatTrack>()
                        for (i in 0 until items.length()) {
                            val item = items.optJSONObject(i) ?: continue
                            val rawUrl = item.optString("url")
                            val videoId = rawUrl.substringAfter("v=", "").take(11)
                            val dur = item.optLong("duration", 0L)
                            if (videoId.length == 11 && dur > 0) {
                                val min = dur / 60
                                val sec = dur % 60
                                list.add(
                                    GoatTrack(
                                        id = videoId,
                                        title = item.optString("title", "Bilinmeyen Parça"),
                                        artist = item.optString("uploaderName", "YouTube"),
                                        durationText = "%d:%02d".format(min, sec),
                                        durationSec = dur,
                                        thumbnailUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"
                                    )
                                )
                            }
                        }
                        if (list.isNotEmpty()) return list
                    }
                }
            } catch (_: Exception) {
            }
        }
        return emptyList()
    }

    suspend fun resolveStream(context: Context, videoId: String): ResolvedStream? = withContext(Dispatchers.IO) {
        val visitorData = fetchFreshVisitorData()

        resolveViaInnerTubeClient(
            videoId = videoId,
            clientName = "ANDROID_VR",
            clientVersion = "1.56.21",
            clientIdHeader = "28",
            userAgent = VR_USER_AGENT,
            osName = "Android",
            osVersion = "12L",
            deviceMake = "Oculus",
            deviceModel = "Quest 3",
            androidSdkVersion = 32,
            visitorData = visitorData,
            isEmbedded = false
        )?.let { return@withContext updateActiveHeaders(it) }

        resolveViaInnerTubeClient(
            videoId = videoId,
            clientName = "VISIONOS",
            clientVersion = "0.1",
            clientIdHeader = "101",
            userAgent = VISIONOS_USER_AGENT,
            osName = "visionOS",
            osVersion = "1.0.21N307",
            deviceMake = "Apple",
            deviceModel = "RealityDevice14,1",
            androidSdkVersion = null,
            visitorData = visitorData,
            isEmbedded = false
        )?.let { return@withContext updateActiveHeaders(it) }

        resolveViaInnerTubeClient(
            videoId = videoId,
            clientName = "ANDROID_TESTSUITE",
            clientVersion = "1.9",
            clientIdHeader = "30",
            userAgent = ANDROID_TESTSUITE_UA,
            osName = "Android",
            osVersion = "14",
            deviceMake = "Google",
            deviceModel = "Pixel 8",
            androidSdkVersion = 34,
            visitorData = visitorData,
            isEmbedded = false
        )?.let { return@withContext updateActiveHeaders(it) }

        resolveViaInnerTubeClient(
            videoId = videoId,
            clientName = "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
            clientVersion = "2.0",
            clientIdHeader = "85",
            userAgent = WEB_USER_AGENT,
            osName = null,
            osVersion = null,
            deviceMake = null,
            deviceModel = null,
            androidSdkVersion = null,
            visitorData = visitorData,
            isEmbedded = true
        )?.let { return@withContext updateActiveHeaders(it) }

        resolveViaInnerTubeClient(
            videoId = videoId,
            clientName = "IOS",
            clientVersion = "19.29.1",
            clientIdHeader = "5",
            userAgent = IOS_USER_AGENT,
            osName = "iOS",
            osVersion = "17.5.1.21F90",
            deviceMake = "Apple",
            deviceModel = "iPhone16,2",
            androidSdkVersion = null,
            visitorData = visitorData,
            isEmbedded = false
        )?.let { return@withContext updateActiveHeaders(it) }

        resolveViaPipedStreamFallback(videoId)?.let { return@withContext updateActiveHeaders(it) }

        return@withContext null
    }


    private fun resolveViaPipedStreamFallback(videoId: String): ResolvedStream? {
        val pipedInstances = listOf(
            "https://pipedapi.kavin.rocks",
            "https://pipedapi.tokhmi.xyz",
            "https://pipedapi.moomoo.me",
            "https://api.piped.private.coffee"
        )
        for (base in pipedInstances) {
            try {
                val req = Request.Builder()
                    .url("$base/streams/$videoId")
                    .header("User-Agent", WEB_USER_AGENT)
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use
                    val root = JSONObject(resp.body?.string().orEmpty())
                    val audioStreams = root.optJSONArray("audioStreams") ?: JSONArray()
                    var bestAudioUrl: String? = null
                    var bestMime = "audio/mp4"
                    var bestBitrate = 0
                    for (i in 0 until audioStreams.length()) {
                        val a = audioStreams.optJSONObject(i) ?: continue
                        val url = a.optString("url")
                        val mime = a.optString("mimeType", "audio/mp4")
                        val br = a.optInt("bitrate", 0)
                        if (url.isNotBlank() && (br > bestBitrate || bestAudioUrl == null)) {
                            bestBitrate = br
                            bestAudioUrl = url
                            bestMime = mime
                        }
                    }
                    val hls = root.optString("hls").takeIf { it.isNotBlank() }
                    val finalUrl = bestAudioUrl ?: hls ?: return@use
                    return ResolvedStream(
                        videoId = videoId,
                        audioUrl = finalUrl,
                        audioMimeType = bestMime,
                        m4aDownloadUrl = bestAudioUrl ?: finalUrl,
                        m4aContentLength = 0L,
                        muxedVideoUrl = null,
                        adaptiveVideoUrl = null,
                        adaptiveVideoLength = 0L,
                        hlsManifestUrl = hls,
                        userAgent = WEB_USER_AGENT,
                        referer = "https://www.youtube.com/watch?v=$videoId"
                    )
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun updateActiveHeaders(stream: ResolvedStream): ResolvedStream {
        activePlaybackUserAgent = stream.userAgent
        activePlaybackReferer = stream.referer
        return stream
    }

    private fun resolveViaInnerTubeClient(
        videoId: String,
        clientName: String,
        clientVersion: String,
        clientIdHeader: String,
        userAgent: String,
        osName: String?,
        osVersion: String?,
        deviceMake: String?,
        deviceModel: String?,
        androidSdkVersion: Int?,
        visitorData: String?,
        isEmbedded: Boolean
    ): ResolvedStream? {
        try {
            val clientObj = JSONObject().apply {
                put("clientName", clientName)
                put("clientVersion", clientVersion)
                put("hl", "tr")
                put("gl", "TR")
                if (deviceMake != null) put("deviceMake", deviceMake)
                if (deviceModel != null) put("deviceModel", deviceModel)
                if (osName != null) put("osName", osName)
                if (osVersion != null) put("osVersion", osVersion)
                if (androidSdkVersion != null) put("androidSdkVersion", androidSdkVersion)
                if (!visitorData.isNullOrBlank()) put("visitorData", visitorData)
            }

            val contextObj = JSONObject().apply {
                put("client", clientObj)
                if (isEmbedded) {
                    put("thirdParty", JSONObject().apply {
                        put("embedUrl", "https://www.youtube.com/embed/$videoId")
                    })
                }
            }

            val payload = JSONObject().apply {
                put("videoId", videoId)
                put("contentCheckOk", true)
                put("racyCheckOk", true)
                put("context", contextObj)
            }

            val reqBuilder = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
                .header("User-Agent", userAgent)
                .header("Content-Type", "application/json")
                .header("Origin", "https://www.youtube.com")
                .header("Referer", "https://www.youtube.com/watch?v=$videoId")
                .header("X-YouTube-Client-Name", clientIdHeader)
                .header("X-YouTube-Client-Version", clientVersion)
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))

            if (!visitorData.isNullOrBlank()) {
                reqBuilder.header("X-Goog-Visitor-Id", visitorData)
            }

            val cookies = getYouTubeCookies()
            if (cookies.isNotBlank()) {
                reqBuilder.header("Cookie", cookies)
                buildSapisidAuthorizationHeader(cookies)?.let { auth ->
                    reqBuilder.header("Authorization", auth)
                }
            }

            httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val root = JSONObject(resp.body?.string().orEmpty())

                val newVd = root.optJSONObject("responseContext")?.optString("visitorData")
                if (!newVd.isNullOrBlank()) {
                    cachedVisitorData = newVd
                }

                val playability = root.optJSONObject("playabilityStatus")
                val status = playability?.optString("status")
                if (status != "OK") return null

                val streamingData = root.optJSONObject("streamingData") ?: return null
                val adaptive = streamingData.optJSONArray("adaptiveFormats") ?: JSONArray()
                val muxed = streamingData.optJSONArray("formats") ?: JSONArray()
                val hlsUrl = streamingData.optString("hlsManifestUrl").takeIf { it.isNotBlank() }

                var highestQualityAudioUrl: String? = null
                var highestQualityMime = "audio/webm"
                var highestQualityScore = 0

                var bestM4aDownloadUrl: String? = null
                var bestM4aBitrate = 0
                var bestM4aLength = 0L

                var bestAdaptiveVideoUrl: String? = null
                var bestAdaptiveVideoHeight = 0
                var bestAdaptiveVideoLength = 0L

                for (i in 0 until adaptive.length()) {
                    val fmt = adaptive.optJSONObject(i) ?: continue
                    val mime = fmt.optString("mimeType")
                    val url = fmt.optString("url")
                    if (url.isBlank()) continue
                    val clen = fmt.optString("contentLength", "0").toLongOrNull() ?: 0L

                    if (mime.startsWith("audio/")) {
                        val bitrate = fmt.optInt("bitrate", 0)
                        val sampleRate = fmt.optString("audioSampleRate", "44100").toIntOrNull() ?: 44100
                        val audioQuality = fmt.optString("audioQuality", "")

                        // M4A (audio/mp4 - itag 140/141) akislari dosyanin ilk 4 KB bolumunde 'sidx' (Segment Index)
                        // barindirdigi icin ileri/geri sarmada (seek) %100 milisaniye hassasiyetinde calisir ve asla basa atmaz!
                        var qualityScore = bitrate
                        if (audioQuality.contains("HIGH")) qualityScore += 50_000
                        if (mime.contains("mp4")) qualityScore += 95_000
                        else if (sampleRate >= 48000) qualityScore += 20_000

                        if (qualityScore > highestQualityScore) {
                            highestQualityScore = qualityScore
                            highestQualityAudioUrl = url
                            highestQualityMime = mime.substringBefore(";")
                        }

                        if (mime.contains("mp4") && bitrate > bestM4aBitrate) {
                            bestM4aBitrate = bitrate
                            bestM4aDownloadUrl = url
                            bestM4aLength = clen
                        } else if (bestM4aDownloadUrl == null) {
                            bestM4aDownloadUrl = url
                            bestM4aLength = clen
                        }
                    } else if (mime.startsWith("video/mp4")) {
                        val height = fmt.optInt("height", 0)
                        if (height in 360..1080 && height >= bestAdaptiveVideoHeight) {
                            bestAdaptiveVideoHeight = height
                            bestAdaptiveVideoUrl = url
                            bestAdaptiveVideoLength = clen
                        }
                    }
                }

                var bestMuxedVideoUrl: String? = null
                var bestMuxedHeight = 0
                for (i in 0 until muxed.length()) {
                    val fmt = muxed.optJSONObject(i) ?: continue
                    val url = fmt.optString("url")
                    if (url.isBlank()) continue
                    val h = fmt.optInt("height", 0)
                    if (h >= bestMuxedHeight) {
                        bestMuxedHeight = h
                        bestMuxedVideoUrl = url
                    }
                    if (highestQualityAudioUrl == null) {
                        highestQualityAudioUrl = url
                        highestQualityMime = "video/mp4"
                    }
                }

                val finalAudio = highestQualityAudioUrl ?: bestMuxedVideoUrl ?: hlsUrl ?: return null

                return ResolvedStream(
                    videoId = videoId,
                    audioUrl = finalAudio,
                    audioMimeType = highestQualityMime,
                    m4aDownloadUrl = bestM4aDownloadUrl ?: finalAudio,
                    m4aContentLength = bestM4aLength,
                    muxedVideoUrl = bestMuxedVideoUrl,
                    adaptiveVideoUrl = bestAdaptiveVideoUrl,
                    adaptiveVideoLength = bestAdaptiveVideoLength,
                    hlsManifestUrl = hlsUrl,
                    userAgent = userAgent,
                    referer = "https://www.youtube.com/watch?v=$videoId"
                )
            }
        } catch (_: Exception) {
            return null
        }
    }

    suspend fun downloadTrack(
        context: Context,
        track: GoatTrack,
        formatType: MediaFormatType,
        onProgress: (Int, String) -> Unit
    ): File? = withContext(Dispatchers.IO) {
        onProgress(3, "Akış çözülüyor...")
        val stream = resolveStream(context, track.id) ?: return@withContext null
        val vaultDir = LibraryRepository.getIsolatedVaultDirectory(context)

        val safeTitle = "${track.title} - ${track.artist}"
            .replace(Regex("[\\\\/:*?\"<>|]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(65)

        if (formatType == MediaFormatType.AUDIO_M4A) {
            val outFile = File(vaultDir, "GMV_${safeTitle}_${track.id}.m4a")
            val dlUrl = stream.m4aDownloadUrl ?: stream.audioUrl
            val ok = downloadUrlChunked(dlUrl, stream.m4aContentLength, stream.userAgent, outFile) { pct ->
                onProgress(pct, "Ses indiriliyor (%$pct)")
            }
            return@withContext if (ok && outFile.exists() && outFile.length() > 15_000L) outFile else null
        } else {
            val outFile = File(vaultDir, "GMV_${safeTitle}_${track.id}.mp4")
            if (!stream.adaptiveVideoUrl.isNullOrBlank() && !stream.m4aDownloadUrl.isNullOrBlank()) {
                val tempVid = File(context.cacheDir, "tmp_v_${track.id}.mp4")
                val tempAud = File(context.cacheDir, "tmp_a_${track.id}.m4a")
                try {
                    val vOk = downloadUrlChunked(stream.adaptiveVideoUrl, stream.adaptiveVideoLength, stream.userAgent, tempVid) { p ->
                        onProgress((p * 0.65f).toInt().coerceAtLeast(5), "Video indiriliyor...")
                    }
                    val aOk = if (vOk) {
                        downloadUrlChunked(stream.m4aDownloadUrl, stream.m4aContentLength, stream.userAgent, tempAud) { p ->
                            onProgress(65 + (p * 0.25f).toInt(), "Ses birleştiriliyor...")
                        }
                    } else false

                    if (vOk && aOk) {
                        onProgress(92, "MP4 birleştiriliyor...")
                        if (NativeMp4Muxer.muxVideoAndAudio(tempVid, tempAud, outFile)) {
                            onProgress(100, "Tamamlandı")
                            return@withContext outFile
                        }
                    }
                } finally {
                    runCatching { tempVid.delete() }
                    runCatching { tempAud.delete() }
                }
            }

            val fallbackVideoUrl = stream.muxedVideoUrl ?: stream.audioUrl
            val ok = downloadUrlChunked(fallbackVideoUrl, 0L, stream.userAgent, outFile) { pct ->
                onProgress(pct, "Video indiriliyor (%$pct)")
            }
            return@withContext if (ok && outFile.exists() && outFile.length() > 20_000L) outFile else null
        }
    }

    private fun downloadUrlChunked(
        url: String,
        knownLength: Long,
        userAgent: String,
        destFile: File,
        onProgress: (Int) -> Unit
    ): Boolean {
        try {
            if (destFile.exists()) destFile.delete()
            destFile.parentFile?.mkdirs()

            val chunkSize = 9 * 1024 * 1024L
            var totalBytes = knownLength

            if (totalBytes <= 0L) {
                val probeReq = Request.Builder()
                    .url(url)
                    .header("User-Agent", userAgent.ifBlank { VR_USER_AGENT })
                    .header("Range", "bytes=0-1")
                    .build()
                httpClient.newCall(probeReq).execute().use { resp ->
                    val cr = resp.header("Content-Range").orEmpty()
                    val totalStr = cr.substringAfter("/", "").trim()
                    totalBytes = totalStr.toLongOrNull() ?: 0L
                }
            }

            if (totalBytes <= 0L) {
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", userAgent.ifBlank { VR_USER_AGENT })
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return false
                    val body = resp.body ?: return false
                    val len = body.contentLength()
                    body.byteStream().use { input ->
                        destFile.outputStream().use { output ->
                            val buf = ByteArray(64 * 1024)
                            var downloaded = 0L
                            var read: Int
                            while (input.read(buf).also { read = it } != -1) {
                                output.write(buf, 0, read)
                                downloaded += read
                                if (len > 0L) {
                                    onProgress(((downloaded * 100L) / len).toInt().coerceIn(1, 99))
                                }
                            }
                        }
                    }
                }
                return destFile.exists() && destFile.length() > 10_000L
            }

            RandomAccessFile(destFile, "rw").use { raf ->
                var downloaded = 0L
                while (downloaded < totalBytes) {
                    val end = (downloaded + chunkSize - 1L).coerceAtMost(totalBytes - 1L)
                    val req = Request.Builder()
                        .url(url)
                        .header("User-Agent", userAgent.ifBlank { VR_USER_AGENT })
                        .header("Range", "bytes=$downloaded-$end")
                        .build()

                    httpClient.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful && resp.code != 206) return false
                        val body = resp.body ?: return false
                        body.byteStream().use { input ->
                            val buf = ByteArray(64 * 1024)
                            var read: Int
                            while (input.read(buf).also { read = it } != -1) {
                                raf.write(buf, 0, read)
                                downloaded += read
                                val pct = ((downloaded * 100L) / totalBytes).toInt().coerceIn(1, 99)
                                onProgress(pct)
                            }
                        }
                    }
                }
            }
            onProgress(100)
            return destFile.exists() && destFile.length() > 10_000L
        } catch (_: Exception) {
            return false
        }
    }
}
