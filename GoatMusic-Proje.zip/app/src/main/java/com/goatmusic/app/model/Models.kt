package com.goatmusic.app.model

import java.io.File

enum class MediaFormatType {
    AUDIO_M4A,
    VIDEO_MP4
}

data class GoatTrack(
    val id: String,
    val title: String,
    val artist: String,
    val durationText: String = "",
    val durationSec: Long = 0L,
    val thumbnailUrl: String = "",
    val localAudioPath: String? = null,
    val localVideoPath: String? = null,
    val isFavorite: Boolean = false,
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L,
    val addedAt: Long = System.currentTimeMillis()
) {
    val isDownloadedAudio: Boolean
        get() = !localAudioPath.isNullOrBlank() && File(localAudioPath).exists()

    val isDownloadedVideo: Boolean
        get() = !localVideoPath.isNullOrBlank() && File(localVideoPath).exists()

    val isDownloadedAny: Boolean
        get() = isDownloadedAudio || isDownloadedVideo
}

data class GoatPlaylist(
    val id: String,
    val name: String,
    val trackIds: List<String>,
    val isSystemPlaylist: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class DownloadTaskState(
    val videoId: String,
    val title: String,
    val formatType: MediaFormatType,
    val progressPercent: Int,
    val statusText: String,
    val isCompleted: Boolean = false,
    val isFailed: Boolean = false
)

data class ResolvedStream(
    val videoId: String,
    val audioUrl: String,
    val audioMimeType: String = "audio/mp4",
    val m4aDownloadUrl: String? = null,
    val m4aContentLength: Long = 0L,
    val muxedVideoUrl: String? = null,
    val adaptiveVideoUrl: String? = null,
    val adaptiveVideoLength: Long = 0L,
    val hlsManifestUrl: String? = null,
    val userAgent: String = "",
    val referer: String = "https://www.youtube.com/"
)

data class LyricLine(
    val startMs: Long,
    val endMs: Long,
    val words: List<String>,
    val fullText: String
)
