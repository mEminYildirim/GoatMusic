package com.goatmusic.app.model

enum class MediaFormatType {
    AUDIO_M4A,
    VIDEO_MP4
}

data class GoatTrack(
    val id: String,
    val title: String,
    val artist: String,
    val durationText: String,
    val durationSec: Long,
    val thumbnailUrl: String,
    val localAudioPath: String? = null,
    val localVideoPath: String? = null,
    val isFavorite: Boolean = false,
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L,
    val addedAt: Long = System.currentTimeMillis()
) {
    val isDownloadedAudio: Boolean get() = !localAudioPath.isNullOrBlank()
    val isDownloadedVideo: Boolean get() = !localVideoPath.isNullOrBlank()
    val isDownloadedAny: Boolean get() = isDownloadedAudio || isDownloadedVideo
}

data class GoatPlaylist(
    val id: String,
    val name: String,
    val trackIds: List<String>,
    val isSystemPlaylist: Boolean = false
)

data class LyricLine(
    val startMs: Long,
    val endMs: Long,
    val words: List<String>,
    val fullText: String
)

data class ResolvedStream(
    val videoId: String,
    val audioUrl: String,
    val downloadAudioUrl: String,
    val muxedVideoUrl: String?,
    val adaptiveVideoOnlyUrl: String?,
    val hlsManifestUrl: String?,
    val mimeType: String,
    val bitrate: Int,
    val contentLength: Long,
    val videoContentLength: Long,
    val userAgent: String,
    val referer: String,
    val engineName: String
)

data class DownloadTaskState(
    val videoId: String,
    val title: String,
    val formatType: MediaFormatType,
    val progressPercent: Int,
    val statusText: String,
    val isCompleted: Boolean = false,
    val isFailed: Boolean = false,
    val filePath: String? = null
)
