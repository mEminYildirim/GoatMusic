@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.goatmusic.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.goatmusic.app.data.LibraryRepository
import com.goatmusic.app.engine.GoatStreamEngine
import com.goatmusic.app.model.DownloadTaskState
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.MediaFormatType
import com.goatmusic.app.player.DynamicHttpDataSourceFactory
import com.goatmusic.app.player.GoatAudioLevelSink
import com.goatmusic.app.player.GoatNotificationBridge
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.random.Random

class GoatViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = LibraryRepository(application)

    private val _isBotShieldVerified = MutableStateFlow(false)
    val isBotShieldVerified: StateFlow<Boolean> = _isBotShieldVerified.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchResults = MutableStateFlow<List<GoatTrack>>(emptyList())
    val searchResults: StateFlow<List<GoatTrack>> = _searchResults.asStateFlow()

    private val _libraryTracks = MutableStateFlow<List<GoatTrack>>(emptyList())
    val libraryTracks: StateFlow<List<GoatTrack>> = _libraryTracks.asStateFlow()

    private val _similarTracks = MutableStateFlow<List<GoatTrack>>(emptyList())
    val similarTracks: StateFlow<List<GoatTrack>> = _similarTracks.asStateFlow()

    private val _playlists = MutableStateFlow<List<GoatPlaylist>>(emptyList())
    val playlists: StateFlow<List<GoatPlaylist>> = _playlists.asStateFlow()

    private val _currentTrack = MutableStateFlow<GoatTrack?>(null)
    val currentTrack: StateFlow<GoatTrack?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _isVideoMode = MutableStateFlow(false)
    val isVideoMode: StateFlow<Boolean> = _isVideoMode.asStateFlow()

    private val _isShuffleEnabled = MutableStateFlow(false)
    val isShuffleEnabled: StateFlow<Boolean> = _isShuffleEnabled.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(1L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    // Gercek PCM ses siddetine (RMS) duyarli 36 barli yumusak dalga dizisi
    private val _audioIntensity = MutableStateFlow(0f)
    val audioIntensity: StateFlow<Float> = _audioIntensity.asStateFlow()

    private val _downloads = MutableStateFlow<Map<String, DownloadTaskState>>(emptyMap())
    val downloads: StateFlow<Map<String, DownloadTaskState>> = _downloads.asStateFlow()

    private var activeQueue: List<GoatTrack> = emptyList()
    private var searchJob: Job? = null
    private var lastSimilarSeedArtist: String? = null

    val exoPlayer: ExoPlayer = run {
        val dsFactory = DefaultDataSource.Factory(application, DynamicHttpDataSourceFactory())
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(25_000, 90_000, 1_500, 3_000)
            .build()

        val renderersFactory = object : DefaultRenderersFactory(application) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(TeeAudioProcessor(GoatAudioLevelSink)))
                    .build()
            }
        }

        ExoPlayer.Builder(application, renderersFactory)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    init {
        refreshLibraryAndPlaylists()
        _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()

        GoatNotificationBridge.onPrevCallback = { playPreviousInQueue() }
        GoatNotificationBridge.onPlayPauseCallback = { togglePlayPause() }
        GoatNotificationBridge.onNextCallback = { playNextInQueue() }
        GoatNotificationBridge.onLikeCallback = {
            _currentTrack.value?.let { toggleFavorite(it) }
        }
        GoatNotificationBridge.onSeekCallback = { pos -> seekTo(pos) }

        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                syncNotification()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _isBuffering.value = (playbackState == Player.STATE_BUFFERING)
                if (playbackState == Player.STATE_READY) {
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(1L)
                    syncNotification()
                } else if (playbackState == Player.STATE_ENDED) {
                    playNextInQueue()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                _isBuffering.value = false
            }
        })

        // Pozisyon ve anlik ses siddeti (ilerleme cubugu gostergesi icin) guncelleme dongusu
        viewModelScope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _positionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(1L)
                    _audioIntensity.value = GoatAudioLevelSink.currentIntensity
                } else {
                    GoatAudioLevelSink.decayWhenPaused()
                    _audioIntensity.value = GoatAudioLevelSink.currentIntensity
                }
                delay(65)
            }
        }

        viewModelScope.launch {
            GoatStreamEngine.initEngine(application)
            _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()
            refreshSimilarTracksIfNeeded()
        }
    }

    fun onPermissionsGranted() {
        viewModelScope.launch {
            repo.syncIsolatedVaultFiles()
            refreshLibraryAndPlaylists()
        }
    }

    private fun refreshLibraryAndPlaylists() {
        val tracks = repo.getSavedTracks()
        _libraryTracks.value = tracks
        _playlists.value = repo.getAllPlaylistsWithSystem(tracks)
        _currentTrack.value?.let { cur ->
            tracks.find { it.id == cur.id }?.let { updated ->
                _currentTrack.value = updated
            }
        }
    }

    private fun syncNotification() {
        val cur = _currentTrack.value ?: return
        GoatNotificationBridge.updateNotification(
            context = getApplication(),
            track = cur,
            isPlaying = _isPlaying.value,
            positionMs = _positionMs.value,
            durationMs = _durationMs.value
        )
    }

    /**
     * Kullanicinin SON ACTIGI / SON DINLEDIGI sarkiya gore benzer sarkilari bulur.
     */
    private fun refreshSimilarTracksIfNeeded() {
        val recentTrack = _libraryTracks.value
            .filter { it.lastPlayedAt > 0L }
            .maxByOrNull { it.lastPlayedAt }
            ?: _libraryTracks.value.firstOrNull()
            ?: return

        val seedKey = "${recentTrack.id}_${recentTrack.artist}"
        if (seedKey == lastSimilarSeedArtist && _similarTracks.value.isNotEmpty()) return
        lastSimilarSeedArtist = seedKey

        val querySeed = if (recentTrack.artist.isNotBlank() && recentTrack.artist != "YouTube Müzik") {
            "${recentTrack.artist} ${recentTrack.title.take(18)} benzer şarkılar"
        } else {
            "${recentTrack.title.take(28)} mix"
        }

        viewModelScope.launch {
            val results = GoatStreamEngine.searchYouTube(querySeed)
            val existingIds = _libraryTracks.value.map { it.id }.toSet()
            _similarTracks.value = results.filterNot { existingIds.contains(it.id) }.take(10)
        }
    }

    fun refreshBotShieldState() {
        _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()
    }

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
        searchJob?.cancel()
        if (newQuery.trim().length >= 2) {
            searchJob = viewModelScope.launch {
                delay(450)
                performSearch(newQuery.trim())
            }
        }
    }

    fun performSearch(query: String = _searchQuery.value) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _isSearching.value = true
            val list = GoatStreamEngine.searchYouTube(query)
            val savedMap = _libraryTracks.value.associateBy { it.id }
            _searchResults.value = list.map { item ->
                val saved = savedMap[item.id]
                if (saved != null) {
                    item.copy(
                        localAudioPath = saved.localAudioPath,
                        localVideoPath = saved.localVideoPath,
                        isFavorite = saved.isFavorite,
                        playCount = saved.playCount,
                        lastPlayedAt = saved.lastPlayedAt
                    )
                } else item
            }
            _isSearching.value = false
        }
    }

    /**
     * Playlistin ustundeki "Karisik Cal (Shuffle)" butonuna basildiginda listeden rastgele bir sarki
     * acar ve sarki bittiginde baska rastgele sarki ile devam eder.
     */
    fun shufflePlayPlaylist(playlistTracks: List<GoatTrack>) {
        if (playlistTracks.isEmpty()) return
        _isShuffleEnabled.value = true
        activeQueue = playlistTracks
        val randomTrack = playlistTracks[Random.nextInt(playlistTracks.size)]
        playTrack(randomTrack, preferVideo = false, customQueue = playlistTracks)
    }

    fun playPlaylistInOrder(playlistTracks: List<GoatTrack>) {
        if (playlistTracks.isEmpty()) return
        _isShuffleEnabled.value = false
        activeQueue = playlistTracks
        playTrack(playlistTracks.first(), preferVideo = false, customQueue = playlistTracks)
    }

    fun toggleShuffleMode() {
        _isShuffleEnabled.value = !_isShuffleEnabled.value
    }

    fun playTrack(track: GoatTrack, preferVideo: Boolean = false, customQueue: List<GoatTrack>? = null) {
        if (customQueue != null && customQueue.isNotEmpty()) {
            activeQueue = customQueue
        } else if (activeQueue.isEmpty()) {
            activeQueue = _libraryTracks.value.ifEmpty { _searchResults.value }
        }

        _isVideoMode.value = preferVideo
        _isBuffering.value = true

        repo.recordTrackPlayed(track)
        refreshLibraryAndPlaylists()
        val updatedTrack = _libraryTracks.value.find { it.id == track.id } ?: track
        _currentTrack.value = updatedTrack
        syncNotification()
        refreshSimilarTracksIfNeeded()

        viewModelScope.launch {
            val localPath = if (preferVideo) {
                updatedTrack.localVideoPath ?: updatedTrack.localAudioPath
            } else {
                updatedTrack.localAudioPath ?: updatedTrack.localVideoPath
            }

            if (!localPath.isNullOrBlank() && File(localPath).exists()) {
                val mediaItem = MediaItem.Builder()
                    .setUri(Uri.fromFile(File(localPath)))
                    .setMediaId(updatedTrack.id)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(updatedTrack.title)
                            .setArtist(updatedTrack.artist)
                            .setArtworkUri(Uri.parse(updatedTrack.thumbnailUrl))
                            .build()
                    )
                    .build()

                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
                syncNotification()
                return@launch
            }

            val stream = GoatStreamEngine.resolveStream(getApplication(), updatedTrack.id)
            if (stream != null) {
                val targetUrl = if (preferVideo) {
                    stream.muxedVideoUrl ?: stream.hlsManifestUrl ?: stream.audioUrl
                } else {
                    stream.audioUrl
                }

                val mediaItem = MediaItem.Builder()
                    .setUri(targetUrl)
                    .setMediaId(updatedTrack.id)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(updatedTrack.title)
                            .setArtist(updatedTrack.artist)
                            .setArtworkUri(Uri.parse(updatedTrack.thumbnailUrl))
                            .build()
                    )
                    .build()

                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
                syncNotification()
            } else {
                _isBuffering.value = false
            }
        }
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
        syncNotification()
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
        _positionMs.value = positionMs
        syncNotification()
    }

    fun toggleVideoMode() {
        val cur = _currentTrack.value ?: return
        val nextMode = !_isVideoMode.value
        playTrack(cur, preferVideo = nextMode)
    }

    fun toggleFavorite(track: GoatTrack) {
        repo.toggleFavorite(track)
        refreshLibraryAndPlaylists()
        val latest = _libraryTracks.value.find { it.id == track.id }
        if (latest != null) {
            _searchResults.value = _searchResults.value.map { if (it.id == track.id) latest else it }
            _similarTracks.value = _similarTracks.value.map { if (it.id == track.id) latest else it }
        }
        syncNotification()
    }

    fun deleteDownloadedTrack(trackId: String) {
        repo.deleteDownloadedFiles(trackId)
        refreshLibraryAndPlaylists()
        _searchResults.value = _searchResults.value.map {
            if (it.id == trackId) it.copy(localAudioPath = null, localVideoPath = null) else it
        }
    }

    fun createPlaylist(name: String) {
        repo.createCustomPlaylist(name)
        refreshLibraryAndPlaylists()
    }

    fun deleteCustomPlaylist(playlistId: String) {
        repo.deleteCustomPlaylist(playlistId)
        refreshLibraryAndPlaylists()
    }

    fun toggleTrackInPlaylist(playlistId: String, track: GoatTrack) {
        when (playlistId) {
            LibraryRepository.PLAYLIST_LIKED_ID -> toggleFavorite(track)
            LibraryRepository.PLAYLIST_DOWNLOADED_ID -> {
                if (track.isDownloadedAny) {
                    deleteDownloadedTrack(track.id)
                } else {
                    downloadTrack(track, MediaFormatType.AUDIO_M4A)
                }
            }
            else -> {
                repo.toggleTrackInCustomPlaylist(playlistId, track)
                refreshLibraryAndPlaylists()
            }
        }
    }

    fun addMultipleTracksToPlaylist(playlistId: String, tracks: List<GoatTrack>) {
        repo.addMultipleTracksToPlaylist(playlistId, tracks)
        refreshLibraryAndPlaylists()
    }

    fun reorderPlaylistTracks(playlistId: String, fromIndex: Int, toIndex: Int, currentIds: List<String>) {
        repo.reorderPlaylistTracks(playlistId, fromIndex, toIndex, currentIds)
        refreshLibraryAndPlaylists()
    }

    fun playNextInQueue() {
        val queue = activeQueue.ifEmpty { _libraryTracks.value.ifEmpty { _searchResults.value } }
        if (queue.isEmpty()) return
        val curId = _currentTrack.value?.id

        if (_isShuffleEnabled.value && queue.size > 1) {
            val candidates = queue.filterNot { it.id == curId }
            val nextRandom = candidates[Random.nextInt(candidates.size)]
            playTrack(nextRandom, preferVideo = _isVideoMode.value, customQueue = queue)
            return
        }

        val idx = queue.indexOfFirst { it.id == curId }
        val nextTrack = if (idx in 0 until queue.lastIndex) queue[idx + 1] else queue.first()
        playTrack(nextTrack, preferVideo = _isVideoMode.value, customQueue = queue)
    }

    fun playPreviousInQueue() {
        val queue = activeQueue.ifEmpty { _libraryTracks.value.ifEmpty { _searchResults.value } }
        if (queue.isEmpty()) return
        val curId = _currentTrack.value?.id

        if (_isShuffleEnabled.value && queue.size > 1) {
            val candidates = queue.filterNot { it.id == curId }
            val prevRandom = candidates[Random.nextInt(candidates.size)]
            playTrack(prevRandom, preferVideo = _isVideoMode.value, customQueue = queue)
            return
        }

        val idx = queue.indexOfFirst { it.id == curId }
        val prevTrack = if (idx > 0) queue[idx - 1] else queue.last()
        playTrack(prevTrack, preferVideo = _isVideoMode.value, customQueue = queue)
    }

    fun downloadTrack(track: GoatTrack, formatType: MediaFormatType) {
        viewModelScope.launch {
            _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                videoId = track.id,
                title = track.title,
                formatType = formatType,
                progressPercent = 1,
                statusText = "Başlatılıyor..."
            ))

            val file = GoatStreamEngine.downloadTrack(
                context = getApplication(),
                track = track,
                formatType = formatType
            ) { pct, status ->
                _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                    videoId = track.id,
                    title = track.title,
                    formatType = formatType,
                    progressPercent = pct,
                    statusText = status
                ))
            }

            if (file != null && file.exists()) {
                val updatedTrack = if (formatType == MediaFormatType.AUDIO_M4A) {
                    track.copy(localAudioPath = file.absolutePath)
                } else {
                    track.copy(localVideoPath = file.absolutePath)
                }
                repo.upsertTrack(updatedTrack)
                refreshLibraryAndPlaylists()
                _searchResults.value = _searchResults.value.map {
                    if (it.id == track.id) _libraryTracks.value.find { s -> s.id == track.id } ?: updatedTrack else it
                }
                // Indirme tamamlandiginda ilerleme cubugunu kaldir (kalici mavi cubuk kalmasin)
                _downloads.value = _downloads.value - track.id
            } else {
                _downloads.value = _downloads.value - track.id
            }
        }
    }

    fun shutdownPlayerAndNotification() {
        runCatching { exoPlayer.stop() }
        GoatNotificationBridge.cancelNotificationAndRelease(getApplication())
    }

    override fun onCleared() {
        GoatNotificationBridge.cancelNotificationAndRelease(getApplication())
        GoatNotificationBridge.onPrevCallback = null
        GoatNotificationBridge.onPlayPauseCallback = null
        GoatNotificationBridge.onNextCallback = null
        GoatNotificationBridge.onLikeCallback = null
        GoatNotificationBridge.onSeekCallback = null
        runCatching { exoPlayer.stop() }
        runCatching { exoPlayer.release() }
        super.onCleared()
    }
}
