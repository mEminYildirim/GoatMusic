@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.goatmusic.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.goatmusic.app.data.LibraryRepository
import com.goatmusic.app.engine.GoatStreamEngine
import com.goatmusic.app.model.DownloadTaskState
import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.MediaFormatType
import com.goatmusic.app.player.DynamicHttpDataSourceFactory
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class GoatViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = LibraryRepository(application)

    private val _engineStatus = MutableStateFlow("Anti-Bot Motoru Başlatılıyor...")
    val engineStatus: StateFlow<String> = _engineStatus.asStateFlow()

    private val _isBotShieldVerified = MutableStateFlow(false)
    val isBotShieldVerified: StateFlow<Boolean> = _isBotShieldVerified.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchResults = MutableStateFlow<List<GoatTrack>>(emptyList())
    val searchResults: StateFlow<List<GoatTrack>> = _searchResults.asStateFlow()

    private val _libraryTracks = MutableStateFlow<List<GoatTrack>>(emptyList())
    val libraryTracks: StateFlow<List<GoatTrack>> = _libraryTracks.asStateFlow()

    private val _currentTrack = MutableStateFlow<GoatTrack?>(null)
    val currentTrack: StateFlow<GoatTrack?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _isVideoMode = MutableStateFlow(false)
    val isVideoMode: StateFlow<Boolean> = _isVideoMode.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(1L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _downloads = MutableStateFlow<Map<String, DownloadTaskState>>(emptyMap())
    val downloads: StateFlow<Map<String, DownloadTaskState>> = _downloads.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private var searchJob: Job? = null

    val exoPlayer: ExoPlayer = run {
        val dsFactory = DefaultDataSource.Factory(application, DynamicHttpDataSourceFactory())

        ExoPlayer.Builder(application)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    init {
        _libraryTracks.value = repo.getSavedTracks()
        _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()

        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _isBuffering.value = (playbackState == Player.STATE_BUFFERING)
                if (playbackState == Player.STATE_READY) {
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(1L)
                } else if (playbackState == Player.STATE_ENDED) {
                    playNextInLibrary()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                _isBuffering.value = false
                _statusBanner.value = "Akış yenileniyor (${error.errorCodeName})..."
            }
        })

        viewModelScope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _positionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(1L)
                }
                delay(500)
            }
        }

        viewModelScope.launch {
            _engineStatus.value = GoatStreamEngine.initEngine(application)
            _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()
            if (_searchResults.value.isEmpty()) {
                performSearch("Türkçe Pop Hit Şarkılar")
            }
        }
    }

    fun refreshBotShieldState() {
        _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()
        if (_isBotShieldVerified.value) {
            _statusBanner.value = "Bot Kalkanı Aktif: YouTube çerezleri doğrulandı"
        }
    }

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
        searchJob?.cancel()
        if (newQuery.trim().length >= 2) {
            searchJob = viewModelScope.launch {
                delay(450)
                performSearch(newQuery.trim())
            }
        }
    }

    fun performSearch(query: String = _searchQuery.value) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _isSearching.value = true
            val list = GoatStreamEngine.searchYouTube(query)
            val savedMap = _libraryTracks.value.associateBy { it.id }
            _searchResults.value = list.map { item ->
                val saved = savedMap[item.id]
                if (saved != null) {
                    item.copy(
                        localAudioPath = saved.localAudioPath,
                        localVideoPath = saved.localVideoPath,
                        isFavorite = saved.isFavorite
                    )
                } else item
            }
            _isSearching.value = false
        }
    }

    fun playTrack(track: GoatTrack, preferVideo: Boolean = false) {
        _currentTrack.value = track
        _isVideoMode.value = preferVideo
        _isBuffering.value = true

        viewModelScope.launch {
            val localPath = if (preferVideo) {
                track.localVideoPath ?: track.localAudioPath
            } else {
                track.localAudioPath ?: track.localVideoPath
            }

            if (!localPath.isNullOrBlank() && File(localPath).exists()) {
                val mediaItem = MediaItem.Builder()
                    .setUri(Uri.fromFile(File(localPath)))
                    .setMediaId(track.id)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(track.title)
                            .setArtist(track.artist)
                            .setArtworkUri(Uri.parse(track.thumbnailUrl))
                            .build()
                    )
                    .build()

                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
                _statusBanner.value = "Çevrimdışı çalınıyor: ${track.title}"
                repo.upsertTrack(track)
                _libraryTracks.value = repo.getSavedTracks()
                return@launch
            }

            _statusBanner.value = "Akış hazırlanıyor: ${track.title}..."
            val stream = GoatStreamEngine.resolveStream(getApplication(), track.id)
            if (stream != null) {
                val targetUrl = if (preferVideo) {
                    stream.muxedVideoUrl ?: stream.hlsManifestUrl ?: stream.audioUrl
                } else {
                    stream.audioUrl
                }

                val mediaItem = MediaItem.Builder()
                    .setUri(targetUrl)
                    .setMediaId(track.id)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(track.title)
                            .setArtist(track.artist)
                            .setArtworkUri(Uri.parse(track.thumbnailUrl))
                            .build()
                    )
                    .build()

                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
                _statusBanner.value = "${stream.engineName} ile çalınıyor"
                repo.upsertTrack(track)
                _libraryTracks.value = repo.getSavedTracks()
            } else {
                _isBuffering.value = false
                _statusBanner.value = "Akış engellendi: Üstteki Kalkan ikonundan Bot Kalkanını açın."
            }
        }
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
        _positionMs.value = positionMs
    }

    fun toggleVideoMode() {
        val cur = _currentTrack.value ?: return
        val nextMode = !_isVideoMode.value
        playTrack(cur, preferVideo = nextMode)
    }

    fun toggleFavorite(track: GoatTrack) {
        val updated = repo.toggleFavorite(track)
        _libraryTracks.value = updated
        val latest = updated.find { it.id == track.id }
        if (_currentTrack.value?.id == track.id && latest != null) {
            _currentTrack.value = latest
        }
    }

    fun deleteFromLibrary(trackId: String) {
        _libraryTracks.value = repo.removeTrack(trackId)
        _statusBanner.value = "Parça kitaplıktan kaldırıldı"
    }

    fun playNextInLibrary() {
        val list = _libraryTracks.value.ifEmpty { _searchResults.value }
        if (list.isEmpty()) return
        val curId = _currentTrack.value?.id
        val idx = list.indexOfFirst { it.id == curId }
        val nextTrack = if (idx in 0 until list.lastIndex) list[idx + 1] else list.first()
        playTrack(nextTrack, preferVideo = _isVideoMode.value)
    }

    fun playPreviousInLibrary() {
        val list = _libraryTracks.value.ifEmpty { _searchResults.value }
        if (list.isEmpty()) return
        val curId = _currentTrack.value?.id
        val idx = list.indexOfFirst { it.id == curId }
        val prevTrack = if (idx > 0) list[idx - 1] else list.last()
        playTrack(prevTrack, preferVideo = _isVideoMode.value)
    }

    fun downloadTrack(track: GoatTrack, formatType: MediaFormatType) {
        viewModelScope.launch {
            _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                videoId = track.id,
                title = track.title,
                formatType = formatType,
                progressPercent = 1,
                statusText = "Başlatılıyor..."
            ))

            val file = GoatStreamEngine.downloadTrack(
                context = getApplication(),
                track = track,
                formatType = formatType
            ) { pct, status ->
                _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                    videoId = track.id,
                    title = track.title,
                    formatType = formatType,
                    progressPercent = pct,
                    statusText = status
                ))
            }

            if (file != null && file.exists()) {
                val updatedTrack = if (formatType == MediaFormatType.AUDIO_M4A) {
                    track.copy(localAudioPath = file.absolutePath)
                } else {
                    track.copy(localVideoPath = file.absolutePath)
                }
                val newLib = repo.upsertTrack(updatedTrack)
                _libraryTracks.value = newLib
                if (_currentTrack.value?.id == track.id) {
                    _currentTrack.value = newLib.find { it.id == track.id }
                }
                _searchResults.value = _searchResults.value.map {
                    if (it.id == track.id) newLib.find { s -> s.id == track.id } ?: updatedTrack else it
                }
                _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                    videoId = track.id,
                    title = track.title,
                    formatType = formatType,
                    progressPercent = 100,
                    statusText = if (formatType == MediaFormatType.AUDIO_M4A) "Ses İndirildi (M4A)" else "Video İndirildi (MP4)",
                    isCompleted = true,
                    filePath = file.absolutePath
                ))
                _statusBanner.value = "Telefona İndirildi: ${track.title}"
            } else {
                _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                    videoId = track.id,
                    title = track.title,
                    formatType = formatType,
                    progressPercent = 0,
                    statusText = "İndirme hatası",
                    isFailed = true
                ))
                _statusBanner.value = "İndirme başarısız: ${track.title}"
            }
        }
    }

    override fun onCleared() {
        exoPlayer.release()
        super.onCleared()
    }
}
