@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.goatmusic.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.goatmusic.app.data.LibraryRepository
import com.goatmusic.app.engine.GoatLyricsEngine
import com.goatmusic.app.engine.GoatStreamEngine
import com.goatmusic.app.model.DownloadTaskState
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.LyricLine
import com.goatmusic.app.model.MediaFormatType
import com.goatmusic.app.player.DynamicHttpDataSourceFactory
import com.goatmusic.app.player.GoatAudioLevelSink
import com.goatmusic.app.player.GoatNotificationBridge
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs
import kotlin.random.Random

class GoatViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = LibraryRepository(application)

    private val _isBotShieldVerified = MutableStateFlow(false)
    val isBotShieldVerified: StateFlow<Boolean> = _isBotShieldVerified.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _activeCategoryTitle = MutableStateFlow<String?>(null)
    val activeCategoryTitle: StateFlow<String?> = _activeCategoryTitle.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchResults = MutableStateFlow<List<GoatTrack>>(emptyList())
    val searchResults: StateFlow<List<GoatTrack>> = _searchResults.asStateFlow()

    private val _libraryTracks = MutableStateFlow<List<GoatTrack>>(emptyList())
    val libraryTracks: StateFlow<List<GoatTrack>> = _libraryTracks.asStateFlow()

    private val _similarTracks = MutableStateFlow<List<GoatTrack>>(emptyList())
    val similarTracks: StateFlow<List<GoatTrack>> = _similarTracks.asStateFlow()

    private val _playlists = MutableStateFlow<List<GoatPlaylist>>(emptyList())
    val playlists: StateFlow<List<GoatPlaylist>> = _playlists.asStateFlow()

    private val _currentTrack = MutableStateFlow<GoatTrack?>(null)
    val currentTrack: StateFlow<GoatTrack?> = _currentTrack.asStateFlow()

    private val _currentLyrics = MutableStateFlow<List<LyricLine>>(emptyList())
    val currentLyrics: StateFlow<List<LyricLine>> = _currentLyrics.asStateFlow()

    private val _isLoadingLyrics = MutableStateFlow(false)
    val isLoadingLyrics: StateFlow<Boolean> = _isLoadingLyrics.asStateFlow()

    private val _lyricsOffsetMs = MutableStateFlow(0L)
    val lyricsOffsetMs: StateFlow<Long> = _lyricsOffsetMs.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _isShuffleEnabled = MutableStateFlow(false)
    val isShuffleEnabled: StateFlow<Boolean> = _isShuffleEnabled.asStateFlow()

    private val _isRepeatOneEnabled = MutableStateFlow(false)
    val isRepeatOneEnabled: StateFlow<Boolean> = _isRepeatOneEnabled.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(1L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _audioIntensity = MutableStateFlow(0f)
    val audioIntensity: StateFlow<Float> = _audioIntensity.asStateFlow()

    private val _downloads = MutableStateFlow<Map<String, DownloadTaskState>>(emptyMap())
    val downloads: StateFlow<Map<String, DownloadTaskState>> = _downloads.asStateFlow()

    private var activeQueue: List<GoatTrack> = emptyList()
    private var searchJob: Job? = null
    private var lyricsJob: Job? = null
    private var lastLyricsDurationUsedMs: Long = 0L
    private var lastSimilarSeedKey: String? = null

    val exoPlayer: ExoPlayer = run {
        val dsFactory = DefaultDataSource.Factory(application, DynamicHttpDataSourceFactory())
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 120_000, 1_500, 3_000)
            .build()

        val renderersFactory = object : DefaultRenderersFactory(application) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                // 32-bit Float Hi-Res PCM cikisi aktif edildi (Maksimum ses berrakligi ve bas derinligi)
                return DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(true)
                    .setAudioProcessors(arrayOf(TeeAudioProcessor(GoatAudioLevelSink)))
                    .build()
            }
        }

        ExoPlayer.Builder(application, renderersFactory)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
    }

    init {
        refreshLibraryAndPlaylists()
        _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()

        GoatNotificationBridge.onPrevCallback = { playPreviousInQueue() }
        GoatNotificationBridge.onPlayPauseCallback = { togglePlayPause() }
        GoatNotificationBridge.onNextCallback = { playNextInQueue() }
        GoatNotificationBridge.onLikeCallback = {
            _currentTrack.value?.let { toggleFavorite(it) }
        }
        GoatNotificationBridge.onSeekCallback = { pos -> seekTo(pos) }
        GoatNotificationBridge.onAppSwipedClosedCallback = {
            shutdownPlayerAndNotification()
        }

        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                syncNotification()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _isBuffering.value = (playbackState == Player.STATE_BUFFERING)
                if (playbackState == Player.STATE_READY) {
                    val realDur = exoPlayer.duration.coerceAtLeast(1L)
                    _durationMs.value = realDur
                    syncNotification()
                    // Gerçek parça süresi geldiğinde şarkı sözü süresini gerçek süreyle hassas eşleştir
                    val cur = _currentTrack.value
                    if (cur != null && realDur > 15_000L && abs(realDur - lastLyricsDurationUsedMs) > 2_500L) {
                        loadLyricsForTrack(cur, realDur)
                    }
                } else if (playbackState == Player.STATE_ENDED) {
                    if (_isRepeatOneEnabled.value) {
                        exoPlayer.seekTo(0L)
                        exoPlayer.play()
                    } else {
                        playNextInQueue()
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                _isBuffering.value = false
            }
        })

        viewModelScope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _positionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(1L)
                    _audioIntensity.value = GoatAudioLevelSink.currentIntensity
                } else {
                    GoatAudioLevelSink.decayWhenPaused()
                    _audioIntensity.value = GoatAudioLevelSink.currentIntensity
                }
                delay(45)
            }
        }

        viewModelScope.launch {
            GoatStreamEngine.initEngine(application)
            _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()
            refreshSimilarTracksIfNeeded()
        }
    }

    fun onPermissionsGranted() {
        viewModelScope.launch {
            repo.syncIsolatedVaultFiles()
            refreshLibraryAndPlaylists()
        }
    }

    private fun refreshLibraryAndPlaylists() {
        val tracks = repo.getSavedTracks()
        _libraryTracks.value = tracks
        _playlists.value = repo.getAllPlaylistsWithSystem(tracks)
        _currentTrack.value?.let { cur ->
            tracks.find { it.id == cur.id }?.let { updated ->
                _currentTrack.value = updated
            }
        }
    }

    private fun syncNotification() {
        val cur = _currentTrack.value ?: return
        GoatNotificationBridge.updateNotification(
            context = getApplication(),
            track = cur,
            isPlaying = _isPlaying.value,
            positionMs = _positionMs.value,
            durationMs = _durationMs.value
        )
    }

    /**
     * Kullanıcının SON 3 DİNLEDİĞİ ŞARKIYA göre karma ve dengeli benzer şarkı önerileri üretir.
     */
    private fun refreshSimilarTracksIfNeeded() {
        val lastThreePlayed = _libraryTracks.value
            .filter { it.lastPlayedAt > 0L }
            .sortedByDescending { it.lastPlayedAt }
            .take(3)
            .ifEmpty { _libraryTracks.value.take(3) }

        if (lastThreePlayed.isEmpty()) return

        val seedKey = lastThreePlayed.joinToString("|") { "${it.id}_${it.artist}" }
        if (seedKey == lastSimilarSeedKey && _similarTracks.value.isNotEmpty()) return
        lastSimilarSeedKey = seedKey

        viewModelScope.launch {
            val existingIds = _libraryTracks.value.map { it.id }.toSet()
            val deferredLists = lastThreePlayed.map { seedTrack ->
                async {
                    val querySeed = if (seedTrack.artist.isNotBlank() && seedTrack.artist != "YouTube Müzik") {
                        "${seedTrack.artist} ${seedTrack.title.take(18)} benzer şarkılar"
                    } else {
                        "${seedTrack.title.take(28)} mix"
                    }
                    GoatStreamEngine.searchYouTube(querySeed)
                        .filterNot { existingIds.contains(it.id) || it.id == seedTrack.id }
                        .take(5)
                }
            }

            val perSeedResults = deferredLists.awaitAll()
            // Son 3 şarkının önerilerini sırayla harmanla (Round-Robin Interleave)
            val blended = mutableListOf<GoatTrack>()
            val seenIds = mutableSetOf<String>()
            val maxLen = perSeedResults.maxOfOrNull { it.size } ?: 0
            for (idx in 0 until maxLen) {
                for (list in perSeedResults) {
                    if (idx < list.size) {
                        val candidate = list[idx]
                        if (seenIds.add(candidate.id)) {
                            blended.add(candidate)
                        }
                    }
                }
            }
            _similarTracks.value = blended.take(12)
        }
    }

    fun refreshBotShieldState() {
        _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()
    }

    fun adjustLyricsOffset(deltaMs: Long) {
        _lyricsOffsetMs.value = (_lyricsOffsetMs.value + deltaMs).coerceIn(-10_000L, 10_000L)
    }

    fun resetLyricsOffset() {
        _lyricsOffsetMs.value = 0L
    }

    private fun loadLyricsForTrack(track: GoatTrack, targetDurationMs: Long) {
        lastLyricsDurationUsedMs = targetDurationMs
        lyricsJob?.cancel()
        _isLoadingLyrics.value = true
        lyricsJob = viewModelScope.launch {
            val fetched = GoatLyricsEngine.fetchSynchronizedLyrics(track, targetDurationMs)
            _currentLyrics.value = fetched
            _isLoadingLyrics.value = false
        }
    }

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
        if (newQuery.isBlank()) {
            _activeCategoryTitle.value = null
            _searchResults.value = emptyList()
        }
        searchJob?.cancel()
        if (newQuery.trim().length >= 2) {
            _activeCategoryTitle.value = null
            searchJob = viewModelScope.launch {
                delay(450)
                performSearch(newQuery.trim())
            }
        }
    }

    fun selectSearchCategory(displayTitle: String, hiddenSearchQuery: String) {
        _activeCategoryTitle.value = displayTitle
        _searchQuery.value = ""
        searchJob?.cancel()
        performSearch(hiddenSearchQuery)
    }

    fun clearSelectedCategory() {
        _activeCategoryTitle.value = null
        _searchQuery.value = ""
        _searchResults.value = emptyList()
    }

    fun performSearch(query: String = _searchQuery.value) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _isSearching.value = true
            val list = GoatStreamEngine.searchYouTube(query)
            val savedMap = _libraryTracks.value.associateBy { it.id }
            _searchResults.value = list.map { item ->
                val saved = savedMap[item.id]
                if (saved != null) {
                    item.copy(
                        localAudioPath = saved.localAudioPath,
                        localVideoPath = saved.localVideoPath,
                        isFavorite = saved.isFavorite,
                        playCount = saved.playCount,
                        lastPlayedAt = saved.lastPlayedAt
                    )
                } else item
            }
            _isSearching.value = false
        }
    }

    fun shufflePlayPlaylist(playlistTracks: List<GoatTrack>) {
        if (playlistTracks.isEmpty()) return
        _isShuffleEnabled.value = true
        activeQueue = playlistTracks
        val randomTrack = playlistTracks[Random.nextInt(playlistTracks.size)]
        playTrack(randomTrack, preferVideo = false, customQueue = playlistTracks)
    }

    fun playPlaylistInOrder(playlistTracks: List<GoatTrack>) {
        if (playlistTracks.isEmpty()) return
        _isShuffleEnabled.value = false
        activeQueue = playlistTracks
        playTrack(playlistTracks.first(), preferVideo = false, customQueue = playlistTracks)
    }

    fun toggleRepeatOneMode() {
        _isRepeatOneEnabled.value = !_isRepeatOneEnabled.value
    }

    fun playTrack(track: GoatTrack, preferVideo: Boolean = false, customQueue: List<GoatTrack>? = null) {
        if (customQueue != null && customQueue.isNotEmpty()) {
            activeQueue = customQueue
        } else if (activeQueue.isEmpty()) {
            activeQueue = _libraryTracks.value.ifEmpty { _searchResults.value }
        }

        _isBuffering.value = true
        _lyricsOffsetMs.value = 0L
        repo.recordTrackPlayed(track)
        refreshLibraryAndPlaylists()
        val updatedTrack = _libraryTracks.value.find { it.id == track.id } ?: track
        _currentTrack.value = updatedTrack
        syncNotification()
        refreshSimilarTracksIfNeeded()

        // Şarkı sözlerini arka planda getir
        _currentLyrics.value = emptyList()
        val estDur = (updatedTrack.durationSec * 1000L).takeIf { it > 15_000L } ?: 180_000L
        loadLyricsForTrack(updatedTrack, estDur)

        viewModelScope.launch {
            val localPath = if (preferVideo) {
                updatedTrack.localVideoPath ?: updatedTrack.localAudioPath
            } else {
                updatedTrack.localAudioPath ?: updatedTrack.localVideoPath
            }

            if (!localPath.isNullOrBlank() && File(localPath).exists()) {
                val mediaItem = MediaItem.Builder()
                    .setUri(Uri.fromFile(File(localPath)))
                    .setMediaId(updatedTrack.id)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(updatedTrack.title)
                            .setArtist(updatedTrack.artist)
                            .setArtworkUri(Uri.parse(updatedTrack.thumbnailUrl))
                            .build()
                    )
                    .build()

                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
                syncNotification()
                return@launch
            }

            val stream = GoatStreamEngine.resolveStream(getApplication(), updatedTrack.id)
            if (stream != null) {
                val targetUrl = if (preferVideo) {
                    stream.muxedVideoUrl ?: stream.hlsManifestUrl ?: stream.audioUrl
                } else {
                    stream.audioUrl
                }

                val mediaItem = MediaItem.Builder()
                    .setUri(targetUrl)
                    .setMediaId(updatedTrack.id)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(updatedTrack.title)
                            .setArtist(updatedTrack.artist)
                            .setArtworkUri(Uri.parse(updatedTrack.thumbnailUrl))
                            .build()
                    )
                    .build()

                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
                syncNotification()
            } else {
                _isBuffering.value = false
            }
        }
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
        syncNotification()
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
        _positionMs.value = positionMs
        syncNotification()
    }

    fun toggleFavorite(track: GoatTrack) {
        repo.toggleFavorite(track)
        refreshLibraryAndPlaylists()
        val latest = _libraryTracks.value.find { it.id == track.id }
        if (latest != null) {
            _searchResults.value = _searchResults.value.map { if (it.id == track.id) latest else it }
            _similarTracks.value = _similarTracks.value.map { if (it.id == track.id) latest else it }
        }
        syncNotification()
    }

    fun deleteDownloadedTrack(trackId: String) {
        repo.deleteDownloadedFiles(trackId)
        refreshLibraryAndPlaylists()
        _searchResults.value = _searchResults.value.map {
            if (it.id == trackId) it.copy(localAudioPath = null, localVideoPath = null) else it
        }
    }

    fun createPlaylist(name: String) {
        repo.createCustomPlaylist(name)
        refreshLibraryAndPlaylists()
    }

    fun deleteCustomPlaylist(playlistId: String) {
        repo.deleteCustomPlaylist(playlistId)
        refreshLibraryAndPlaylists()
    }

    fun toggleTrackInPlaylist(playlistId: String, track: GoatTrack) {
        when (playlistId) {
            LibraryRepository.PLAYLIST_LIKED_ID -> {
                toggleFavorite(track)
            }
            LibraryRepository.PLAYLIST_DOWNLOADED_ID -> {
                if (track.isDownloadedAny) {
                    deleteDownloadedTrack(track.id)
                }
            }
            else -> {
                val pl = _playlists.value.find { it.id == playlistId } ?: return
                if (pl.trackIds.contains(track.id)) {
                    repo.removeTrackFromCustomPlaylist(playlistId, track.id)
                } else {
                    repo.addTrackToCustomPlaylist(playlistId, track)
                }
                refreshLibraryAndPlaylists()
            }
        }
    }

    fun addMultipleTracksToPlaylist(playlistId: String, selectedTracks: List<GoatTrack>) {
        if (selectedTracks.isEmpty()) return
        when (playlistId) {
            LibraryRepository.PLAYLIST_LIKED_ID -> {
                selectedTracks.forEach { t ->
                    if (!t.isFavorite) repo.toggleFavorite(t)
                }
            }
            else -> {
                repo.addMultipleTracksToPlaylist(playlistId, selectedTracks)
            }
        }
        refreshLibraryAndPlaylists()
    }

    fun reorderPlaylistTracks(playlistId: String, fromIndex: Int, toIndex: Int, currentTrackIds: List<String>) {
        repo.moveTrackInPlaylist(playlistId, fromIndex, toIndex, currentTrackIds)
        refreshLibraryAndPlaylists()
    }

    fun playNextInQueue() {
        val list = activeQueue.ifEmpty { _libraryTracks.value.ifEmpty { _searchResults.value } }
        if (list.isEmpty()) return
        val curId = _currentTrack.value?.id
        if (_isShuffleEnabled.value && list.size > 1) {
            val candidates = list.filter { it.id != curId }
            val next = candidates[Random.nextInt(candidates.size)]
            playTrack(next, false, list)
            return
        }
        val idx = list.indexOfFirst { it.id == curId }
        val next = if (idx in 0 until list.lastIndex) list[idx + 1] else list.first()
        playTrack(next, false, list)
    }

    fun playPreviousInQueue() {
        val list = activeQueue.ifEmpty { _libraryTracks.value.ifEmpty { _searchResults.value } }
        if (list.isEmpty()) return
        val curId = _currentTrack.value?.id
        if (_isShuffleEnabled.value && list.size > 1) {
            val candidates = list.filter { it.id != curId }
            val prev = candidates[Random.nextInt(candidates.size)]
            playTrack(prev, false, list)
            return
        }
        val idx = list.indexOfFirst { it.id == curId }
        val prev = if (idx > 0) list[idx - 1] else list.last()
        playTrack(prev, false, list)
    }

    fun downloadTrack(track: GoatTrack, formatType: MediaFormatType) {
        val currentState = _downloads.value[track.id]
        if (currentState != null && !currentState.isCompleted && !currentState.isFailed) return

        viewModelScope.launch {
            val targetFile = repo.createVaultTargetFile(track, formatType)
            _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                trackId = track.id,
                formatType = formatType,
                progressPercent = 1,
                statusText = "İndiriliyor..."
            ))

            val ok = GoatStreamEngine.downloadMediaToFile(
                context = getApplication(),
                track = track,
                formatType = formatType,
                destFile = targetFile
            ) { pct, status ->
                _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                    trackId = track.id,
                    formatType = formatType,
                    progressPercent = pct,
                    statusText = status
                ))
            }

            if (ok && targetFile.exists() && targetFile.length() > 10_000L) {
                repo.markTrackDownloaded(track, formatType, targetFile.absolutePath)
                refreshLibraryAndPlaylists()
                val updated = _libraryTracks.value.find { it.id == track.id }
                if (updated != null) {
                    _searchResults.value = _searchResults.value.map { if (it.id == track.id) updated else it }
                    _similarTracks.value = _similarTracks.value.map { if (it.id == track.id) updated else it }
                }
                _downloads.value = _downloads.value - track.id
            } else {
                _downloads.value = _downloads.value - track.id
            }
        }
    }

    fun shutdownPlayerAndNotification() {
        runCatching {
            exoPlayer.stop()
            _isPlaying.value = false
            GoatNotificationBridge.cancelNotificationAndRelease(getApplication())
        }
    }

    override fun onCleared() {
        shutdownPlayerAndNotification()
        exoPlayer.release()
        super.onCleared()
    }
}
