@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.goatmusic.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import com.goatmusic.app.data.LibraryRepository
import com.goatmusic.app.engine.GoatLyricsEngine
import com.goatmusic.app.engine.GoatStreamEngine
import com.goatmusic.app.model.DownloadTaskState
import com.goatmusic.app.model.GoatPlaylist
import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.LyricLine
import com.goatmusic.app.model.MediaFormatType
import com.goatmusic.app.player.DynamicHttpDataSourceFactory
import com.goatmusic.app.player.GoatAudioLevelSink
import com.goatmusic.app.player.GoatNotificationBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlin.math.abs
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.random.Random

class GoatViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = LibraryRepository(application)

    private val _isBotShieldVerified = MutableStateFlow(false)
    val isBotShieldVerified: StateFlow<Boolean> = _isBotShieldVerified.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _activeCategoryTitle = MutableStateFlow<String?>(null)
    val activeCategoryTitle: StateFlow<String?> = _activeCategoryTitle.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchResults = MutableStateFlow<List<GoatTrack>>(emptyList())
    val searchResults: StateFlow<List<GoatTrack>> = _searchResults.asStateFlow()

    private val _libraryTracks = MutableStateFlow<List<GoatTrack>>(emptyList())
    val libraryTracks: StateFlow<List<GoatTrack>> = _libraryTracks.asStateFlow()

    private val _similarTracks = MutableStateFlow<List<GoatTrack>>(emptyList())
    val similarTracks: StateFlow<List<GoatTrack>> = _similarTracks.asStateFlow()

    private val _playlists = MutableStateFlow<List<GoatPlaylist>>(emptyList())
    val playlists: StateFlow<List<GoatPlaylist>> = _playlists.asStateFlow()

    private val _currentTrack = MutableStateFlow<GoatTrack?>(null)
    val currentTrack: StateFlow<GoatTrack?> = _currentTrack.asStateFlow()

    private val _currentLyrics = MutableStateFlow<List<LyricLine>>(emptyList())
    val currentLyrics: StateFlow<List<LyricLine>> = _currentLyrics.asStateFlow()

    private val _isLoadingLyrics = MutableStateFlow(false)
    val isLoadingLyrics: StateFlow<Boolean> = _isLoadingLyrics.asStateFlow()

    private val _lyricsOffsetMs = MutableStateFlow(0L)
    val lyricsOffsetMs: StateFlow<Long> = _lyricsOffsetMs.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _isShuffleEnabled = MutableStateFlow(false)
    val isShuffleEnabled: StateFlow<Boolean> = _isShuffleEnabled.asStateFlow()

    private val _isRepeatOneEnabled = MutableStateFlow(false)
    val isRepeatOneEnabled: StateFlow<Boolean> = _isRepeatOneEnabled.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(1L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _audioIntensity = MutableStateFlow(0f)
    val audioIntensity: StateFlow<Float> = _audioIntensity.asStateFlow()

    private val _downloads = MutableStateFlow<Map<String, DownloadTaskState>>(emptyMap())
    val downloads: StateFlow<Map<String, DownloadTaskState>> = _downloads.asStateFlow()

    private var activeQueue: List<GoatTrack> = emptyList()
    private var searchJob: Job? = null
    private var lyricsJob: Job? = null
    private var lastLyricsDurationUsedMs: Long = 0L
    private var lastSimilarSeedArtist: String? = null
    private var lastCategoryQueryIndexMap = mutableMapOf<String, Int>()

    val exoPlayer: ExoPlayer = run {
        val dsFactory = DefaultDataSource.Factory(application, DynamicHttpDataSourceFactory())
        val extractorsFactory = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
            .setConstantBitrateSeekingAlwaysEnabled(true)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 120_000, 1_500, 3_000)
            .build()

        val renderersFactory = object : DefaultRenderersFactory(application) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(true)
                    .setAudioProcessors(arrayOf(TeeAudioProcessor(GoatAudioLevelSink)))
                    .build()
            }
        }

        ExoPlayer.Builder(application, renderersFactory)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory, extractorsFactory))
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
    }

    init {
        refreshLibraryAndPlaylists()
        _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()

        GoatNotificationBridge.onPrevCallback = { playPreviousInQueue() }
        GoatNotificationBridge.onPlayPauseCallback = { togglePlayPause() }
        GoatNotificationBridge.onNextCallback = { playNextInQueue() }
        GoatNotificationBridge.onLikeCallback = {
            _currentTrack.value?.let { toggleFavorite(it) }
        }
        GoatNotificationBridge.onSeekCallback = { pos -> seekTo(pos) }
        GoatNotificationBridge.onAppSwipedClosedCallback = {
            shutdownPlayerAndNotification()
        }

        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                syncNotification()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _isBuffering.value = (playbackState == Player.STATE_BUFFERING)
                if (playbackState == Player.STATE_READY) {
                    val rawDur = exoPlayer.duration
                    if (rawDur > 1000L) {
                        _durationMs.value = rawDur
                        val cur = _currentTrack.value
                        if (cur != null && rawDur > 15_000L && abs(rawDur - lastLyricsDurationUsedMs) > 800L) {
                            loadLyricsForTrack(cur, rawDur)
                        }
                    }
                    syncNotification()
                } else if (playbackState == Player.STATE_ENDED) {
                    if (_isRepeatOneEnabled.value) {
                        exoPlayer.seekTo(0L)
                        exoPlayer.play()
                    } else {
                        playNextInQueue()
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                _isBuffering.value = false
            }
        })

        viewModelScope.launch {
            while (isActive) {
                _positionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
                if (exoPlayer.duration > 0L) {
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(1L)
                }
                val livePlaying = exoPlayer.isPlaying
                if (_isPlaying.value != livePlaying && exoPlayer.playbackState != Player.STATE_BUFFERING) {
                    _isPlaying.value = livePlaying
                    syncNotification()
                }
                if (livePlaying) {
                    _audioIntensity.value = GoatAudioLevelSink.currentIntensity
                } else {
                    GoatAudioLevelSink.decayWhenPaused()
                    _audioIntensity.value = GoatAudioLevelSink.currentIntensity
                }
                delay(30)
            }
        }

        viewModelScope.launch {
            GoatStreamEngine.initEngine(application)
            _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()
            refreshSimilarTracksIfNeeded()
        }
    }

    fun onPermissionsGranted() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repo.deepRestoreAndMergeVaultDatabase()
                repo.syncIsolatedVaultFiles()
            }
            refreshLibraryAndPlaylists()
            refreshSimilarTracksIfNeeded()
        }
    }

    private fun refreshLibraryAndPlaylists() {
        val tracks = repo.getSavedTracks()
        _libraryTracks.value = tracks
        _playlists.value = repo.getAllPlaylistsWithSystem(tracks)
        _currentTrack.value?.let { cur ->
            tracks.find { it.id == cur.id }?.let { updated ->
                _currentTrack.value = updated
            }
        }
    }

    private fun syncNotification() {
        val cur = _currentTrack.value ?: return
        val effectivePlaying = exoPlayer.isPlaying ||
            (exoPlayer.playWhenReady && exoPlayer.playbackState == Player.STATE_BUFFERING)
        _isPlaying.value = effectivePlaying
        GoatNotificationBridge.updateNotification(
            context = getApplication(),
            track = cur,
            isPlaying = effectivePlaying,
            positionMs = _positionMs.value,
            durationMs = _durationMs.value
        )
    }

    private fun refreshSimilarTracksIfNeeded() {
        val lastThreePlayed = _libraryTracks.value
            .filter { it.lastPlayedAt > 0L }
            .sortedByDescending { it.lastPlayedAt }
            .take(3)
            .ifEmpty { _libraryTracks.value.take(3) }

        if (lastThreePlayed.isEmpty()) return

        val seedKey = lastThreePlayed.joinToString("|") { "${it.id}_${it.artist}" }
        if (seedKey == lastSimilarSeedArtist && _similarTracks.value.isNotEmpty()) return
        lastSimilarSeedArtist = seedKey

        viewModelScope.launch {
            val existingIds = _libraryTracks.value.map { it.id }.toSet()
            val deferredLists = lastThreePlayed.map { seedTrack ->
                async {
                    val querySeed = if (seedTrack.artist.isNotBlank() && seedTrack.artist != "YouTube Müzik") {
                        "${seedTrack.artist} ${seedTrack.title.take(18)} benzer şarkılar"
                    } else {
                        "${seedTrack.title.take(28)} mix"
                    }
                    GoatStreamEngine.searchYouTube(querySeed)
                        .filterNot { existingIds.contains(it.id) || it.id == seedTrack.id }
                        .take(5)
                }
            }

            val perSeedResults = deferredLists.awaitAll()
            val blended = mutableListOf<GoatTrack>()
            val seenIds = mutableSetOf<String>()
            val maxLen = perSeedResults.maxOfOrNull { it.size } ?: 0
            for (idx in 0 until maxLen) {
                for (list in perSeedResults) {
                    if (idx < list.size) {
                        val candidate = list[idx]
                        if (seenIds.add(candidate.id)) {
                            blended.add(candidate)
                        }
                    }
                }
            }
            _similarTracks.value = blended.take(12)
        }
    }

    fun adjustLyricsOffset(deltaMs: Long) {
        _lyricsOffsetMs.value = (_lyricsOffsetMs.value + deltaMs).coerceIn(-10_000L, 10_000L)
    }

    fun resetLyricsOffset() {
        _lyricsOffsetMs.value = 0L
    }

    private fun loadLyricsForTrack(track: GoatTrack, targetDurationMs: Long) {
        lastLyricsDurationUsedMs = targetDurationMs
        lyricsJob?.cancel()
        _isLoadingLyrics.value = true
        lyricsJob = viewModelScope.launch {
            val fetched = GoatLyricsEngine.fetchSynchronizedLyrics(track, targetDurationMs)
            _currentLyrics.value = fetched
            _isLoadingLyrics.value = false
        }
    }

    fun refreshBotShieldState() {
        _isBotShieldVerified.value = GoatStreamEngine.hasVerifiedBotCookies()
    }

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
        if (newQuery.isBlank()) {
            _activeCategoryTitle.value = null
            _searchResults.value = emptyList()
        }
        searchJob?.cancel()
        if (newQuery.trim().length >= 2) {
            _activeCategoryTitle.value = null
            searchJob = viewModelScope.launch {
                delay(450)
                performSearch(newQuery.trim())
            }
        }
    }

    fun selectSearchCategory(displayTitle: String, queryPool: List<String>) {
        _activeCategoryTitle.value = displayTitle
        _searchQuery.value = ""
        searchJob?.cancel()
        if (queryPool.isEmpty()) return

        // Her yenilemede en az 10+ gerçek şarkı garantilemek için kategori havuzundan 3 farklı sorguyu paralel çek!
        val lastIdx = lastCategoryQueryIndexMap[displayTitle] ?: -1
        val shuffledIndices = queryPool.indices.shuffled()
        val primaryIdx = shuffledIndices.firstOrNull { it != lastIdx } ?: shuffledIndices.first()
        lastCategoryQueryIndexMap[displayTitle] = primaryIdx
        val chosenIndices = (listOf(primaryIdx) + shuffledIndices.filter { it != primaryIdx }).take(3)
        val selectedQueries = chosenIndices.map { queryPool[it] }.distinct()

        searchJob = viewModelScope.launch {
            _isSearching.value = true
            val longMixRegex = Regex("(?i)(1\\s*hour|2\\s*hour|3\\s*hour|1\\s*saat|2\\s*saat|full\\s*album|non\\s*stop|kesintisiz\\s*mix|uzun\\s*mix|playlist\\s*mix)")

            val deferredResults = selectedQueries.map { q ->
                async { GoatStreamEngine.searchYouTube(q) }
            }
            val rawCombined = deferredResults.awaitAll().flatten().toMutableList()

            var validCandidates = rawCombined
                .distinctBy { it.id }
                .filter { track ->
                    track.durationSec in 55L..600L && !longMixRegex.containsMatchIn(track.title)
                }

            // Eğer ilk 3 sorgudan 12'den az şarkı çıktıysa havuzdaki diğer sorguları da ekleyerek 10+ şarkıyı garantile
            if (validCandidates.size < 12 && queryPool.size > selectedQueries.size) {
                val extraQueries = queryPool.filterNot { selectedQueries.contains(it) }.take(2)
                val extraResults = extraQueries.map { q ->
                    async { GoatStreamEngine.searchYouTube(q) }
                }.awaitAll().flatten()
                rawCombined.addAll(extraResults)
                validCandidates = rawCombined
                    .distinctBy { it.id }
                    .filter { track ->
                        track.durationSec in 55L..600L && !longMixRegex.containsMatchIn(track.title)
                    }
            }

            val savedMap = _libraryTracks.value.associateBy { it.id }
            val filteredSongs = validCandidates
                .shuffled()
                .map { item ->
                    val saved = savedMap[item.id]
                    if (saved != null) {
                        item.copy(
                            localAudioPath = saved.localAudioPath,
                            localVideoPath = saved.localVideoPath,
                            isFavorite = saved.isFavorite,
                            playCount = saved.playCount,
                            lastPlayedAt = saved.lastPlayedAt
                        )
                    } else item
                }

            _searchResults.value = filteredSongs
            _isSearching.value = false
        }
    }

    fun clearSelectedCategory() {
        _activeCategoryTitle.value = null
        _searchQuery.value = ""
        _searchResults.value = emptyList()
    }

    fun performSearch(query: String = _searchQuery.value) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _isSearching.value = true
            val list = GoatStreamEngine.searchYouTube(query)
            val savedMap = _libraryTracks.value.associateBy { it.id }
            _searchResults.value = list.map { item ->
                val saved = savedMap[item.id]
                if (saved != null) {
                    item.copy(
                        localAudioPath = saved.localAudioPath,
                        localVideoPath = saved.localVideoPath,
                        isFavorite = saved.isFavorite,
                        playCount = saved.playCount,
                        lastPlayedAt = saved.lastPlayedAt
                    )
                } else item
            }
            _isSearching.value = false
        }
    }

    fun shufflePlayPlaylist(playlistTracks: List<GoatTrack>) {
        if (playlistTracks.isEmpty()) return
        _isShuffleEnabled.value = true
        val currentId = _currentTrack.value?.id
        var virtualShuffled = playlistTracks.shuffled()
        if (virtualShuffled.size > 1 && virtualShuffled.first().id == currentId) {
            virtualShuffled = virtualShuffled.drop(1) + virtualShuffled.first()
        }
        activeQueue = virtualShuffled
        playTrack(virtualShuffled.first(), preferVideo = false, customQueue = virtualShuffled)
    }

    fun playPlaylistInOrder(playlistTracks: List<GoatTrack>) {
        if (playlistTracks.isEmpty()) return
        _isShuffleEnabled.value = false
        activeQueue = playlistTracks
        playTrack(playlistTracks.first(), preferVideo = false, customQueue = playlistTracks)
    }

    fun toggleRepeatOneMode() {
        _isRepeatOneEnabled.value = !_isRepeatOneEnabled.value
    }

    fun playTrack(track: GoatTrack, preferVideo: Boolean = false, customQueue: List<GoatTrack>? = null) {
        if (customQueue != null && customQueue.isNotEmpty()) {
            activeQueue = customQueue
        } else if (activeQueue.isEmpty()) {
            activeQueue = _libraryTracks.value.ifEmpty { _searchResults.value }
        }

        GoatNotificationBridge.isShuttingDown = false
        _isBuffering.value = true
        _isPlaying.value = true
        _positionMs.value = 0L
        if (track.durationSec > 0L) {
            _durationMs.value = track.durationSec * 1000L
        }
        repo.recordTrackPlayed(track)
        refreshLibraryAndPlaylists()
        val updatedTrack = _libraryTracks.value.find { it.id == track.id } ?: track
        if (updatedTrack.durationSec > 0L) {
            _durationMs.value = updatedTrack.durationSec * 1000L
        }
        _currentTrack.value = updatedTrack
        syncNotification()
        refreshSimilarTracksIfNeeded()

        // Şarkı sözlerini arka planda getir
        _lyricsOffsetMs.value = 0L
        _currentLyrics.value = emptyList()
        val estDur = (updatedTrack.durationSec * 1000L).takeIf { it > 20_000L } ?: 0L
        loadLyricsForTrack(updatedTrack, estDur)

        viewModelScope.launch {
            val localPath = if (preferVideo) {
                updatedTrack.localVideoPath ?: updatedTrack.localAudioPath
            } else {
                updatedTrack.localAudioPath ?: updatedTrack.localVideoPath
            }

            if (!localPath.isNullOrBlank() && File(localPath).exists()) {
                val mediaItem = MediaItem.Builder()
                    .setUri(Uri.fromFile(File(localPath)))
                    .setMediaId(updatedTrack.id)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(updatedTrack.title)
                            .setArtist(updatedTrack.artist)
                            .setArtworkUri(Uri.parse(updatedTrack.thumbnailUrl))
                            .build()
                    )
                    .build()

                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
                syncNotification()
                return@launch
            }

            val stream = GoatStreamEngine.resolveStream(getApplication(), updatedTrack.id)
            if (stream != null) {
                val targetUrl = if (preferVideo) {
                    stream.muxedVideoUrl ?: stream.hlsManifestUrl ?: stream.audioUrl
                } else {
                    stream.audioUrl
                }

                val mediaItem = MediaItem.Builder()
                    .setUri(targetUrl)
                    .setMediaId(updatedTrack.id)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(updatedTrack.title)
                            .setArtist(updatedTrack.artist)
                            .setArtworkUri(Uri.parse(updatedTrack.thumbnailUrl))
                            .build()
                    )
                    .build()

                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
                syncNotification()
            } else {
                _isBuffering.value = false
            }
        }
    }

    fun togglePlayPause() {
        GoatNotificationBridge.isShuttingDown = false
        val currentlyActive = exoPlayer.isPlaying ||
            (exoPlayer.playWhenReady && exoPlayer.playbackState == Player.STATE_BUFFERING)
        if (currentlyActive) {
            exoPlayer.playWhenReady = false
            exoPlayer.pause()
            _isPlaying.value = false
        } else {
            if (exoPlayer.playbackState == Player.STATE_IDLE || exoPlayer.playbackState == Player.STATE_ENDED) {
                exoPlayer.prepare()
            }
            exoPlayer.playWhenReady = true
            exoPlayer.play()
            _isPlaying.value = true
        }
        GoatNotificationBridge.updateNotification(
            context = getApplication(),
            track = _currentTrack.value ?: return,
            isPlaying = _isPlaying.value,
            positionMs = _positionMs.value,
            durationMs = _durationMs.value
        )
    }

    fun seekTo(positionMs: Long) {
        val validDur = exoPlayer.duration.takeIf { it > 1000L }
            ?: _durationMs.value.takeIf { it > 1000L }
            ?: ((_currentTrack.value?.durationSec ?: 0L) * 1000L)
        val safeTarget = if (validDur > 2000L) {
            positionMs.coerceIn(0L, validDur - 1200L)
        } else {
            positionMs.coerceAtLeast(0L)
        }
        exoPlayer.seekTo(safeTarget)
        _positionMs.value = safeTarget
        syncNotification()
    }

    fun seekToFraction(fraction: Float) {
        val validDur = exoPlayer.duration.takeIf { it > 1000L }
            ?: _durationMs.value.takeIf { it > 1000L }
            ?: ((_currentTrack.value?.durationSec ?: 0L) * 1000L)
        if (validDur <= 1000L) return
        val targetMs = (fraction.coerceIn(0f, 0.992f) * validDur).toLong()
        seekTo(targetMs)
    }

    fun toggleFavorite(track: GoatTrack) {
        repo.toggleFavorite(track)
        refreshLibraryAndPlaylists()
        val latest = _libraryTracks.value.find { it.id == track.id }
        if (latest != null) {
            _searchResults.value = _searchResults.value.map { if (it.id == track.id) latest else it }
            _similarTracks.value = _similarTracks.value.map { if (it.id == track.id) latest else it }
        }
        syncNotification()
    }

    fun deleteDownloadedTrack(trackId: String) {
        repo.deleteDownloadedFiles(trackId)
        refreshLibraryAndPlaylists()
        _searchResults.value = _searchResults.value.map {
            if (it.id == trackId) it.copy(localAudioPath = null, localVideoPath = null) else it
        }
    }

    fun createPlaylist(name: String) {
        repo.createCustomPlaylist(name)
        refreshLibraryAndPlaylists()
    }

    fun deleteCustomPlaylist(playlistId: String) {
        repo.deleteCustomPlaylist(playlistId)
        refreshLibraryAndPlaylists()
    }

    fun toggleTrackInPlaylist(playlistId: String, track: GoatTrack) {
        when (playlistId) {
            LibraryRepository.PLAYLIST_LIKED_ID -> toggleFavorite(track)
            LibraryRepository.PLAYLIST_DOWNLOADED_ID -> {
                if (track.isDownloadedAny) {
                    deleteDownloadedTrack(track.id)
                } else {
                    downloadTrack(track, MediaFormatType.AUDIO_M4A)
                }
            }
            else -> {
                repo.toggleTrackInCustomPlaylist(playlistId, track)
                refreshLibraryAndPlaylists()
            }
        }
    }

    fun addMultipleTracksToPlaylist(playlistId: String, tracks: List<GoatTrack>) {
        repo.addMultipleTracksToPlaylist(playlistId, tracks)
        refreshLibraryAndPlaylists()
    }

    fun reorderPlaylistTracks(playlistId: String, fromIndex: Int, toIndex: Int, currentIds: List<String>) {
        repo.reorderPlaylistTracks(playlistId, fromIndex, toIndex, currentIds)
        refreshLibraryAndPlaylists()
    }

    fun playNextInQueue() {
        val queue = activeQueue.ifEmpty { _libraryTracks.value.ifEmpty { _searchResults.value } }
        if (queue.isEmpty()) return
        val curId = _currentTrack.value?.id
        val idx = queue.indexOfFirst { it.id == curId }

        if (idx in 0 until queue.lastIndex) {
            // Hayali (karıştırılmış veya sıralı) listedeki bir sonraki şarkıya geç
            playTrack(queue[idx + 1], preferVideo = false, customQueue = queue)
        } else {
            // Listenin sonuna gelindiğinde: Rastgele mod açıksa listeyi yeni oturum için tekrar karıştır!
            if (_isShuffleEnabled.value && queue.size > 1) {
                var reshuffled = queue.shuffled()
                if (reshuffled.first().id == curId) {
                    reshuffled = reshuffled.drop(1) + reshuffled.first()
                }
                activeQueue = reshuffled
                playTrack(reshuffled.first(), preferVideo = false, customQueue = reshuffled)
            } else {
                playTrack(queue.first(), preferVideo = false, customQueue = queue)
            }
        }
    }

    fun playPreviousInQueue() {
        // Bildirimden veya oynatıcıdan geri tuşuna basıldığında:
        // Şarkı 3 saniyeden (3000ms) fazla ilerlemişse önce şarkıyı en başa (0:00) al!
        // Şarkı henüz ilk 3 saniyedeyse (veya arka arkaya ikinci kez basıldıysa) önceki şarkıya geç!
        val currentPos = maxOf(exoPlayer.currentPosition, _positionMs.value)
        if (currentPos > 3_000L) {
            exoPlayer.seekTo(0L)
            _positionMs.value = 0L
            if (!exoPlayer.isPlaying) {
                exoPlayer.play()
            }
            syncNotification()
            return
        }

        val queue = activeQueue.ifEmpty { _libraryTracks.value.ifEmpty { _searchResults.value } }
        if (queue.isEmpty()) return
        val curId = _currentTrack.value?.id
        val idx = queue.indexOfFirst { it.id == curId }
        val prevTrack = if (idx > 0) queue[idx - 1] else queue.last()
        playTrack(prevTrack, preferVideo = false, customQueue = queue)
    }

    fun downloadTrack(track: GoatTrack, formatType: MediaFormatType) {
        viewModelScope.launch {
            _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                videoId = track.id,
                title = track.title,
                formatType = formatType,
                progressPercent = 1,
                statusText = "Başlatılıyor..."
            ))

            val file = GoatStreamEngine.downloadTrack(
                context = getApplication(),
                track = track,
                formatType = formatType
            ) { pct, status ->
                _downloads.value = _downloads.value + (track.id to DownloadTaskState(
                    videoId = track.id,
                    title = track.title,
                    formatType = formatType,
                    progressPercent = pct,
                    statusText = status
                ))
            }

            if (file != null && file.exists()) {
                val updatedTrack = if (formatType == MediaFormatType.AUDIO_M4A) {
                    track.copy(localAudioPath = file.absolutePath)
                } else {
                    track.copy(localVideoPath = file.absolutePath)
                }
                repo.upsertTrack(updatedTrack)
                refreshLibraryAndPlaylists()
                _searchResults.value = _searchResults.value.map {
                    if (it.id == track.id) _libraryTracks.value.find { s -> s.id == track.id } ?: updatedTrack else it
                }
                _downloads.value = _downloads.value - track.id
            } else {
                _downloads.value = _downloads.value - track.id
            }
        }
    }

    fun shutdownPlayerAndNotification() {
        runCatching { exoPlayer.stop() }
        GoatNotificationBridge.cancelNotificationAndRelease(getApplication())
    }

    override fun onCleared() {
        GoatNotificationBridge.cancelNotificationAndRelease(getApplication())
        GoatNotificationBridge.onPrevCallback = null
        GoatNotificationBridge.onPlayPauseCallback = null
        GoatNotificationBridge.onNextCallback = null
        GoatNotificationBridge.onLikeCallback = null
        GoatNotificationBridge.onSeekCallback = null
        GoatNotificationBridge.onAppSwipedClosedCallback = null
        runCatching { exoPlayer.stop() }
        runCatching { exoPlayer.release() }
        super.onCleared()
    }
}
