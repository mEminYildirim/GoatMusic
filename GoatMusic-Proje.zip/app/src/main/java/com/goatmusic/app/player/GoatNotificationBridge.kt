package com.goatmusic.app.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat.MediaStyle
import com.goatmusic.app.MainActivity
import com.goatmusic.app.R
import com.goatmusic.app.model.GoatTrack

object GoatNotificationBridge {

    const val CHANNEL_ID = "goat_music_playback_v8"
    const val NOTIFICATION_ID = 8842

    const val ACTION_PREV = "com.goatmusic.app.ACTION_PREV"
    const val ACTION_PLAY_PAUSE = "com.goatmusic.app.ACTION_PLAY_PAUSE"
    const val ACTION_NEXT = "com.goatmusic.app.ACTION_NEXT"
    const val ACTION_LIKE = "com.goatmusic.app.ACTION_LIKE"
    const val ACTION_STOP_CLOSE = "com.goatmusic.app.ACTION_STOP_CLOSE"

    var onPrevCallback: (() -> Unit)? = null
    var onPlayPauseCallback: (() -> Unit)? = null
    var onNextCallback: (() -> Unit)? = null
    var onLikeCallback: (() -> Unit)? = null
    var onSeekCallback: ((Long) -> Unit)? = null
    var onAppSwipedClosedCallback: (() -> Unit)? = null

    private var mediaSession: MediaSessionCompat? = null
    @Volatile
    var isShuttingDown: Boolean = false

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                val ch = NotificationChannel(
                    CHANNEL_ID,
                    "Goat Music Oynatıcı",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Spotify tarzı medya kontrolleri"
                    setShowBadge(false)
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun ensureMediaSession(context: Context): MediaSessionCompat {
        mediaSession?.let { return it }
        return MediaSessionCompat(context.applicationContext, "GoatMusicSession").apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() {
                    onPlayPauseCallback?.invoke()
                }

                override fun onPause() {
                    onPlayPauseCallback?.invoke()
                }

                override fun onSkipToNext() {
                    onNextCallback?.invoke()
                }

                override fun onSkipToPrevious() {
                    onPrevCallback?.invoke()
                }

                override fun onSeekTo(pos: Long) {
                    onSeekCallback?.invoke(pos)
                }

                override fun onStop() {
                    onAppSwipedClosedCallback?.invoke()
                }
            })
            isActive = true
            GoatNotificationBridge.mediaSession = this
        }
    }

    fun buildNotification(
        context: Context,
        track: GoatTrack,
        isPlaying: Boolean,
        positionMs: Long,
        durationMs: Long
    ): Notification {
        ensureChannel(context)
        val session = ensureMediaSession(context)

        val logoBitmap = runCatching {
            BitmapFactory.decodeResource(context.resources, R.drawable.goat_logo_upper)
        }.getOrNull()

        val metadata = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, track.title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, track.artist)
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, durationMs.coerceAtLeast(1L))
            .apply {
                if (logoBitmap != null) {
                    putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, logoBitmap)
                }
            }
            .build()
        session.setMetadata(metadata)

        val stateActions = PlaybackStateCompat.ACTION_PLAY or
            PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or
            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
            PlaybackStateCompat.ACTION_SEEK_TO or
            PlaybackStateCompat.ACTION_STOP

        val pbState = PlaybackStateCompat.Builder()
            .setActions(stateActions)
            .setState(
                if (isPlaying) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED,
                positionMs.coerceAtLeast(0L),
                if (isPlaying) 1.0f else 0f
            )
            .build()
        session.setPlaybackState(pbState)

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPi = PendingIntent.getActivity(
            context,
            100,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        fun serviceActionPi(action: String, reqCode: Int): PendingIntent {
            val intent = Intent(context, GoatPlaybackService::class.java).apply {
                this.action = action
            }
            return PendingIntent.getService(
                context,
                reqCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val likeIcon = if (track.isFavorite) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off
        val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play

        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(if (isPlaying) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause)
            .setLargeIcon(logoBitmap)
            .setContentTitle(track.title)
            .setContentText(track.artist)
            .setContentIntent(contentPi)
            .setDeleteIntent(serviceActionPi(ACTION_STOP_CLOSE, 105))
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setOngoing(isPlaying)
            .addAction(android.R.drawable.ic_media_previous, "Önceki", serviceActionPi(ACTION_PREV, 101))
            .addAction(playPauseIcon, if (isPlaying) "Duraklat" else "Oynat", serviceActionPi(ACTION_PLAY_PAUSE, 102))
            .addAction(android.R.drawable.ic_media_next, "Sonraki", serviceActionPi(ACTION_NEXT, 103))
            .addAction(likeIcon, "Beğen", serviceActionPi(ACTION_LIKE, 104))
            .setStyle(
                MediaStyle()
                    .setMediaSession(session.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .build()
    }

    fun updateNotification(
        context: Context,
        track: GoatTrack,
        isPlaying: Boolean,
        positionMs: Long,
        durationMs: Long
    ) {
        if (isShuttingDown) return
        runCatching {
            val notif = buildNotification(context, track, isPlaying, positionMs, durationMs)
            GoatPlaybackService.latestNotification = notif
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, notif)

            if (!GoatPlaybackService.isServiceRunning) {
                val serviceIntent = Intent(context, GoatPlaybackService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isPlaying) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            }
        }
    }

    fun cancelNotificationAndRelease(context: Context) {
        isShuttingDown = true
        GoatPlaybackService.latestNotification = null
        runCatching {
            mediaSession?.setPlaybackState(
                PlaybackStateCompat.Builder()
                    .setState(PlaybackStateCompat.STATE_NONE, 0L, 0f)
                    .build()
            )
            mediaSession?.isActive = false
            mediaSession?.release()
            mediaSession = null
        }
        runCatching {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(NOTIFICATION_ID)
            nm.cancelAll()
        }
        runCatching {
            context.stopService(Intent(context, GoatPlaybackService::class.java))
        }
    }
}
