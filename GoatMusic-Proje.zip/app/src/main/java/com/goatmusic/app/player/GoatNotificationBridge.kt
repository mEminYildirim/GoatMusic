package com.goatmusic.app.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media.app.NotificationCompat.MediaStyle
import com.goatmusic.app.MainActivity
import com.goatmusic.app.R
import com.goatmusic.app.model.GoatTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.URL

object GoatNotificationBridge {

    const val CHANNEL_ID = "goat_music_playback_channel"
    const val NOTIFICATION_ID = 4040

    const val ACTION_PREV = "com.goatmusic.app.ACTION_PREV"
    const val ACTION_PLAY_PAUSE = "com.goatmusic.app.ACTION_PLAY_PAUSE"
    const val ACTION_NEXT = "com.goatmusic.app.ACTION_NEXT"
    const val ACTION_LIKE = "com.goatmusic.app.ACTION_LIKE"
    const val ACTION_CLOSE = "com.goatmusic.app.ACTION_CLOSE"

    var onPrevCallback: (() -> Unit)? = null
    var onPlayPauseCallback: (() -> Unit)? = null
    var onNextCallback: (() -> Unit)? = null
    var onLikeCallback: (() -> Unit)? = null
    var onSeekCallback: ((Long) -> Unit)? = null
    var onAppSwipedClosedCallback: (() -> Unit)? = null

    @Volatile
    var lastBuiltNotification: Notification? = null
        private set

    private var mediaSession: MediaSessionCompat? = null
    private var cachedArtId: String? = null
    private var cachedArtBitmap: Bitmap? = null

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                val ch = NotificationChannel(
                    CHANNEL_ID,
                    "Goat Music Çalar",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Müzik oynatma kontrolleri"
                    setShowBadge(false)
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun ensureMediaSession(context: Context): MediaSessionCompat {
        mediaSession?.let { return it }
        return MediaSessionCompat(context.applicationContext, "GoatMusicSession_" + System.currentTimeMillis()).apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() {
                    onPlayPauseCallback?.invoke()
                }

                override fun onPause() {
                    onPlayPauseCallback?.invoke()
                }

                override fun onSkipToNext() {
                    onNextCallback?.invoke()
                }

                override fun onSkipToPrevious() {
                    onPrevCallback?.invoke()
                }

                override fun onSeekTo(pos: Long) {
                    onSeekCallback?.invoke(pos)
                }

                override fun onStop() {
                    onAppSwipedClosedCallback?.invoke()
                    cancelNotificationAndRelease(context.applicationContext)
                }
            })
            isActive = true
            GoatNotificationBridge.mediaSession = this
        }
    }

    fun cancelNotificationAndRelease(context: Context) {
        lastBuiltNotification = null
        try {
            context.stopService(Intent(context, GoatPlaybackService::class.java))
        } catch (_: Exception) {
        }
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(NOTIFICATION_ID)
            nm.cancelAll()
        } catch (_: Exception) {
        }
        try {
            mediaSession?.isActive = false
            mediaSession?.release()
        } catch (_: Exception) {
        }
        mediaSession = null
    }

    fun updateNotification(
        context: Context,
        track: GoatTrack,
        isPlaying: Boolean,
        positionMs: Long,
        durationMs: Long
    ) {
        ensureChannel(context)
        val session = ensureMediaSession(context)

        if (cachedArtId != track.id && track.thumbnailUrl.startsWith("http")) {
            val targetId = track.id
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val bytes = URL(track.thumbnailUrl).openStream().use { it.readBytes() }
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp != null) {
                        cachedArtId = targetId
                        cachedArtBitmap = bmp
                        if (mediaSession != null) {
                            postNotificationInternal(context, session, track, isPlaying, positionMs, durationMs)
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }

        postNotificationInternal(context, session, track, isPlaying, positionMs, durationMs)
    }

    private fun postNotificationInternal(
        context: Context,
        session: MediaSessionCompat,
        track: GoatTrack,
        isPlaying: Boolean,
        positionMs: Long,
        durationMs: Long
    ) {
        val art = if (cachedArtId == track.id && cachedArtBitmap != null) {
            cachedArtBitmap
        } else {
            BitmapFactory.decodeResource(context.resources, R.drawable.goat_logo_upper)
        }

        val stateMask = PlaybackStateCompat.ACTION_PLAY or
            PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or
            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
            PlaybackStateCompat.ACTION_SEEK_TO or
            PlaybackStateCompat.ACTION_STOP

        val pbState = PlaybackStateCompat.Builder()
            .setActions(stateMask)
            .setState(
                if (isPlaying) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED,
                positionMs,
                if (isPlaying) 1.0f else 0f
            )
            .build()
        session.setPlaybackState(pbState)

        val meta = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, track.title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, track.artist)
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, durationMs)
            .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art)
            .build()
        session.setMetadata(meta)

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPi = PendingIntent.getActivity(
            context,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        fun actionPi(action: String, reqCode: Int): PendingIntent {
            val intent = Intent(context, GoatNotificationReceiver::class.java).apply {
                this.action = action
            }
            return PendingIntent.getBroadcast(
                context,
                reqCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val likeIcon = if (track.isFavorite) {
            android.R.drawable.btn_star_big_on
        } else {
            android.R.drawable.btn_star_big_off
        }
        val playPauseIcon = if (isPlaying) {
            android.R.drawable.ic_media_pause
        } else {
            android.R.drawable.ic_media_play
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setLargeIcon(art)
            .setContentTitle(track.title)
            .setContentText(if (track.isFavorite) "♥ ${track.artist}" else track.artist)
            .setSubText("Goat Music")
            .setContentIntent(contentPi)
            .setDeleteIntent(actionPi(ACTION_CLOSE, 5))
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setOngoing(isPlaying)
            .addAction(android.R.drawable.ic_media_previous, "Önceki", actionPi(ACTION_PREV, 1))
            .addAction(playPauseIcon, if (isPlaying) "Duraklat" else "Oynat", actionPi(ACTION_PLAY_PAUSE, 2))
            .addAction(android.R.drawable.ic_media_next, "Sonraki", actionPi(ACTION_NEXT, 3))
            .addAction(likeIcon, if (track.isFavorite) "Beğenildi" else "Beğen", actionPi(ACTION_LIKE, 4))
            .setStyle(
                MediaStyle()
                    .setMediaSession(session.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .build()

        lastBuiltNotification = notification
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, notification)

        // Foreground Service'i baslat (Hem 5dk arka plan kapanmasini onler hem de uygulama kapatilinca onTaskRemoved tetikler)
        try {
            val svcIntent = Intent(context, GoatPlaybackService::class.java)
            if (isPlaying) {
                ContextCompat.startForegroundService(context, svcIntent)
            } else {
                context.startService(svcIntent)
            }
        } catch (_: Exception) {
        }
    }
}

class GoatNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        when (intent?.action) {
            GoatNotificationBridge.ACTION_PREV -> GoatNotificationBridge.onPrevCallback?.invoke()
            GoatNotificationBridge.ACTION_PLAY_PAUSE -> GoatNotificationBridge.onPlayPauseCallback?.invoke()
            GoatNotificationBridge.ACTION_NEXT -> GoatNotificationBridge.onNextCallback?.invoke()
            GoatNotificationBridge.ACTION_LIKE -> GoatNotificationBridge.onLikeCallback?.invoke()
            GoatNotificationBridge.ACTION_CLOSE -> {
                GoatNotificationBridge.onAppSwipedClosedCallback?.invoke()
                if (context != null) {
                    GoatNotificationBridge.cancelNotificationAndRelease(context.applicationContext)
                }
            }
        }
    }
}
