package com.goatmusic.app.engine

import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.LyricLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.roundToLong

object GoatLyricsEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val cache = mutableMapOf<String, List<LyricLine>>()

    private data class AsrTimedWord(
        val timeMs: Long,
        val normWord: String
    )

    private data class YouTubeVideoCaptionInfo(
        val videoDurationSec: Double,
        val videoTitle: String,
        val videoAuthor: String,
        val manualLines: List<LyricLine>,
        val asrLines: List<LyricLine>,
        val asrWords: List<AsrTimedWord>
    )

    suspend fun fetchSynchronizedLyrics(
        track: GoatTrack,
        durationMs: Long
    ): List<LyricLine> = withContext(Dispatchers.IO) {
        val durationBucket = if (durationMs > 20_000L) (durationMs / 1000L) else 0L
        val cacheKey = "${track.id}_$durationBucket"
        cache[cacheKey]?.let { if (it.isNotEmpty()) return@withContext it }

        val ytDeferred = async { fetchYouTubeCaptionInfo(track.id, durationMs) }

        val (initialArtist, initialSong) = extractArtistAndSong(track.title, track.artist)
        val rawLower = "${track.title} ${track.artist}".lowercase()
        val isSlowedTrack = rawLower.contains("slowed") || rawLower.contains("yavaş") || rawLower.contains("yavas") || rawLower.contains("reverb")
        val isSpedUpTrack = rawLower.contains("sped up") || rawLower.contains("speed up") || rawLower.contains("nightcore") || rawLower.contains("hızlandır") || rawLower.contains("hizlandir")
        val isTempoModifiedTrack = isSlowedTrack || isSpedUpTrack
        val wantRemix = rawLower.contains("remix")
        val wantLive = rawLower.contains("live") || rawLower.contains("konser") || rawLower.contains("canlı")
        val wantAcoustic = rawLower.contains("akustik") || rawLower.contains("acoustic")

        val allCandidates = mutableListOf<JSONObject>()
        if (initialSong.isNotBlank() && initialArtist.isNotBlank()) {
            fetchCandidatesFromUrl(
                "https://lrclib.net/api/search?track_name=${enc(initialSong)}&artist_name=${enc(initialArtist)}",
                allCandidates
            )
        }

        val queries = listOf(
            "$initialArtist $initialSong".trim(),
            initialSong,
            cleanNoise(track.title)
        ).distinct().filter { it.length >= 2 }

        for (q in queries) {
            if (allCandidates.size >= 35) break
            fetchCandidatesFromUrl("https://lrclib.net/api/search?q=${enc(q)}", allCandidates)
        }

        val ytInfo = ytDeferred.await()

        val trueDurationSec = when {
            durationMs > 20_000L -> durationMs / 1000.0
            ytInfo != null && ytInfo.videoDurationSec > 20.0 -> ytInfo.videoDurationSec
            track.durationSec > 20L -> track.durationSec.toDouble()
            else -> 0.0
        }
        val effectiveTotalDurationMs = if (trueDurationSec > 20.0) {
            (trueDurationSec * 1000.0).toLong()
        } else {
            210_000L
        }

        if (allCandidates.isEmpty() && ytInfo != null && ytInfo.videoTitle.isNotBlank()) {
            val (ytArtist, ytSong) = extractArtistAndSong(ytInfo.videoTitle, ytInfo.videoAuthor)
            fetchCandidatesFromUrl("https://lrclib.net/api/search?q=${enc("$ytArtist $ytSong".trim())}", allCandidates)
        }

        // ÖNCELİK 1: Videoda insan yapımı (kind != "asr") resmi şarkı sözü altyazısı varsa doğrudan kullan
        if (ytInfo != null && ytInfo.manualLines.size >= 6) {
            cache[cacheKey] = ytInfo.manualLines
            return@withContext ytInfo.manualLines
        }

        // ÖNCELİK 2: LRCLIB adaylarını puanla (Slowed/Sped-Up şarkılarda hem birebir süreli LRC'yi
        // hem de orijinal stüdyo LRC'sini kabul eder; orijinal seçilirse süre oranıyla ölçekler!)
        val scoredSynced = allCandidates
            .filter { obj ->
                val s = obj.optString("syncedLyrics")
                s.isNotBlank() && s != "null"
            }
            .mapNotNull { obj ->
                val score = scoreCandidate(
                    obj = obj,
                    expectedSong = initialSong,
                    expectedArtist = initialArtist,
                    targetDurationSec = trueDurationSec,
                    isTempoModifiedTrack = isTempoModifiedTrack,
                    wantRemix = wantRemix,
                    wantLive = wantLive,
                    wantAcoustic = wantAcoustic
                )
                if (score < 1000.0) (score to obj) else null
            }
            .sortedBy { it.first }

        for ((_, bestObj) in scoredSynced) {
            val synced = bestObj.optString("syncedLyrics")
            val lrcDurSec = bestObj.optDouble("duration", 0.0)
            val parsedLrc = parseLrcText(
                lrc = synced,
                totalDurationMs = effectiveTotalDurationMs
            )
            if (parsedLrc.size >= 4) {
                val aligned = alignLrcWithYouTubeVideo(
                    lrcLines = parsedLrc,
                    lrcDurationSec = lrcDurSec,
                    videoDurationSec = trueDurationSec,
                    isTempoModifiedTrack = isTempoModifiedTrack,
                    asrWords = ytInfo?.asrWords.orEmpty(),
                    asrLines = ytInfo?.asrLines.orEmpty(),
                    totalDurationMs = effectiveTotalDurationMs
                )
                cache[cacheKey] = aligned
                return@withContext aligned
            }
        }

        // ÖNCELİK 3: LRCLIB'de hiç kayıt yoksa YouTube ASR altyazısını kullan
        if (ytInfo != null) {
            val fallbackLines = ytInfo.manualLines.ifEmpty { ytInfo.asrLines }
            if (fallbackLines.size >= 3) {
                cache[cacheKey] = fallbackLines
                return@withContext fallbackLines
            }
        }

        emptyList()
    }

    /**
     * Şarkının orijinal stüdyo süresi (lrcDurationSec) ile çalan YouTube versiyonunun gerçek süresi
     * (videoDurationSec) arasındaki oranı (`durationRatio = videoDurationSec / lrcDurationSec`)
     * hesaplayarak özellikle Slowed / Sped-Up / Nightcore ve farklı tempolu versiyonlarda
     * tüm zaman damgalarını milimetrik olarak yeni hıza ölçekler!
     */
    private fun alignLrcWithYouTubeVideo(
        lrcLines: List<LyricLine>,
        lrcDurationSec: Double,
        videoDurationSec: Double,
        isTempoModifiedTrack: Boolean,
        asrWords: List<AsrTimedWord>,
        asrLines: List<LyricLine>,
        totalDurationMs: Long
    ): List<LyricLine> {
        if (lrcLines.isEmpty()) return lrcLines

        // Orijinal LRC süresini belirle (JSON'daki duration alanı; yoksa son satırın zamanından tahmin)
        val effectiveLrcDurSec = if (lrcDurationSec > 25.0) {
            lrcDurationSec
        } else {
            ((lrcLines.last().startMs / 1000.0) + 12.0).coerceAtLeast(30.0)
        }

        // 1. TEMEL SÜRE ORANI HESABI (Slowed / Sped-Up / Farklı Tempo Oranı):
        // Örn: Orijinal şarkı 180sn, Slowed versiyon 225sn ise ratio = 225 / 180 = 1.25 (Altyazı %25 yavaşlatılır)
        // Örn: Orijinal şarkı 200sn, Sped-Up versiyon 160sn ise ratio = 160 / 200 = 0.80 (Altyazı %20 hızlandırılır)
        val rawDurationRatio = if (videoDurationSec > 25.0 && effectiveLrcDurSec > 25.0) {
            videoDurationSec / effectiveLrcDurSec
        } else {
            1.0
        }

        val durationDiffSec = abs(videoDurationSec - effectiveLrcDurSec)

        // Hangi durumda süre oranı (ratio) doğrudan hız çarpanı olarak uygulanmalı?
        // - Şarkı başlığında slowed/sped-up varsa VEYA
        // - Süre oranı 0.55..0.94 (Sped-Up) ya da 1.06..1.65 (Slowed) aralığındaysa VEYA
        // - Süre farkı %1.5..%6 arasındaysa (25fps TV / master tempo farkı)
        var scale = when {
            durationDiffSec <= 1.2 -> 1.0
            isTempoModifiedTrack && rawDurationRatio in 0.55..1.70 -> rawDurationRatio
            rawDurationRatio in 0.60..0.94 || rawDurationRatio in 1.06..1.60 -> rawDurationRatio
            rawDurationRatio in 0.94..1.06 -> rawDurationRatio
            else -> 1.0
        }

        // Ön-ölçeklenmiş satırlar üzerinden YouTube ASR vokal kelimeleriyle ince başlangıç (intro offset) kontrolü yap
        val preScaledLines = lrcLines.map { line ->
            line.copy(startMs = (line.startMs * scale).roundToLong().coerceAtLeast(0L))
        }

        val residualOffsets = mutableListOf<Double>()

        if (asrWords.size >= 8) {
            for (line in preScaledLines) {
                val lineNormWords = normalizeForMatch(line.fullText)
                    .split(" ")
                    .filter { it.length >= 2 }
                if (lineNormWords.isEmpty()) continue

                val firstWord = lineNormWords.first()
                val secondWord = lineNormWords.getOrNull(1)

                var bestMatchTimeMs: Long? = null
                var bestDist = Long.MAX_VALUE

                for (idx in asrWords.indices) {
                    val aw = asrWords[idx]
                    val dist = abs(aw.timeMs - line.startMs)
                    if (dist > 14_000L) continue

                    val firstMatches = aw.normWord == firstWord ||
                        (firstWord.length >= 4 && aw.normWord.startsWith(firstWord.take(4)))
                    if (!firstMatches) continue

                    val verified = if (secondWord != null && idx + 1 < asrWords.size) {
                        val nextAw = asrWords[idx + 1]
                        nextAw.normWord == secondWord ||
                            (secondWord.length >= 4 && nextAw.normWord.startsWith(secondWord.take(4))) ||
                            firstWord.length >= 6
                    } else {
                        firstWord.length >= 5
                    }

                    if (verified && dist < bestDist) {
                        bestDist = dist
                        bestMatchTimeMs = aw.timeMs
                    }
                }

                if (bestMatchTimeMs != null) {
                    residualOffsets.add((bestMatchTimeMs - line.startMs).toDouble())
                }
            }
        }

        if (residualOffsets.size < 3 && asrLines.size >= 3) {
            val usedAsrIndices = mutableSetOf<Int>()
            for (lrc in preScaledLines) {
                val lrcTokens = normalizeForMatch(lrc.fullText)
                    .split(" ")
                    .filter { it.length >= 3 }
                    .toSet()
                if (lrcTokens.isEmpty()) continue

                var bestAsrIdx = -1
                var bestOverlap = 0
                var bestTimeDiff = Long.MAX_VALUE

                for (aIdx in asrLines.indices) {
                    if (usedAsrIndices.contains(aIdx)) continue
                    val asr = asrLines[aIdx]
                    val timeDiff = abs(asr.startMs - lrc.startMs)
                    if (timeDiff > 15_000L) continue

                    val asrTokens = normalizeForMatch(asr.fullText)
                        .split(" ")
                        .filter { it.length >= 3 }
                        .toSet()
                    if (asrTokens.isEmpty()) continue

                    val overlap = lrcTokens.count { tok ->
                        asrTokens.any { aTok -> aTok == tok || (tok.length >= 4 && aTok.startsWith(tok.take(4))) }
                    }
                    if (overlap > bestOverlap || (overlap == bestOverlap && overlap > 0 && timeDiff < bestTimeDiff)) {
                        bestOverlap = overlap
                        bestTimeDiff = timeDiff
                        bestAsrIdx = aIdx
                    }
                }

                if (bestAsrIdx >= 0 && (bestOverlap >= 2 || (bestOverlap == 1 && lrcTokens.size <= 2 && bestTimeDiff <= 8_000L))) {
                    usedAsrIndices.add(bestAsrIdx)
                    residualOffsets.add((asrLines[bestAsrIdx].startMs - lrc.startMs).toDouble())
                }
            }
        }

        val fineOffsetMs = if (residualOffsets.size >= 3) {
            val sorted = residualOffsets.sorted()
            val median = sorted[sorted.size / 2]
            if (abs(median) in 200.0..8000.0) median else 0.0
        } else {
            0.0
        }

        val finalLines = lrcLines.map { line ->
            val newStart = (line.startMs * scale + fineOffsetMs).roundToLong().coerceAtLeast(0L)
            line.copy(startMs = newStart)
        }

        return recomputeLineEndings(finalLines, totalDurationMs, scale)
    }

    private fun recomputeLineEndings(
        lines: List<LyricLine>,
        totalDurationMs: Long,
        tempoScale: Double = 1.0
    ): List<LyricLine> {
        if (lines.isEmpty()) return lines
        val safeScale = tempoScale.coerceIn(0.65, 1.55)
        return lines.mapIndexed { i, line ->
            val start = line.startMs
            val nextStart = if (i + 1 < lines.size) {
                lines[i + 1].startMs.coerceAtLeast(start + 450L)
            } else {
                totalDurationMs.coerceAtLeast(start + 4500L)
            }
            val gap = (nextStart - start).coerceAtLeast(450L)
            // Slowed şarkılarda kelime geçiş süresi de şarkının yavaşlama oranında (safeScale) genişler;
            // Sped-up şarkılarda ise aynı oranda hızlanır!
            val naturalHoldMs = ((line.fullText.length * 185L + 1600L) * safeScale).roundToLong().coerceIn(2000L, 9500L)
            val vocalSpan = minOf((gap * 0.92).toLong().coerceAtLeast(400L), naturalHoldMs)
            line.copy(
                startMs = start,
                endMs = (start + vocalSpan).coerceAtLeast(start + 400L)
            )
        }
    }

    private fun fetchYouTubeCaptionInfo(videoId: String, knownDurationMs: Long): YouTubeVideoCaptionInfo? {
        try {
            val visitorData = GoatStreamEngine.getCurrentVisitorData()
            val payload = JSONObject().apply {
                put("videoId", videoId)
                put("contentCheckOk", true)
                put("racyCheckOk", true)
                put("context", JSONObject().apply {
                    put("client", JSONObject().apply {
                        put("clientName", "ANDROID_VR")
                        put("clientVersion", "1.56.21")
                        put("hl", "tr")
                        put("gl", "TR")
                        put("osName", "Android")
                        put("osVersion", "12L")
                        put("deviceMake", "Oculus")
                        put("deviceModel", "Quest 3")
                        put("androidSdkVersion", 32)
                        if (!visitorData.isNullOrBlank()) put("visitorData", visitorData)
                    })
                })
            }

            val reqBuilder = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
                .header("User-Agent", GoatStreamEngine.VR_USER_AGENT)
                .header("Content-Type", "application/json")
                .header("X-YouTube-Client-Name", "28")
                .header("X-YouTube-Client-Version", "1.56.21")
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))

            if (!visitorData.isNullOrBlank()) {
                reqBuilder.header("X-Goog-Visitor-Id", visitorData)
            }
            val cookies = GoatStreamEngine.getYouTubeCookies()
            if (cookies.isNotBlank()) {
                reqBuilder.header("Cookie", cookies)
            }

            var durSec = (knownDurationMs / 1000.0).takeIf { it > 20.0 } ?: 0.0
            var vidTitle = ""
            var vidAuthor = ""
            var manualUrl: String? = null
            var asrUrl: String? = null

            client.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val root = JSONObject(resp.body?.string().orEmpty())
                val vd = root.optJSONObject("videoDetails")
                if (vd != null) {
                    val lenSec = vd.optString("lengthSeconds", "0").toDoubleOrNull() ?: 0.0
                    if (lenSec > 20.0) durSec = lenSec
                    vidTitle = vd.optString("title", "")
                    vidAuthor = vd.optString("author", "")
                }

                val tracks = root.optJSONObject("captions")
                    ?.optJSONObject("playerCaptionsTracklistRenderer")
                    ?.optJSONArray("captionTracks")

                if (tracks != null) {
                    for (i in 0 until tracks.length()) {
                        val t = tracks.optJSONObject(i) ?: continue
                        val kind = t.optString("kind", "")
                        val baseUrl = t.optString("baseUrl", "")
                        val lang = t.optString("languageCode", "")
                        if (baseUrl.isBlank()) continue
                        if (kind == "asr") {
                            if (asrUrl == null || lang.startsWith("tr") || lang.startsWith("en")) {
                                asrUrl = baseUrl
                            }
                        } else {
                            if (manualUrl == null || lang.startsWith("tr") || lang.startsWith("en")) {
                                manualUrl = baseUrl
                            }
                        }
                    }
                }
            }

            val totalMs = ((durSec.takeIf { it > 20.0 } ?: 200.0) * 1000.0).toLong()
            val manualParsed = manualUrl?.let { downloadJson3LinesAndWords(it, totalMs) }
            val asrParsed = asrUrl?.let { downloadJson3LinesAndWords(it, totalMs) }

            return YouTubeVideoCaptionInfo(
                videoDurationSec = durSec,
                videoTitle = vidTitle,
                videoAuthor = vidAuthor,
                manualLines = manualParsed?.first.orEmpty(),
                asrLines = asrParsed?.first.orEmpty(),
                asrWords = asrParsed?.second.orEmpty()
            )
        } catch (_: Exception) {
            return null
        }
    }

    private fun downloadJson3LinesAndWords(
        baseUrl: String,
        totalDurationMs: Long
    ): Pair<List<LyricLine>, List<AsrTimedWord>> {
        try {
            val json3Url = if (baseUrl.contains("fmt=")) {
                baseUrl.replace(Regex("fmt=[^&]+"), "fmt=json3")
            } else {
                "$baseUrl&fmt=json3"
            }
            val req = Request.Builder()
                .url(json3Url)
                .header("User-Agent", GoatStreamEngine.VR_USER_AGENT)
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList<LyricLine>() to emptyList()
                val root = JSONObject(resp.body?.string().orEmpty())
                val events = root.optJSONArray("events") ?: return emptyList<LyricLine>() to emptyList()
                val rawList = mutableListOf<LyricLine>()
                val timedWords = mutableListOf<AsrTimedWord>()

                for (i in 0 until events.length()) {
                    val ev = events.optJSONObject(i) ?: continue
                    val startMs = ev.optLong("tStartMs", -1L)
                    val durMs = ev.optLong("dDurationMs", 2800L)
                    if (startMs < 0L) continue
                    val segs = ev.optJSONArray("segs") ?: continue
                    val sb = StringBuilder()
                    for (j in 0 until segs.length()) {
                        val segObj = segs.optJSONObject(j) ?: continue
                        val utf8 = segObj.optString("utf8").orEmpty()
                        val offsetMs = segObj.optLong("tOffsetMs", 0L)
                        sb.append(utf8)

                        val normW = normalizeForMatch(utf8)
                        if (normW.length >= 2 && normW != "muzik" && normW != "music") {
                            normW.split(" ").filter { it.length >= 2 }.forEach { wToken ->
                                timedWords.add(AsrTimedWord(timeMs = startMs + offsetMs, normWord = wToken))
                            }
                        }
                    }
                    val text = sb.toString()
                        .replace("\n", " ")
                        .replace(Regex("\\[[^]]*]"), " ")
                        .replace(Regex("\\([^)]*\\)"), " ")
                        .replace("♪", " ")
                        .replace("♫", " ")
                        .replace(Regex("\\s+"), " ")
                        .trim()

                    if (text.length >= 2 && !text.equals("müzik", ignoreCase = true) && !text.equals("music", ignoreCase = true)) {
                        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
                        if (words.isNotEmpty()) {
                            rawList.add(
                                LyricLine(
                                    startMs = startMs,
                                    endMs = (startMs + durMs).coerceAtMost(totalDurationMs).coerceAtLeast(startMs + 500L),
                                    words = words,
                                    fullText = text
                                )
                            )
                        }
                    }
                }
                return recomputeLineEndings(rawList, totalDurationMs) to timedWords
            }
        } catch (_: Exception) {
            return emptyList<LyricLine>() to emptyList()
        }
    }

    private fun fetchCandidatesFromUrl(url: String, outList: MutableList<JSONObject>) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "GoatMusic/13.0 (Android)")
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val arr = JSONArray(resp.body?.string().orEmpty())
                    val existingIds = outList.map { it.optInt("id", -1) }.toSet()
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val id = obj.optInt("id", -1)
                        if (id == -1 || !existingIds.contains(id)) {
                            outList.add(obj)
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun extractArtistAndSong(rawTitle: String, rawChannel: String): Pair<String, String> {
        val cleanTitle = cleanNoise(rawTitle)
        val cleanChannel = rawChannel
            .replace(Regex("(?i)(-\\s*topic|vevo|official|resmi|müzik|muzik|music|records|yapım|yapim|production|netd)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val separators = listOf(" - ", " – ", " — ", " | ", " // ")
        for (sep in separators) {
            if (cleanTitle.contains(sep)) {
                val parts = cleanTitle.split(sep, limit = 2).map { it.trim() }
                if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                    return parts[0] to parts[1]
                }
            }
        }
        return cleanChannel to cleanTitle
    }

    /**
     * Başlıktan parantez içi gürültüleri VE slowed/sped-up/reverb/nightcore etiketlerini temizler ki
     * LRCLIB üzerinde şarkının orijinal stüdyo kaydı her zaman bulunabilsin!
     */
    private fun cleanNoise(raw: String): String {
        return raw
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\[[^]]*]"), " ")
            .replace(
                Regex("(?i)(official\\s*music\\s*video|official\\s*video|official\\s*audio|music\\s*video|lyric\\s*video|lyrics|lyric|şarkı\\s*sözleri|sarki\\s*sozleri|slowed\\s*\\+?\\s*reverb|slowed\\s*and\\s*reverb|slowed|reverb|sped\\s*up|speed\\s*up|nightcore|yavaşlatılmış|yavaslatilmis|hızlandırılmış|hizlandirilmis|tiktok\\s*version|tiktok\\s*edit|hd|4k|hq|visualizer|klip|video\\s*klip|feat\\.?|ft\\.?)"),
                " "
            )
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeForMatch(s: String): String {
        return s.lowercase()
            .replace('ı', 'i')
            .replace('İ', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun scoreCandidate(
        obj: JSONObject,
        expectedSong: String,
        expectedArtist: String,
        targetDurationSec: Double,
        isTempoModifiedTrack: Boolean,
        wantRemix: Boolean,
        wantLive: Boolean,
        wantAcoustic: Boolean
    ): Double {
        val rawCandTrack = obj.optString("trackName", "")
        val rawCandArtist = obj.optString("artistName", "")
        val candTrack = cleanNoise(rawCandTrack)
        val candDur = obj.optDouble("duration", 0.0)

        val normCandTrack = normalizeForMatch(candTrack)
        val normCandArtist = normalizeForMatch(rawCandArtist)
        val normExpectedSong = normalizeForMatch(expectedSong)
        val normExpectedArtist = normalizeForMatch(expectedArtist)

        val songTokens = normExpectedSong.split(" ").filter { it.length >= 2 }
        if (songTokens.isNotEmpty()) {
            val matchedTokens = songTokens.count { token ->
                normCandTrack.contains(token) || normCandArtist.contains(token)
            }
            if (matchedTokens == 0 && !normCandTrack.contains(normExpectedSong.take(5))) {
                return 9999.0
            }
        }

        val combinedRawCand = normalizeForMatch("$rawCandTrack $rawCandArtist")
        if (!wantRemix && combinedRawCand.contains("remix")) return 9999.0
        if (!wantLive && (combinedRawCand.contains("live") || combinedRawCand.contains("konser"))) return 9999.0
        if (!wantAcoustic && (combinedRawCand.contains("acoustic") || combinedRawCand.contains("akustik"))) return 9999.0

        // Eğer dinlenen şarkı normal hızdaysa, slowed/sped-up LRC adaylarını ele:
        if (!isTempoModifiedTrack) {
            if (combinedRawCand.contains("slowed") || combinedRawCand.contains("sped up") ||
                combinedRawCand.contains("speed up") || combinedRawCand.contains("nightcore")
            ) {
                return 9999.0
            }
        }

        val durScore = if (targetDurationSec > 20.0 && candDur > 20.0) {
            val diff = abs(candDur - targetDurationSec)
            val ratio = targetDurationSec / candDur
            when {
                // 1) Süresi videoyla birebir (±2.0sn) uyuşan LRC (en yüksek öncelik)
                diff <= 2.0 -> -45.0
                diff <= 5.0 -> -25.0 + diff * 2.0
                // 2) Slowed veya Sped-Up şarkılarda orijinal stüdyo kaydı (oran 0.58x .. 1.65x arasındadır):
                // Asla reddetme! Seçildiğinde alignLrcWithYouTubeVideo içinde tam oranla ölçeklenecek!
                isTempoModifiedTrack && ratio in 0.58..1.65 -> -12.0 + abs(1.0 - ratio) * 15.0
                // 3) Başlığında slowed/sped-up yazmasa bile süresi %62..%155 oranında olan aynı şarkının orijinal kaydı:
                ratio in 0.62..1.55 -> diff * 0.8
                else -> return 9999.0
            }
        } else {
            10.0
        }

        val exactSongBonus = if (normCandTrack == normExpectedSong) -24.0
        else if (normCandTrack.contains(normExpectedSong) || normExpectedSong.contains(normCandTrack)) -12.0
        else 12.0

        val artistTokens = normExpectedArtist.split(" ").filter { it.length >= 2 }
        val artistMatched = artistTokens.any { normCandArtist.contains(it) || normCandTrack.contains(it) }
        val artistPenalty = if (artistMatched) -12.0 else 14.0

        return durScore + exactSongBonus + artistPenalty
    }

    private fun parseLrcText(
        lrc: String,
        totalDurationMs: Long
    ): List<LyricLine> {
        val rawEntries = mutableListOf<Pair<Long, String>>()
        val timestampRegex = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")
        val inlineTagRegex = Regex("<\\d{1,2}:\\d{2}(?:[.:]\\d{1,3})?>")

        val offsetMatch = Regex("(?i)\\[offset:\\s*([+-]?\\d+)\\s*]").find(lrc)
        val lrcHeaderOffsetMs = offsetMatch?.groupValues?.get(1)?.toLongOrNull() ?: 0L

        for (rawLine in lrc.lines()) {
            val line = rawLine.trim()
            val matches = timestampRegex.findAll(line).toList()
            if (matches.isEmpty()) continue

            val cleanText = line
                .replace(timestampRegex, "")
                .replace(inlineTagRegex, " ")
                .replace(Regex("\\s+"), " ")
                .trim()

            if (cleanText.isBlank()) continue

            for (m in matches) {
                val min = m.groupValues[1].toLongOrNull() ?: 0L
                val sec = m.groupValues[2].toLongOrNull() ?: 0L
                val fracStr = m.groupValues[3]
                val millis = when (fracStr.length) {
                    1 -> (fracStr.toLongOrNull() ?: 0L) * 100L
                    2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                    3 -> fracStr.toLongOrNull() ?: 0L
                    else -> 0L
                }
                val timeMs = (min * 60_000L + sec * 1_000L + millis - lrcHeaderOffsetMs).coerceAtLeast(0L)
                rawEntries.add(timeMs to cleanText)
            }
        }

        if (rawEntries.isEmpty()) return emptyList()
        rawEntries.sortBy { it.first }

        val deduped = mutableListOf<Pair<Long, String>>()
        for (entry in rawEntries) {
            val last = deduped.lastOrNull()
            if (last == null || abs(last.first - entry.first) > 80L || last.second != entry.second) {
                deduped.add(entry)
            }
        }

        val initialLines = deduped.map { (start, text) ->
            val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
            LyricLine(
                startMs = start,
                endMs = start + 2500L,
                words = words,
                fullText = text
            )
        }
        return recomputeLineEndings(initialLines, totalDurationMs, 1.0)
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}
