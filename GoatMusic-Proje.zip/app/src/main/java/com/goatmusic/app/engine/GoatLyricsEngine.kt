package com.goatmusic.app.engine

import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.LyricLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.math.abs

object GoatLyricsEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val cache = mutableMapOf<String, List<LyricLine>>()

    suspend fun fetchSynchronizedLyrics(
        track: GoatTrack,
        durationMs: Long,
        forceRefresh: Boolean = false
    ): List<LyricLine> = withContext(Dispatchers.IO) {
        val cacheKey = "${track.id}_${durationMs / 1000L}"
        if (!forceRefresh) {
            cache[cacheKey]?.let { if (it.isNotEmpty()) return@withContext it }
        }

        val cleanedTitle = cleanSearchTitle(track.title)
        val cleanedArtist = track.artist
            .replace(" - Topic", "", ignoreCase = true)
            .replace("VEVO", "", ignoreCase = true)
            .replace("Official", "", ignoreCase = true)
            .trim()

        val targetDurationSec = (durationMs / 1000.0).takeIf { it > 20.0 }
            ?: track.durationSec.toDouble().takeIf { it > 20.0 }
            ?: 180.0

        val queries = listOf(
            "$cleanedTitle $cleanedArtist".trim(),
            cleanedTitle
        ).distinct().filter { it.isNotBlank() }

        for (q in queries) {
            try {
                val encoded = URLEncoder.encode(q, "UTF-8")
                val req = Request.Builder()
                    .url("https://lrclib.net/api/search?q=$encoded")
                    .header("User-Agent", "GoatMusic/10.0 (Android)")
                    .build()

                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val arr = JSONArray(resp.body?.string().orEmpty())
                        val candidates = mutableListOf<JSONObject>()
                        for (i in 0 until arr.length()) {
                            arr.optJSONObject(i)?.let { candidates.add(it) }
                        }

                        // 1. Önce senkronize (zaman damgalı) adayları süre uyumuna ve sanatçı/isim eşleşmesine göre sırala
                        val syncedCandidates = candidates.filter {
                            val s = it.optString("syncedLyrics")
                            s.isNotBlank() && s != "null"
                        }.sortedBy { obj ->
                            scoreCandidate(obj, cleanedTitle, cleanedArtist, targetDurationSec)
                        }

                        for (bestObj in syncedCandidates) {
                            val synced = bestObj.optString("syncedLyrics")
                            val lrcDurationSec = bestObj.optDouble("duration", targetDurationSec)
                            val parsed = parseLrcText(
                                lrc = synced,
                                totalDurationMs = (targetDurationSec * 1000.0).toLong(),
                                lrcDurationMs = (lrcDurationSec * 1000.0).toLong()
                            )
                            if (parsed.isNotEmpty()) {
                                cache[cacheKey] = parsed
                                return@withContext parsed
                            }
                        }

                        // 2. Senkronize yoksa düz şarkı sözünü enstrümantal giriş ve çıkışı hesaba katarak dağıt
                        val plainCandidates = candidates.filter {
                            val p = it.optString("plainLyrics")
                            p.isNotBlank() && p != "null"
                        }.sortedBy { obj ->
                            scoreCandidate(obj, cleanedTitle, cleanedArtist, targetDurationSec)
                        }

                        for (bestPlain in plainCandidates) {
                            val plain = bestPlain.optString("plainLyrics")
                            val parsed = parsePlainLyricsWithTiming(
                                plain = plain,
                                totalDurationMs = (targetDurationSec * 1000.0).toLong()
                            )
                            if (parsed.isNotEmpty()) {
                                cache[cacheKey] = parsed
                                return@withContext parsed
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        emptyList()
    }

    private fun scoreCandidate(
        obj: JSONObject,
        cleanedTitle: String,
        cleanedArtist: String,
        targetDurationSec: Double
    ): Double {
        val candDur = obj.optDouble("duration", 0.0)
        val durDiff = if (candDur > 10.0 && targetDurationSec > 10.0) {
            abs(candDur - targetDurationSec)
        } else {
            25.0
        }
        val trackName = obj.optString("trackName", "").lowercase()
        val artistName = obj.optString("artistName", "").lowercase()
        val titlePenalty = if (cleanedTitle.isNotBlank() && trackName.contains(cleanedTitle.take(8).lowercase())) 0.0 else 12.0
        val artistPenalty = if (cleanedArtist.isNotBlank() && artistName.contains(cleanedArtist.take(6).lowercase())) 0.0 else 8.0
        return durDiff + titlePenalty + artistPenalty
    }

    private fun cleanSearchTitle(raw: String): String {
        return raw
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\[[^]]*]"), " ")
            .replace(Regex("(?i)(official|video|audio|lyrics|lyric|hd|4k|hq|visualizer|klip|feat\\.?|ft\\.?)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun parseLrcText(
        lrc: String,
        totalDurationMs: Long,
        lrcDurationMs: Long
    ): List<LyricLine> {
        val rawEntries = mutableListOf<Pair<Long, String>>()
        val lineRegex = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?](.*)")

        for (line in lrc.lines()) {
            val match = lineRegex.find(line.trim()) ?: continue
            val min = match.groupValues[1].toLongOrNull() ?: 0L
            val sec = match.groupValues[2].toLongOrNull() ?: 0L
            val fracStr = match.groupValues[3]
            val millis = when (fracStr.length) {
                1 -> (fracStr.toLongOrNull() ?: 0L) * 100L
                2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                3 -> fracStr.toLongOrNull() ?: 0L
                else -> 0L
            }
            val timeMs = min * 60_000L + sec * 1_000L + millis
            val text = match.groupValues[4].trim()
            if (text.isNotBlank()) {
                rawEntries.add(timeMs to text)
            }
        }

        if (rawEntries.isEmpty()) return emptyList()
        rawEntries.sortBy { it.first }

        // YouTube kliplerinde stüdyo kaydına kıyasla bulunan giriş farkını (intro lead-in) ve
        // ses tamponu/vokal başlangıç gecikmesini otomatik dengele (sözlerin önden gitmesini engeller)
        val youtubeIntroDeltaMs = if (totalDurationMs > lrcDurationMs && (totalDurationMs - lrcDurationMs) in 700L..9000L) {
            ((totalDurationMs - lrcDurationMs) * 0.72).toLong().coerceIn(0L, 5500L)
        } else {
            0L
        }
        // Ham LRC zaman damgaları vokal nefesinden ~1.45sn erken başlar; tam vokale oturması için kalibrasyon:
        val calibratedDelayMs = 1450L + youtubeIntroDeltaMs

        val result = mutableListOf<LyricLine>()
        for (i in rawEntries.indices) {
            val start = (rawEntries[i].first + calibratedDelayMs).coerceAtLeast(0L)
            val nextStart = if (i + 1 < rawEntries.size) {
                (rawEntries[i + 1].first + calibratedDelayMs).coerceAtLeast(start + 600L)
            } else {
                totalDurationMs.coerceAtLeast(start + 4500L)
            }
            // Şarkıcı satırı iki satır arasındaki boşluğun tamamında değil, aktif vokal penceresinde söyler
            val rawSpan = (nextStart - start).coerceAtLeast(600L)
            val vocalEnd = start + (rawSpan * 0.88).toLong().coerceIn(550L, 6500L)
            val text = rawEntries[i].second
            val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
            result.add(
                LyricLine(
                    startMs = start,
                    endMs = vocalEnd.coerceAtMost(nextStart),
                    words = words,
                    fullText = text
                )
            )
        }
        return result
    }

    private fun parsePlainLyricsWithTiming(plain: String, totalDurationMs: Long): List<LyricLine> {
        val cleanLines = plain.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (cleanLines.isEmpty()) return emptyList()
        val effectiveDuration = totalDurationMs.takeIf { it > 25_000L } ?: 180_000L
        // Enstrümantal giriş (%11 veya en az 12sn) ve çıkış (%9) payı bırak
        val introOffsetMs = (effectiveDuration * 0.11).toLong().coerceIn(11_000L, 20_000L)
        val outroReserveMs = (effectiveDuration * 0.09).toLong().coerceIn(8_000L, 18_000L)
        val singingWindowMs = (effectiveDuration - introOffsetMs - outroReserveMs).coerceAtLeast(30_000L)
        val step = singingWindowMs / cleanLines.size.coerceAtLeast(1)

        return cleanLines.mapIndexed { idx, text ->
            val start = introOffsetMs + idx * step
            val end = start + (step * 0.88).toLong().coerceAtLeast(600L)
            val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
            LyricLine(
                startMs = start,
                endMs = end,
                words = words,
                fullText = text
            )
        }
    }
}
