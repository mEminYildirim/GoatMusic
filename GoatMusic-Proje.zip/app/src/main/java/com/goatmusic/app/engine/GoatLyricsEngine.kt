package com.goatmusic.app.engine

import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.LyricLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object GoatLyricsEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val cache = mutableMapOf<String, List<LyricLine>>()

    suspend fun fetchSynchronizedLyrics(track: GoatTrack, durationMs: Long): List<LyricLine> =
        withContext(Dispatchers.IO) {
            cache[track.id]?.let { if (it.isNotEmpty()) return@withContext it }

            val cleanedTitle = cleanSearchTitle(track.title)
            val cleanedArtist = track.artist
                .replace(" - Topic", "", ignoreCase = true)
                .replace("VEVO", "", ignoreCase = true)
                .trim()

            val queries = listOf(
                "$cleanedTitle $cleanedArtist".trim(),
                cleanedTitle
            ).distinct().filter { it.isNotBlank() }

            for (q in queries) {
                try {
                    val encoded = URLEncoder.encode(q, "UTF-8")
                    val req = Request.Builder()
                        .url("https://lrclib.net/api/search?q=$encoded")
                        .header("User-Agent", "GoatMusic/8.0 (Android)")
                        .build()

                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val arr = JSONArray(resp.body?.string().orEmpty())
                            // 1. Önce senkronize (zaman damgalı) şarkı sözü ara
                            for (i in 0 until arr.length()) {
                                val obj = arr.optJSONObject(i) ?: continue
                                val synced = obj.optString("syncedLyrics")
                                if (synced.isNotBlank() && synced != "null") {
                                    val parsed = parseLrcText(synced, durationMs)
                                    if (parsed.isNotEmpty()) {
                                        cache[track.id] = parsed
                                        return@withContext parsed
                                    }
                                }
                            }
                            // 2. Senkronize yoksa düz şarkı sözünü şarkı süresine orantılı dağıt
                            for (i in 0 until arr.length()) {
                                val obj = arr.optJSONObject(i) ?: continue
                                val plain = obj.optString("plainLyrics")
                                if (plain.isNotBlank() && plain != "null") {
                                    val parsed = parsePlainLyricsWithTiming(plain, durationMs)
                                    if (parsed.isNotEmpty()) {
                                        cache[track.id] = parsed
                                        return@withContext parsed
                                    }
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }
            emptyList()
        }

    private fun cleanSearchTitle(raw: String): String {
        return raw
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\[[^]]*]"), " ")
            .replace(Regex("(?i)(official|video|audio|lyrics|lyric|hd|4k|hq|visualizer|klip|feat\\.?|ft\\.?)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun parseLrcText(lrc: String, totalDurationMs: Long): List<LyricLine> {
        val rawEntries = mutableListOf<Pair<Long, String>>()
        val lineRegex = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?](.*)")

        for (line in lrc.lines()) {
            val match = lineRegex.find(line.trim()) ?: continue
            val min = match.groupValues[1].toLongOrNull() ?: 0L
            val sec = match.groupValues[2].toLongOrNull() ?: 0L
            val fracStr = match.groupValues[3]
            val millis = when (fracStr.length) {
                1 -> (fracStr.toLongOrNull() ?: 0L) * 100L
                2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                3 -> fracStr.toLongOrNull() ?: 0L
                else -> 0L
            }
            val timeMs = min * 60_000L + sec * 1_000L + millis
            val text = match.groupValues[4].trim()
            if (text.isNotBlank()) {
                rawEntries.add(timeMs to text)
            }
        }

        if (rawEntries.isEmpty()) return emptyList()
        rawEntries.sortBy { it.first }

        val result = mutableListOf<LyricLine>()
        for (i in rawEntries.indices) {
            val start = rawEntries[i].first
            val end = if (i + 1 < rawEntries.size) {
                rawEntries[i + 1].first
            } else {
                totalDurationMs.coerceAtLeast(start + 4000L)
            }
            val text = rawEntries[i].second
            val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
            result.add(
                LyricLine(
                    startMs = start,
                    endMs = end.coerceAtLeast(start + 500L),
                    words = words,
                    fullText = text
                )
            )
        }
        return result
    }

    private fun parsePlainLyricsWithTiming(plain: String, totalDurationMs: Long): List<LyricLine> {
        val cleanLines = plain.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (cleanLines.isEmpty()) return emptyList()
        val effectiveDuration = totalDurationMs.takeIf { it > 15_000L } ?: 180_000L
        val step = effectiveDuration / cleanLines.size.coerceAtLeast(1)

        return cleanLines.mapIndexed { idx, text ->
            val start = idx * step
            val end = (idx + 1) * step
            val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
            LyricLine(
                startMs = start,
                endMs = end,
                words = words,
                fullText = text
            )
        }
    }
}
