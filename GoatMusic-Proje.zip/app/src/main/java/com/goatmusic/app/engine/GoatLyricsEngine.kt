package com.goatmusic.app.engine

import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.LyricLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.math.abs

object GoatLyricsEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val cache = mutableMapOf<String, List<LyricLine>>()

    suspend fun fetchSynchronizedLyrics(
        track: GoatTrack,
        durationMs: Long
    ): List<LyricLine> = withContext(Dispatchers.IO) {
        val targetDurationSec = (durationMs / 1000.0).takeIf { it > 20.0 }
            ?: track.durationSec.toDouble().takeIf { it > 20.0 }
            ?: 0.0

        val cacheKey = "${track.id}_${targetDurationSec.toInt()}"
        cache[cacheKey]?.let { if (it.isNotEmpty()) return@withContext it }

        val (parsedArtist, parsedSongTitle) = extractArtistAndSong(track.title, track.artist)
        val rawLower = "${track.title} ${track.artist}".lowercase()
        val wantRemix = rawLower.contains("remix")
        val wantSlowed = rawLower.contains("slowed")
        val wantSpedUp = rawLower.contains("sped up") || rawLower.contains("speed up")
        val wantLive = rawLower.contains("live") || rawLower.contains("konser") || rawLower.contains("canlı")
        val wantAcoustic = rawLower.contains("akustik") || rawLower.contains("acoustic")

        val allCandidates = mutableListOf<JSONObject>()

        // 1. Önce LRCLIB tam alan araması (track_name + artist_name)
        if (parsedSongTitle.isNotBlank() && parsedArtist.isNotBlank()) {
            val url = "https://lrclib.net/api/search?track_name=${enc(parsedSongTitle)}&artist_name=${enc(parsedArtist)}"
            fetchCandidatesFromUrl(url, allCandidates)
        }

        // 2. Genel arama sorguları
        val queries = listOf(
            "$parsedArtist $parsedSongTitle".trim(),
            parsedSongTitle,
            cleanNoise(track.title)
        ).distinct().filter { it.length >= 2 }

        for (q in queries) {
            if (allCandidates.size >= 30) break
            val url = "https://lrclib.net/api/search?q=${enc(q)}"
            fetchCandidatesFromUrl(url, allCandidates)
        }

        // Adayları şarkı adı doğrulaması, versiyon uyumu (remix/slowed/live filtresi) ve saniye farkına göre puanla
        val scoredSynced = allCandidates
            .filter { obj ->
                val s = obj.optString("syncedLyrics")
                s.isNotBlank() && s != "null"
            }
            .mapNotNull { obj ->
                val score = scoreCandidate(
                    obj = obj,
                    expectedSong = parsedSongTitle,
                    expectedArtist = parsedArtist,
                    targetDurationSec = targetDurationSec,
                    wantRemix = wantRemix,
                    wantSlowed = wantSlowed,
                    wantSpedUp = wantSpedUp,
                    wantLive = wantLive,
                    wantAcoustic = wantAcoustic
                )
                if (score < 1000.0) (score to obj) else null
            }
            .sortedBy { it.first }

        for ((_, bestObj) in scoredSynced) {
            val synced = bestObj.optString("syncedLyrics")
            val lrcDurSec = bestObj.optDouble("duration", targetDurationSec)
            val effectiveDurMs = if (targetDurationSec > 20.0) {
                (targetDurationSec * 1000.0).toLong()
            } else {
                (lrcDurSec * 1000.0).toLong().coerceAtLeast(180_000L)
            }
            val parsed = parseLrcText(
                lrc = synced,
                totalDurationMs = effectiveDurMs
            )
            if (parsed.size >= 3) {
                cache[cacheKey] = parsed
                return@withContext parsed
            }
        }

        // 3. LRCLIB üzerinde gerçek zaman damgalı (.lrc) kayıt bulunamazsa,
        // doğrudan oynatılan YouTube videosunun kendi zaman damgalı altyazılarını (json3) çek
        val ytSynced = fetchYouTubeTimedCaptions(track.id, (targetDurationSec * 1000.0).toLong().coerceAtLeast(180_000L))
        if (ytSynced.size >= 3) {
            cache[cacheKey] = ytSynced
            return@withContext ytSynced
        }

        emptyList()
    }

    private fun fetchCandidatesFromUrl(url: String, outList: MutableList<JSONObject>) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "GoatMusic/11.0 (Android)")
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val arr = JSONArray(resp.body?.string().orEmpty())
                    val existingIds = outList.map { it.optInt("id", -1) }.toSet()
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val id = obj.optInt("id", -1)
                        if (id == -1 || !existingIds.contains(id)) {
                            outList.add(obj)
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    /**
     * YouTube başlıklarındaki "Sanatçı - Şarkı Adı (Official Video)" yapısını doğru şekilde ayrıştırır.
     */
    private fun extractArtistAndSong(rawTitle: String, rawChannel: String): Pair<String, String> {
        val cleanTitle = cleanNoise(rawTitle)
        val cleanChannel = rawChannel
            .replace(Regex("(?i)(-\\s*topic|vevo|official|resmi|müzik|muzik|music|records|yapım|yapim|production|netd)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val separators = listOf(" - ", " – ", " — ", " | ", " // ")
        for (sep in separators) {
            if (cleanTitle.contains(sep)) {
                val parts = cleanTitle.split(sep, limit = 2).map { it.trim() }
                if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                    return parts[0] to parts[1]
                }
            }
        }
        return cleanChannel to cleanTitle
    }

    private fun cleanNoise(raw: String): String {
        return raw
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\[[^]]*]"), " ")
            .replace(Regex("(?i)(official\\s*music\\s*video|official\\s*video|official\\s*audio|music\\s*video|lyric\\s*video|lyrics|lyric|şarkı\\s*sözleri|sarki\\s*sozleri|hd|4k|hq|visualizer|klip|video\\s*klip|feat\\.?|ft\\.?)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeForMatch(s: String): String {
        return s.lowercase()
            .replace('ı', 'i')
            .replace('İ', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun scoreCandidate(
        obj: JSONObject,
        expectedSong: String,
        expectedArtist: String,
        targetDurationSec: Double,
        wantRemix: Boolean,
        wantSlowed: Boolean,
        wantSpedUp: Boolean,
        wantLive: Boolean,
        wantAcoustic: Boolean
    ): Double {
        val candTrack = obj.optString("trackName", "")
        val candArtist = obj.optString("artistName", "")
        val candDur = obj.optDouble("duration", 0.0)

        val normCandTrack = normalizeForMatch(candTrack)
        val normCandArtist = normalizeForMatch(candArtist)
        val normExpectedSong = normalizeForMatch(expectedSong)
        val normExpectedArtist = normalizeForMatch(expectedArtist)

        // Şarkı adı kelime eşleşmesi kontrolü (Yanlış şarkı seçilmesini kesin olarak engeller)
        val songTokens = normExpectedSong.split(" ").filter { it.length >= 2 }
        if (songTokens.isNotEmpty()) {
            val matchedTokens = songTokens.count { token ->
                normCandTrack.contains(token) || normCandArtist.contains(token)
            }
            if (matchedTokens == 0 && !normCandTrack.contains(normExpectedSong.take(5))) {
                return 9999.0
            }
        }

        // Tempo/Versiyon sapmasını (sonradan başka kelimelere kaymayı) önlemek için versiyon filtresi:
        val combinedCand = "$normCandTrack $normCandArtist"
        if (!wantRemix && combinedCand.contains("remix")) return 9999.0
        if (!wantSlowed && (combinedCand.contains("slowed") || combinedCand.contains("reverb"))) return 9999.0
        if (!wantSpedUp && (combinedCand.contains("sped up") || combinedCand.contains("speed up") || combinedCand.contains("nightcore"))) return 9999.0
        if (!wantLive && (combinedCand.contains("live") || combinedCand.contains("konser"))) return 9999.0
        if (!wantAcoustic && (combinedCand.contains("acoustic") || combinedCand.contains("akustik"))) return 9999.0

        // Süre farkı: Şarkı süresi biliniyorsa ve 15 saniyeden fazla fark varsa farklı bir versiyondur
        val durPenalty = if (targetDurationSec > 20.0 && candDur > 20.0) {
            val diff = abs(candDur - targetDurationSec)
            if (diff > 15.0) return 9999.0
            diff * 2.5
        } else {
            10.0
        }

        val exactSongBonus = if (normCandTrack == normExpectedSong) -18.0
        else if (normCandTrack.contains(normExpectedSong) || normExpectedSong.contains(normCandTrack)) -9.0
        else 10.0

        val artistTokens = normExpectedArtist.split(" ").filter { it.length >= 2 }
        val artistMatched = artistTokens.any { normCandArtist.contains(it) || normCandTrack.contains(it) }
        val artistPenalty = if (artistMatched) -8.0 else 12.0

        return durPenalty + exactSongBonus + artistPenalty
    }

    /**
     * LRC metnindeki TÜM zaman damgalarını (aynı satırda birden fazla [mm:ss.xx] olan nakaratlar dahil)
     * eksiksiz ayrıştırır ve yapay gecikme eklemeden orijinal stüdyo milisaniyeleriyle sıralar.
     */
    private fun parseLrcText(
        lrc: String,
        totalDurationMs: Long
    ): List<LyricLine> {
        val rawEntries = mutableListOf<Pair<Long, String>>()
        val timestampRegex = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")
        val inlineTagRegex = Regex("<\\d{1,2}:\\d{2}(?:[.:]\\d{1,3})?>")

        val offsetMatch = Regex("(?i)\\[offset:\\s*([+-]?\\d+)\\s*]").find(lrc)
        val lrcHeaderOffsetMs = offsetMatch?.groupValues?.get(1)?.toLongOrNull() ?: 0L

        for (rawLine in lrc.lines()) {
            val line = rawLine.trim()
            val matches = timestampRegex.findAll(line).toList()
            if (matches.isEmpty()) continue

            val cleanText = line
                .replace(timestampRegex, "")
                .replace(inlineTagRegex, " ")
                .replace(Regex("\\s+"), " ")
                .trim()

            if (cleanText.isBlank()) continue

            // Aynı satırda birden fazla zaman damgası varsa (örn. [00:45.10][01:52.30]Nakarat) hepsini ekle!
            for (m in matches) {
                val min = m.groupValues[1].toLongOrNull() ?: 0L
                val sec = m.groupValues[2].toLongOrNull() ?: 0L
                val fracStr = m.groupValues[3]
                val millis = when (fracStr.length) {
                    1 -> (fracStr.toLongOrNull() ?: 0L) * 100L
                    2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                    3 -> fracStr.toLongOrNull() ?: 0L
                    else -> 0L
                }
                val timeMs = (min * 60_000L + sec * 1_000L + millis - lrcHeaderOffsetMs).coerceAtLeast(0L)
                rawEntries.add(timeMs to cleanText)
            }
        }

        if (rawEntries.isEmpty()) return emptyList()
        rawEntries.sortBy { it.first }

        val deduped = mutableListOf<Pair<Long, String>>()
        for (entry in rawEntries) {
            val last = deduped.lastOrNull()
            if (last == null || abs(last.first - entry.first) > 80L || last.second != entry.second) {
                deduped.add(entry)
            }
        }

        val result = mutableListOf<LyricLine>()
        for (i in deduped.indices) {
            val start = deduped[i].first
            val nextStart = if (i + 1 < deduped.size) {
                deduped[i + 1].first.coerceAtLeast(start + 400L)
            } else {
                totalDurationMs.coerceAtLeast(start + 4000L)
            }
            val text = deduped[i].second
            val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }

            val realisticVocalDurationMs = (text.length * 95L + 450L).coerceIn(1100L, 4500L)
            val availableGapMs = (nextStart - start - 100L).coerceAtLeast(400L)
            val vocalEnd = start + minOf(realisticVocalDurationMs, availableGapMs)

            result.add(
                LyricLine(
                    startMs = start,
                    endMs = vocalEnd.coerceAtLeast(start + 350L),
                    words = words,
                    fullText = text
                )
            )
        }
        return result
    }

    /**
     * Videonun doğrudan kendi YouTube altyazı (captionTracks json3) zaman damgalarını çeker.
     */
    private fun fetchYouTubeTimedCaptions(videoId: String, totalDurationMs: Long): List<LyricLine> {
        try {
            val bodyJson = JSONObject().apply {
                put("videoId", videoId)
                put("context", JSONObject().apply {
                    put("client", JSONObject().apply {
                        put("clientName", "WEB")
                        put("clientVersion", "2.20250201.01.00")
                        put("hl", "tr")
                        put("gl", "TR")
                    })
                })
            }
            val req = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val tracks = client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val root = JSONObject(resp.body?.string().orEmpty())
                root.optJSONObject("captions")
                    ?.optJSONObject("playerCaptionsTracklistRenderer")
                    ?.optJSONArray("captionTracks")
            } ?: return emptyList()

            if (tracks.length() == 0) return emptyList()

            // Önce insan yapımı (kind != "asr") altyazıyı, yoksa otomatik altyazıyı seç
            var chosenUrl: String? = null
            for (i in 0 until tracks.length()) {
                val t = tracks.optJSONObject(i) ?: continue
                val kind = t.optString("kind", "")
                val baseUrl = t.optString("baseUrl", "")
                if (baseUrl.isNotBlank() && kind != "asr") {
                    chosenUrl = baseUrl
                    break
                }
            }
            if (chosenUrl == null) {
                chosenUrl = tracks.optJSONObject(0)?.optString("baseUrl")
            }
            if (chosenUrl.isNullOrBlank()) return emptyList()

            val json3Url = if (chosenUrl.contains("fmt=")) {
                chosenUrl.replace(Regex("fmt=[^&]+"), "fmt=json3")
            } else {
                "$chosenUrl&fmt=json3"
            }

            val capReq = Request.Builder()
                .url(json3Url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            client.newCall(capReq).execute().use { capResp ->
                if (!capResp.isSuccessful) return emptyList()
                val capRoot = JSONObject(capResp.body?.string().orEmpty())
                val events = capRoot.optJSONArray("events") ?: return emptyList()
                val rawEntries = mutableListOf<Triple<Long, Long, String>>()

                for (i in 0 until events.length()) {
                    val ev = events.optJSONObject(i) ?: continue
                    val startMs = ev.optLong("tStartMs", -1L)
                    val durMs = ev.optLong("dDurationMs", 2500L)
                    if (startMs < 0L) continue
                    val segs = ev.optJSONArray("segs") ?: continue
                    val sb = StringBuilder()
                    for (j in 0 until segs.length()) {
                        sb.append(segs.optJSONObject(j)?.optString("utf8").orEmpty())
                    }
                    val text = sb.toString()
                        .replace("\n", " ")
                        .replace(Regex("\\[[^]]*]"), " ")
                        .replace("♪", " ")
                        .replace(Regex("\\s+"), " ")
                        .trim()
                    if (text.length >= 2) {
                        rawEntries.add(Triple(startMs, (startMs + durMs).coerceAtMost(totalDurationMs), text))
                    }
                }

                if (rawEntries.isEmpty()) return emptyList()
                return rawEntries.map { (s, e, txt) ->
                    val words = txt.split(Regex("\\s+")).filter { it.isNotBlank() }
                    LyricLine(
                        startMs = s,
                        endMs = e.coerceAtLeast(s + 500L),
                        words = words,
                        fullText = txt
                    )
                }
            }
        } catch (_: Exception) {
            return emptyList()
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}
