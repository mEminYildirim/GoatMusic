package com.goatmusic.app.engine

import com.goatmusic.app.model.GoatTrack
import com.goatmusic.app.model.LyricLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.roundToLong

object GoatLyricsEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val cache = mutableMapOf<String, List<LyricLine>>()

    private data class AsrTimedWord(
        val timeMs: Long,
        val normWord: String
    )

    private data class YouTubeVideoCaptionInfo(
        val videoDurationSec: Double,
        val videoTitle: String,
        val videoAuthor: String,
        val manualLines: List<LyricLine>,
        val asrLines: List<LyricLine>,
        val asrWords: List<AsrTimedWord>
    )

    private data class ParsedCandidate(
        val obj: JSONObject,
        val lines: List<LyricLine>,
        val declaredDurationSec: Double,
        val firstVocalSec: Double,
        val lastVocalSec: Double,
        val isCandidateSlowedOrSped: Boolean
    )

    suspend fun fetchSynchronizedLyrics(
        track: GoatTrack,
        durationMs: Long
    ): List<LyricLine> = withContext(Dispatchers.IO) {
        val durationBucket = if (durationMs > 20_000L) (durationMs / 1000L) else 0L
        val cacheKey = "${track.id}_$durationBucket"
        if (durationBucket > 0L) {
            cache[cacheKey]?.let { if (it.isNotEmpty()) return@withContext it }
        }

        val ytDeferred = async { fetchYouTubeCaptionInfo(track.id, durationMs) }

        val (initialArtist, initialSong) = extractArtistAndSong(track.title, track.artist)

        val allCandidates = mutableListOf<JSONObject>()
        if (initialSong.isNotBlank() && initialArtist.isNotBlank()) {
            fetchCandidatesFromUrl(
                "https://lrclib.net/api/search?track_name=${enc(initialSong)}&artist_name=${enc(initialArtist)}",
                allCandidates
            )
        }
        if (initialSong.isNotBlank()) {
            fetchCandidatesFromUrl(
                "https://lrclib.net/api/search?track_name=${enc(initialSong)}",
                allCandidates
            )
        }

        val queries = listOf(
            "$initialArtist $initialSong".trim(),
            initialSong,
            cleanNoise(track.title)
        ).distinct().filter { it.length >= 2 }

        for (q in queries) {
            if (allCandidates.size >= 45) break
            fetchCandidatesFromUrl("https://lrclib.net/api/search?q=${enc(q)}", allCandidates)
        }

        val ytInfo = ytDeferred.await()

        val trueDurationSec = when {
            durationMs > 20_000L -> durationMs / 1000.0
            ytInfo != null && ytInfo.videoDurationSec > 20.0 -> ytInfo.videoDurationSec
            track.durationSec > 20L -> track.durationSec.toDouble()
            else -> 0.0
        }
        val effectiveTotalDurationMs = if (trueDurationSec > 20.0) {
            (trueDurationSec * 1000.0).toLong()
        } else {
            210_000L
        }

        val combinedMetaLower = "${track.title} ${track.artist} ${ytInfo?.videoTitle.orEmpty()} ${ytInfo?.videoAuthor.orEmpty()}"
            .lowercase(Locale("tr"))
        val isSlowedTrack = combinedMetaLower.contains("slowed") || combinedMetaLower.contains("slow ") ||
            combinedMetaLower.contains("yavaş") || combinedMetaLower.contains("yavas") ||
            combinedMetaLower.contains("reverb") || combinedMetaLower.contains("0.8x") ||
            combinedMetaLower.contains("0.85x") || combinedMetaLower.contains("0.9x") ||
            combinedMetaLower.contains("daycore") || combinedMetaLower.contains("pitched down")
        val isSpedUpTrack = combinedMetaLower.contains("sped up") || combinedMetaLower.contains("speed up") ||
            combinedMetaLower.contains("spedup") || combinedMetaLower.contains("speedup") ||
            combinedMetaLower.contains("nightcore") || combinedMetaLower.contains("hızlandır") ||
            combinedMetaLower.contains("hizlandir") || combinedMetaLower.contains("1.15x") ||
            combinedMetaLower.contains("1.2x") || combinedMetaLower.contains("1.25x") ||
            combinedMetaLower.contains("1.3x")
        val isTempoModifiedTrack = isSlowedTrack || isSpedUpTrack
        val wantRemix = combinedMetaLower.contains("remix")
        val wantLive = combinedMetaLower.contains("live") || combinedMetaLower.contains("konser") || combinedMetaLower.contains("canlı")
        val wantAcoustic = combinedMetaLower.contains("akustik") || combinedMetaLower.contains("acoustic")

        if (allCandidates.isEmpty() && ytInfo != null && ytInfo.videoTitle.isNotBlank()) {
            val (ytArtist, ytSong) = extractArtistAndSong(ytInfo.videoTitle, ytInfo.videoAuthor)
            fetchCandidatesFromUrl("https://lrclib.net/api/search?q=${enc("$ytArtist $ytSong".trim())}", allCandidates)
        }

        // ÖNCELİK 1: Videoda insan yapımı (kind != "asr") resmi şarkı sözü altyazısı varsa doğrudan kullan
        if (ytInfo != null && ytInfo.manualLines.size >= 6) {
            if (durationBucket > 0L) cache[cacheKey] = ytInfo.manualLines
            return@withContext ytInfo.manualLines
        }

        // Tüm adayların LRC metinlerini ayrıştır, başlık/reklam satırlarını (00:00) temizle
        val parsedCandidates = allCandidates.mapNotNull { obj ->
            val synced = obj.optString("syncedLyrics")
            if (synced.isBlank() || synced == "null") return@mapNotNull null
            val lines = parseLrcText(
                lrc = synced,
                totalDurationMs = effectiveTotalDurationMs,
                expectedSong = initialSong,
                expectedArtist = initialArtist
            )
            if (lines.size < 4) return@mapNotNull null
            val declDur = obj.optDouble("duration", 0.0)
            val firstSec = lines.first().startMs / 1000.0
            val lastSec = lines.last().startMs / 1000.0
            val rawTrackAndArtist = "${obj.optString("trackName")} ${obj.optString("artistName")}".lowercase(Locale("tr"))
            val isCandTempoMod = rawTrackAndArtist.contains("slowed") || rawTrackAndArtist.contains("reverb") ||
                rawTrackAndArtist.contains("sped up") || rawTrackAndArtist.contains("speed up") ||
                rawTrackAndArtist.contains("nightcore")
            ParsedCandidate(
                obj = obj,
                lines = lines,
                declaredDurationSec = declDur,
                firstVocalSec = firstSec,
                lastVocalSec = lastSec,
                isCandidateSlowedOrSped = isCandTempoMod
            )
        }

        // Aynı şarkının stüdyo adaylarına bakarak:
        // 1) Şarkıda gerçek bir enstrümantal giriş (intro >= 5sn) olup olmadığını tespit et
        // 2) Şarkının gerçek ORİJİNAL STÜDYO SÜRESİNİ (consensusStudioDurSec) hesapla!
        val titleMatchedCandidates = parsedCandidates.filter { pc ->
            matchesExpectedSongTitle(pc.obj.optString("trackName", ""), initialSong)
        }

        val hasRealIntroCandidate = titleMatchedCandidates.any { it.firstVocalSec >= 5.0 }

        val studioDurations = titleMatchedCandidates
            .filter { pc ->
                !pc.isCandidateSlowedOrSped &&
                    pc.declaredDurationSec > 35.0 &&
                    (pc.declaredDurationSec - pc.lastVocalSec) in 1.5..26.0
            }
            .map { it.declaredDurationSec }
            .sorted()

        val consensusStudioDurSec = if (studioDurations.isNotEmpty()) {
            studioDurations[studioDurations.size / 2]
        } else {
            0.0
        }

        val scoredSynced = parsedCandidates
            .mapNotNull { pc ->
                val score = scoreCandidate(
                    pc = pc,
                    expectedSong = initialSong,
                    expectedArtist = initialArtist,
                    targetDurationSec = trueDurationSec,
                    consensusStudioDurSec = consensusStudioDurSec,
                    hasRealIntroCandidate = hasRealIntroCandidate,
                    isSlowedTrack = isSlowedTrack,
                    isSpedUpTrack = isSpedUpTrack,
                    wantRemix = wantRemix,
                    wantLive = wantLive,
                    wantAcoustic = wantAcoustic
                )
                if (score < 1000.0) (score to pc) else null
            }
            .sortedBy { it.first }

        for ((_, bestPc) in scoredSynced) {
            val aligned = alignLrcWithYouTubeVideo(
                lrcLines = bestPc.lines,
                lrcDurationSec = bestPc.declaredDurationSec,
                consensusStudioDurSec = consensusStudioDurSec,
                videoDurationSec = trueDurationSec,
                isTempoModifiedTrack = isTempoModifiedTrack,
                asrWords = ytInfo?.asrWords.orEmpty(),
                asrLines = ytInfo?.asrLines.orEmpty(),
                totalDurationMs = effectiveTotalDurationMs
            )
            if (durationBucket > 0L) {
                cache[cacheKey] = aligned
            }
            return@withContext aligned
        }

        if (ytInfo != null) {
            val fallbackLines = ytInfo.manualLines.ifEmpty { ytInfo.asrLines }
            if (fallbackLines.size >= 3) {
                if (durationBucket > 0L) cache[cacheKey] = fallbackLines
                return@withContext fallbackLines
            }
        }

        emptyList()
    }

    /**
     * hem Slowed / Sped-Up süre oranını (`videoDurationSec / trueOriginalLrcDurSec`) hem de
     * giriş müziği (intro) senkronunu milisaniye hassasiyetinde hizalar!
     */
    private fun alignLrcWithYouTubeVideo(
        lrcLines: List<LyricLine>,
        lrcDurationSec: Double,
        consensusStudioDurSec: Double,
        videoDurationSec: Double,
        isTempoModifiedTrack: Boolean,
        asrWords: List<AsrTimedWord>,
        asrLines: List<LyricLine>,
        totalDurationMs: Long
    ): List<LyricLine> {
        if (lrcLines.isEmpty()) return lrcLines

        val lastLineSec = lrcLines.last().startMs / 1000.0

        // KRİTİK DÜZELTME:
        // Bazı LRCLIB kayıtlarında slowed şarkının süresi (örn. 220sn) yazıldığı halde içine
        // orijinal hızdaki şarkı sözleri (örn. 165sn'de biten) yapıştırılmıştır!
        // Eğer lrcDurationSec ile lastLineSec arasında 25 saniyeden fazla boşluk varsa ve
        // orijinal stüdyo süresi (consensusStudioDurSec) biliniyorsa, gerçek LRC süresi stüdyo süresidir!
        val effectiveLrcDurSec = when {
            isTempoModifiedTrack && consensusStudioDurSec > 30.0 &&
                abs(lastLineSec - consensusStudioDurSec) < abs(lastLineSec - lrcDurationSec) -> {
                consensusStudioDurSec
            }
            lrcDurationSec > 25.0 && (lrcDurationSec - lastLineSec) in 0.0..26.0 -> {
                lrcDurationSec
            }
            consensusStudioDurSec > 30.0 && abs(consensusStudioDurSec - lastLineSec) <= 22.0 -> {
                consensusStudioDurSec
            }
            lrcDurationSec > 25.0 && lrcDurationSec >= lastLineSec -> {
                if (lrcDurationSec - lastLineSec > 28.0) (lastLineSec + 10.0) else lrcDurationSec
            }
            else -> {
                (lastLineSec + 10.0).coerceAtLeast(30.0)
            }
        }

        val rawDurationRatio = if (videoDurationSec > 25.0 && effectiveLrcDurSec > 25.0) {
            videoDurationSec / effectiveLrcDurSec
        } else {
            1.0
        }

        val durationDiffSec = abs(videoDurationSec - effectiveLrcDurSec)

        // Slowed (1.04x .. 1.80x) veya Sped-Up (0.52x .. 0.96x) oranını otomatik uygula
        val isRatioSlowedOrSped = rawDurationRatio in 0.52..0.95 || rawDurationRatio in 1.05..1.80
        val scale = when {
            durationDiffSec <= 1.2 -> 1.0
            (isTempoModifiedTrack || isRatioSlowedOrSped) && rawDurationRatio in 0.52..1.80 -> rawDurationRatio
            rawDurationRatio in 0.95..1.05 -> rawDurationRatio
            else -> 1.0
        }

        if (isTempoModifiedTrack || scale < 0.95 || scale > 1.05) {
            val ratioScaledLines = lrcLines.map { line ->
                val newStart = (line.startMs * scale).roundToLong().coerceAtLeast(0L)
                line.copy(startMs = newStart)
            }
            return recomputeLineEndings(ratioScaledLines, totalDurationMs, scale)
        }

        val preScaledLines = lrcLines.map { line ->
            line.copy(startMs = (line.startMs * scale).roundToLong().coerceAtLeast(0L))
        }

        val residualOffsets = mutableListOf<Double>()

        if (asrWords.size >= 6) {
            for (line in preScaledLines) {
                val lineNormWords = normalizeForMatch(line.fullText)
                    .split(" ")
                    .filter { it.length >= 2 }
                if (lineNormWords.isEmpty()) continue

                val firstWord = lineNormWords.first()
                val secondWord = lineNormWords.getOrNull(1)

                var bestMatchTimeMs: Long? = null
                var bestDist = Long.MAX_VALUE

                for (idx in asrWords.indices) {
                    val aw = asrWords[idx]
                    val dist = abs(aw.timeMs - line.startMs)
                    if (dist > 22_000L) continue

                    val firstMatches = aw.normWord == firstWord ||
                        (firstWord.length >= 4 && aw.normWord.startsWith(firstWord.take(4)))
                    if (!firstMatches) continue

                    val verified = if (secondWord != null && idx + 1 < asrWords.size) {
                        val nextAw = asrWords[idx + 1]
                        nextAw.normWord == secondWord ||
                            (secondWord.length >= 4 && nextAw.normWord.startsWith(secondWord.take(4))) ||
                            firstWord.length >= 6
                    } else {
                        firstWord.length >= 5
                    }

                    if (verified && dist < bestDist) {
                        bestDist = dist
                        bestMatchTimeMs = aw.timeMs
                    }
                }

                if (bestMatchTimeMs != null) {
                    residualOffsets.add((bestMatchTimeMs - line.startMs).toDouble())
                }
            }
        }

        // Eğer LRC 0:00 - 0:03 arasında çok erken başlıyorsa ama YouTube sesinde ilk vokal daha geç
        // giriyorsa (giriş müziği / klip introsu varsa), intro kaymasını yakala!
        val firstLrcMs = preScaledLines.first().startMs
        val firstAsrMs = asrWords.firstOrNull()?.timeMs ?: asrLines.firstOrNull()?.startMs ?: 0L

        val fineOffsetMs = when {
            residualOffsets.size >= 3 -> {
                val sorted = residualOffsets.sorted()
                val median = sorted[sorted.size / 2]
                if (abs(median) in 250.0..18_000.0) median else 0.0
            }
            firstLrcMs < 2500L && firstAsrMs in 4500L..22_000L && durationDiffSec >= 3.0 -> {
                (firstAsrMs - firstLrcMs).toDouble()
            }
            else -> 0.0
        }

        val finalLines = lrcLines.map { line ->
            val newStart = (line.startMs * scale + fineOffsetMs).roundToLong().coerceAtLeast(0L)
            line.copy(startMs = newStart)
        }

        return recomputeLineEndings(finalLines, totalDurationMs, scale)
    }

    private fun recomputeLineEndings(
        lines: List<LyricLine>,
        totalDurationMs: Long,
        tempoScale: Double = 1.0
    ): List<LyricLine> {
        if (lines.isEmpty()) return lines
        val safeScale = tempoScale.coerceIn(0.55, 1.75)
        return lines.mapIndexed { i, line ->
            val start = line.startMs
            val nextStart = if (i + 1 < lines.size) {
                lines[i + 1].startMs.coerceAtLeast(start + 400L)
            } else {
                totalDurationMs.coerceAtLeast(start + 4500L)
            }
            val gap = (nextStart - start).coerceAtLeast(400L)
            val naturalHoldMs = ((line.fullText.length * 185L + 1600L) * safeScale).roundToLong().coerceIn(1800L, 10_500L)
            val vocalSpan = minOf((gap * 0.92).toLong().coerceAtLeast(380L), naturalHoldMs)
            line.copy(
                startMs = start,
                endMs = (start + vocalSpan).coerceAtLeast(start + 380L)
            )
        }
    }

    private fun fetchYouTubeCaptionInfo(videoId: String, knownDurationMs: Long): YouTubeVideoCaptionInfo? {
        try {
            val visitorData = GoatStreamEngine.getCurrentVisitorData()
            val payload = JSONObject().apply {
                put("videoId", videoId)
                put("contentCheckOk", true)
                put("racyCheckOk", true)
                put("context", JSONObject().apply {
                    put("client", JSONObject().apply {
                        put("clientName", "ANDROID_VR")
                        put("clientVersion", "1.56.21")
                        put("hl", "tr")
                        put("gl", "TR")
                        put("osName", "Android")
                        put("osVersion", "12L")
                        put("deviceMake", "Oculus")
                        put("deviceModel", "Quest 3")
                        put("androidSdkVersion", 32)
                        if (!visitorData.isNullOrBlank()) put("visitorData", visitorData)
                    })
                })
            }

            val reqBuilder = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
                .header("User-Agent", GoatStreamEngine.VR_USER_AGENT)
                .header("Content-Type", "application/json")
                .header("X-YouTube-Client-Name", "28")
                .header("X-YouTube-Client-Version", "1.56.21")
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))

            if (!visitorData.isNullOrBlank()) {
                reqBuilder.header("X-Goog-Visitor-Id", visitorData)
            }
            val cookies = GoatStreamEngine.getYouTubeCookies()
            if (cookies.isNotBlank()) {
                reqBuilder.header("Cookie", cookies)
            }

            var durSec = (knownDurationMs / 1000.0).takeIf { it > 20.0 } ?: 0.0
            var vidTitle = ""
            var vidAuthor = ""
            var manualUrl: String? = null
            var asrUrl: String? = null

            client.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val root = JSONObject(resp.body?.string().orEmpty())
                val vd = root.optJSONObject("videoDetails")
                if (vd != null) {
                    val lenSec = vd.optString("lengthSeconds", "0").toDoubleOrNull() ?: 0.0
                    if (lenSec > 20.0) durSec = lenSec
                    vidTitle = vd.optString("title", "")
                    vidAuthor = vd.optString("author", "")
                }

                val tracks = root.optJSONObject("captions")
                    ?.optJSONObject("playerCaptionsTracklistRenderer")
                    ?.optJSONArray("captionTracks")

                if (tracks != null) {
                    for (i in 0 until tracks.length()) {
                        val t = tracks.optJSONObject(i) ?: continue
                        val kind = t.optString("kind", "")
                        val baseUrl = t.optString("baseUrl", "")
                        val lang = t.optString("languageCode", "")
                        if (baseUrl.isBlank()) continue
                        if (kind == "asr") {
                            if (asrUrl == null || lang.startsWith("tr") || lang.startsWith("en")) {
                                asrUrl = baseUrl
                            }
                        } else {
                            if (manualUrl == null || lang.startsWith("tr") || lang.startsWith("en")) {
                                manualUrl = baseUrl
                            }
                        }
                    }
                }
            }

            val totalMs = ((durSec.takeIf { it > 20.0 } ?: 200.0) * 1000.0).toLong()
            val manualParsed = manualUrl?.let { downloadJson3LinesAndWords(it, totalMs) }
            val asrParsed = asrUrl?.let { downloadJson3LinesAndWords(it, totalMs) }

            return YouTubeVideoCaptionInfo(
                videoDurationSec = durSec,
                videoTitle = vidTitle,
                videoAuthor = vidAuthor,
                manualLines = manualParsed?.first.orEmpty(),
                asrLines = asrParsed?.first.orEmpty(),
                asrWords = asrParsed?.second.orEmpty()
            )
        } catch (_: Exception) {
            return null
        }
    }

    private fun downloadJson3LinesAndWords(
        baseUrl: String,
        totalDurationMs: Long
    ): Pair<List<LyricLine>, List<AsrTimedWord>> {
        try {
            val json3Url = if (baseUrl.contains("fmt=")) {
                baseUrl.replace(Regex("fmt=[^&]+"), "fmt=json3")
            } else {
                "$baseUrl&fmt=json3"
            }
            val req = Request.Builder()
                .url(json3Url)
                .header("User-Agent", GoatStreamEngine.VR_USER_AGENT)
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList<LyricLine>() to emptyList()
                val root = JSONObject(resp.body?.string().orEmpty())
                val events = root.optJSONArray("events") ?: return emptyList<LyricLine>() to emptyList()
                val rawList = mutableListOf<LyricLine>()
                val timedWords = mutableListOf<AsrTimedWord>()

                for (i in 0 until events.length()) {
                    val ev = events.optJSONObject(i) ?: continue
                    val startMs = ev.optLong("tStartMs", -1L)
                    val durMs = ev.optLong("dDurationMs", 2800L)
                    if (startMs < 0L) continue
                    val segs = ev.optJSONArray("segs") ?: continue
                    val sb = StringBuilder()
                    for (j in 0 until segs.length()) {
                        val segObj = segs.optJSONObject(j) ?: continue
                        val utf8 = segObj.optString("utf8").orEmpty()
                        val offsetMs = segObj.optLong("tOffsetMs", 0L)
                        sb.append(utf8)

                        val normW = normalizeForMatch(utf8)
                        if (normW.length >= 2 && normW != "muzik" && normW != "music") {
                            normW.split(" ").filter { it.length >= 2 }.forEach { wToken ->
                                timedWords.add(AsrTimedWord(timeMs = startMs + offsetMs, normWord = wToken))
                            }
                        }
                    }
                    val text = sb.toString()
                        .replace("\n", " ")
                        .replace(Regex("\\[[^]]*]"), " ")
                        .replace(Regex("\\([^)]*\\)"), " ")
                        .replace("♪", " ")
                        .replace("♫", " ")
                        .replace(Regex("\\s+"), " ")
                        .trim()

                    if (text.length >= 2 && !text.equals("müzik", ignoreCase = true) && !text.equals("music", ignoreCase = true)) {
                        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
                        if (words.isNotEmpty()) {
                            rawList.add(
                                LyricLine(
                                    startMs = startMs,
                                    endMs = (startMs + durMs).coerceAtMost(totalDurationMs).coerceAtLeast(startMs + 500L),
                                    words = words,
                                    fullText = text
                                )
                            )
                        }
                    }
                }
                return recomputeLineEndings(rawList, totalDurationMs) to timedWords
            }
        } catch (_: Exception) {
            return emptyList<LyricLine>() to emptyList()
        }
    }

    private fun fetchCandidatesFromUrl(url: String, outList: MutableList<JSONObject>) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "GoatMusic/17.0 (Android)")
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val arr = JSONArray(resp.body?.string().orEmpty())
                    val existingIds = outList.map { it.optInt("id", -1) }.toSet()
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val id = obj.optInt("id", -1)
                        if (id == -1 || !existingIds.contains(id)) {
                            outList.add(obj)
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun extractArtistAndSong(rawTitle: String, rawChannel: String): Pair<String, String> {
        val cleanTitle = cleanNoise(rawTitle)
        val cleanChannel = rawChannel
            .replace(Regex("(?i)(-\\s*topic|vevo|official|resmi|müzik|muzik|music|records|yapım|yapim|production|netd|slowed|sped\\s*up|nightcore)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val separators = listOf(" - ", " – ", " — ", " | ", " // ")
        for (sep in separators) {
            if (cleanTitle.contains(sep)) {
                val parts = cleanTitle.split(sep).map { it.trim() }.filter { it.length >= 2 }
                if (parts.size >= 2) {
                    return parts[0] to parts[1]
                }
            }
        }
        return cleanChannel to cleanTitle
    }

    private fun cleanNoise(raw: String): String {
        return raw
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\[[^]]*]"), " ")
            .replace(
                Regex("(?i)(official\\s*music\\s*video|official\\s*video|official\\s*audio|music\\s*video|lyric\\s*video|lyrics|lyric|şarkı\\s*sözleri|sarki\\s*sozleri|slowed\\s*[+&and]*\\s*reverb|slowed\\s*down|slowed|reverb|sped\\s*up|speed\\s*up|spedup|speedup|nightcore|yavaşlatılmış|yavaslatilmis|hızlandırılmış|hizlandirilmis|tiktok\\s*version|tiktok\\s*edit|0\\.8x|0\\.85x|0\\.9x|1\\.15x|1\\.2x|1\\.25x|1\\.3x|hd|4k|hq|visualizer|klip|video\\s*klip|feat\\.?|ft\\.?)"),
                " "
            )
            .replace(Regex("[-–—|&+]+\\s*$"), " ")
            .replace(Regex("^\\s*[-–—|&+]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeForMatch(s: String): String {
        return s.lowercase(Locale("tr"))
            .replace('ı', 'i')
            .replace('İ', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun matchesExpectedSongTitle(rawCandTrack: String, expectedSong: String): Boolean {
        val normCandTrack = normalizeForMatch(cleanNoise(rawCandTrack))
        val normExpectedSong = normalizeForMatch(expectedSong)
        if (normCandTrack.isBlank() || normExpectedSong.isBlank()) return false
        val songTokens = normExpectedSong.split(" ").filter { it.length >= 2 }
        if (songTokens.isEmpty()) return normCandTrack.contains(normExpectedSong)
        val matched = songTokens.count { token -> normCandTrack.contains(token) }
        return matched > 0 || normCandTrack.contains(normExpectedSong.take(5))
    }

    private fun scoreCandidate(
        pc: ParsedCandidate,
        expectedSong: String,
        expectedArtist: String,
        targetDurationSec: Double,
        consensusStudioDurSec: Double,
        hasRealIntroCandidate: Boolean,
        isSlowedTrack: Boolean,
        isSpedUpTrack: Boolean,
        wantRemix: Boolean,
        wantLive: Boolean,
        wantAcoustic: Boolean
    ): Double {
        val obj = pc.obj
        val rawCandTrack = obj.optString("trackName", "")
        val rawCandArtist = obj.optString("artistName", "")
        val candTrack = cleanNoise(rawCandTrack)
        val candDur = pc.declaredDurationSec

        val normCandTrack = normalizeForMatch(candTrack)
        val normCandArtist = normalizeForMatch(rawCandArtist)
        val normExpectedSong = normalizeForMatch(expectedSong)
        val normExpectedArtist = normalizeForMatch(expectedArtist)

        if (!matchesExpectedSongTitle(rawCandTrack, expectedSong)) return 9999.0

        val combinedRawCand = normalizeForMatch("$rawCandTrack $rawCandArtist")
        if (!wantRemix && combinedRawCand.contains("remix")) return 9999.0
        if (!wantLive && (combinedRawCand.contains("live") || combinedRawCand.contains("konser"))) return 9999.0
        if (!wantAcoustic && (combinedRawCand.contains("acoustic") || combinedRawCand.contains("akustik"))) return 9999.0

        val isTempoModifiedTrack = isSlowedTrack || isSpedUpTrack
        if (!isTempoModifiedTrack && pc.isCandidateSlowedOrSped) {
            return 9999.0
        }

        // KRİTİK: Eğer şarkıda enstrümantal giriş (intro >= 5sn) olan düzgün bir LRC adayı varsa,
        // 0:00 - 0:01.8 saniyede (daha giriş müziği çalarken) hemen başlayan hatalı LRC adaylarına ağır ceza ver!
        val prematureIntroPenalty = if (hasRealIntroCandidate && pc.firstVocalSec < 2.0) {
            42.0
        } else if (pc.firstVocalSec >= 4.0) {
            -12.0
        } else {
            0.0
        }

        // Eğer bir LRC adayının beyan edilen süresi (candDur) son satırdan 28 saniyeden fazla uzunsa
        // (örneğin slowed süre yazılıp içine ölçeklenmemiş orijinal sözler konmuşsa) ceza ver ki
        // temiz stüdyo LRC'si seçilip gerçek oranla (targetDurationSec / candDur) ölçeklensin!
        val unscaledMismatchPenalty = if (candDur > 30.0 && (candDur - pc.lastVocalSec) > 28.0) {
            35.0
        } else {
            0.0
        }

        val durScore = if (targetDurationSec > 20.0 && candDur > 20.0) {
            val diff = abs(candDur - targetDurationSec)
            val ratio = targetDurationSec / candDur
            when {
                // Slowed veya Sped-Up şarkılarda temiz ORİJİNAL STÜDYO kaydını (veya doğru ölçeklenmiş kaydı) seç
                isSlowedTrack && !pc.isCandidateSlowedOrSped && ratio in 1.05..1.75 -> {
                    -42.0 + abs(1.22 - ratio) * 8.0
                }
                isSpedUpTrack && !pc.isCandidateSlowedOrSped && ratio in 0.55..0.95 -> {
                    -42.0 + abs(0.80 - ratio) * 8.0
                }
                diff <= 2.2 -> -45.0
                diff <= 6.0 -> -22.0 + diff * 2.0
                consensusStudioDurSec > 30.0 && abs(candDur - consensusStudioDurSec) <= 3.0 && ratio in 0.55..1.75 -> {
                    -30.0
                }
                ratio in 0.58..1.70 -> diff * 0.5
                else -> return 9999.0
            }
        } else {
            10.0
        }

        val exactSongBonus = if (normCandTrack == normExpectedSong) -30.0
        else if (normCandTrack.contains(normExpectedSong) || normExpectedSong.contains(normCandTrack)) -16.0
        else 15.0

        val artistTokens = normExpectedArtist.split(" ").filter { it.length >= 2 }
        val artistMatched = artistTokens.any { normCandArtist.contains(it) || normCandTrack.contains(it) }
        val artistPenalty = if (artistMatched) -15.0 else 14.0

        return durScore + exactSongBonus + artistPenalty + prematureIntroPenalty + unscaledMismatchPenalty
    }

    private fun parseLrcText(
        lrc: String,
        totalDurationMs: Long,
        expectedSong: String = "",
        expectedArtist: String = ""
    ): List<LyricLine> {
        val rawEntries = mutableListOf<Pair<Long, String>>()
        val timestampRegex = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")
        val inlineTagRegex = Regex("<\\d{1,2}:\\d{2}(?:[.:]\\d{1,3})?>")

        val offsetMatch = Regex("(?i)\\[offset:\\s*([+-]?\\d+)\\s*]").find(lrc)
        val lrcHeaderOffsetMs = offsetMatch?.groupValues?.get(1)?.toLongOrNull() ?: 0L

        for (rawLine in lrc.lines()) {
            val line = rawLine.trim()
            val matches = timestampRegex.findAll(line).toList()
            if (matches.isEmpty()) continue

            val cleanText = line
                .replace(timestampRegex, "")
                .replace(inlineTagRegex, " ")
                .replace(Regex("\\s+"), " ")
                .trim()

            if (cleanText.isBlank()) continue

            for (m in matches) {
                val min = m.groupValues[1].toLongOrNull() ?: 0L
                val sec = m.groupValues[2].toLongOrNull() ?: 0L
                val fracStr = m.groupValues[3]
                val millis = when (fracStr.length) {
                    1 -> (fracStr.toLongOrNull() ?: 0L) * 100L
                    2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                    3 -> fracStr.toLongOrNull() ?: 0L
                    else -> 0L
                }
                val timeMs = (min * 60_000L + sec * 1_000L + millis - lrcHeaderOffsetMs).coerceAtLeast(0L)
                rawEntries.add(timeMs to cleanText)
            }
        }

        if (rawEntries.isEmpty()) return emptyList()
        rawEntries.sortBy { it.first }

        val deduped = mutableListOf<Pair<Long, String>>()
        for (entry in rawEntries) {
            val last = deduped.lastOrNull()
            if (last == null || abs(last.first - entry.first) > 80L || last.second != entry.second) {
                deduped.add(entry)
            }
        }

        // KRİTİK FİLTRE: İlk 5 saniyede (00:00..00:05) yer alan "Şarkı Adı - Sanatçı", "Söz & Müzik",
        // "Synced by...", "www..." gibi sahte başlık satırlarını temizle ki giriş müziği çalarken
        // şarkı sözü başlamış gibi gözükmesin!
        val normSong = normalizeForMatch(expectedSong)
        val normArtist = normalizeForMatch(expectedArtist)
        val creditRegex = Regex("(?i)(lyrics?\\s*by|synced\\s*by|söz\\s*[:&]|müzik\\s*[:&]|prod\\.?\\s*by|www\\.|\\.com|\\.net|hazırlayan|çeviri|ceviri|arpej|intro|giriş\\s*müziği|enstrümantal)")

        val filteredEntries = deduped.filterIndexed { idx, (timeMs, text) ->
            if (idx <= 2 && timeMs < 5500L) {
                val normLine = normalizeForMatch(text)
                val nextTimeMs = deduped.getOrNull(idx + 1)?.first ?: (timeMs + 1000L)
                val gapToNext = nextTimeMs - timeMs
                val isCreditLine = creditRegex.containsMatchIn(text)
                val isTitleEcho = normSong.length >= 3 && normLine.contains(normSong) &&
                    ((normArtist.length >= 3 && normLine.contains(normArtist)) || gapToNext >= 3500L || timeMs <= 1200L)
                !(isCreditLine || isTitleEcho)
            } else {
                true
            }
        }.ifEmpty { deduped }

        val initialLines = filteredEntries.map { (start, text) ->
            val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
            LyricLine(
                startMs = start,
                endMs = start + 2500L,
                words = words,
                fullText = text
            )
        }
        return recomputeLineEndings(initialLines, totalDurationMs, 1.0)
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}
