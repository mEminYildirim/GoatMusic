package com.goatmusic.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.goatmusic.app.ui.GoatMusicApp
import com.goatmusic.app.ui.GoatViewModel
import com.goatmusic.app.ui.theme.GoatMusicTheme

class MainActivity : ComponentActivity() {

    private var warmupWebView: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Android 13+ icin Spotify tarzi medya bildirimi iznini iste
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }

        try {
            val cm = CookieManager.getInstance()
            cm.setAcceptCookie(true)
            warmupWebView = WebView(applicationContext).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        CookieManager.getInstance().flush()
                    }
                }
                loadUrl("https://m.youtube.com")
            }
        } catch (_: Exception) {
        }

        setContent {
            GoatMusicTheme {
                val vm: GoatViewModel = viewModel()
                GoatMusicApp(vm = vm)
            }
        }
    }

    override fun onDestroy() {
        warmupWebView?.destroy()
        warmupWebView = null
        super.onDestroy()
    }
}
