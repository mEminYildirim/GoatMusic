package com.goatmusic.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.goatmusic.app.player.GoatNotificationBridge
import com.goatmusic.app.ui.GoatMusicApp
import com.goatmusic.app.ui.GoatViewModel
import com.goatmusic.app.ui.theme.GoatMusicTheme

class MainActivity : ComponentActivity() {

    private val viewModel: GoatViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.onPermissionsGranted()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNecessaryPermissions()

        setContent {
            GoatMusicTheme {
                GoatMusicApp(vm = viewModel)
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) {
            viewModel.shutdownPlayerAndNotification()
            GoatNotificationBridge.cancelNotificationAndRelease(applicationContext)
        }
        super.onDestroy()
    }

    private fun requestNecessaryPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (perms.isNotEmpty()) {
            permissionLauncher.launch(perms.toTypedArray())
        } else {
            viewModel.onPermissionsGranted()
        }
    }
}
