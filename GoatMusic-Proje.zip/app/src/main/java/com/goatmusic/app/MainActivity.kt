package com.goatmusic.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.goatmusic.app.player.GoatNotificationBridge
import com.goatmusic.app.ui.GoatMusicApp
import com.goatmusic.app.ui.GoatViewModel
import com.goatmusic.app.ui.theme.GoatMusicTheme

class MainActivity : ComponentActivity() {

    private val viewModel: GoatViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.onPermissionsGranted()
    }

    private val manageStorageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.onPermissionsGranted()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNecessaryPermissions()

        setContent {
            GoatMusicTheme {
                GoatMusicApp(vm = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.onPermissionsGranted()
    }

    override fun onDestroy() {
        if (isFinishing) {
            viewModel.shutdownPlayerAndNotification()
            GoatNotificationBridge.cancelNotificationAndRelease(applicationContext)
        }
        super.onDestroy()
    }

    private fun requestNecessaryPermissions() {
        // Documents/GoatMusic_Vault içindeki 37 indirilen şarkının ve veritabanının
        // uygulama silinip yüklense bile %100 okunabilmesi için Android 11+ dosya erişimi kontrolü
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            runCatching {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                manageStorageLauncher.launch(intent)
            }.onFailure {
                runCatching {
                    manageStorageLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            }
        }

        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
                perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
        if (perms.isNotEmpty()) {
            permissionLauncher.launch(perms.toTypedArray())
        } else {
            viewModel.onPermissionsGranted()
        }
    }
}
