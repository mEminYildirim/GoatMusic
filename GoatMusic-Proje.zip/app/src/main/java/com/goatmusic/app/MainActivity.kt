package com.goatmusic.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.goatmusic.app.ui.GoatMusicApp
import com.goatmusic.app.ui.GoatViewModel
import com.goatmusic.app.ui.theme.GoatMusicTheme

class MainActivity : ComponentActivity() {

    private var warmupWebView: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            val cm = CookieManager.getInstance()
            cm.setAcceptCookie(true)
            warmupWebView = WebView(applicationContext).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        CookieManager.getInstance().flush()
                    }
                }
                loadUrl("https://m.youtube.com")
            }
        } catch (_: Exception) {
        }

        setContent {
            GoatMusicTheme {
                val vm: GoatViewModel = viewModel()
                GoatMusicApp(vm = vm)
            }
        }
    }

    override fun onDestroy() {
        warmupWebView?.destroy()
        warmupWebView = null
        super.onDestroy()
    }
}
