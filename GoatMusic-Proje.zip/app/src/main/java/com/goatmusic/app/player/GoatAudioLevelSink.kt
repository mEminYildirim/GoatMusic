@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.goatmusic.app.player

import androidx.media3.common.C
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

object GoatAudioLevelSink : TeeAudioProcessor.AudioBufferSink {

    @Volatile
    var currentIntensity: Float = 0f
        private set

    private var currentEncoding: Int = C.ENCODING_PCM_16BIT

    override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
        currentEncoding = encoding
    }

    override fun handleBuffer(buffer: ByteBuffer) {
        val dup = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val remaining = dup.remaining()
        if (remaining <= 0) return

        var sumSquares = 0.0
        var sampleCount = 0

        if (currentEncoding == C.ENCODING_PCM_FLOAT) {
            while (dup.remaining() >= 4 && sampleCount < 512) {
                val sample = dup.float.toDouble()
                if (!sample.isNaN() && !sample.isInfinite()) {
                    sumSquares += sample * sample
                    sampleCount++
                }
            }
        } else {
            while (dup.remaining() >= 2 && sampleCount < 512) {
                val sample = dup.short / 32768.0
                sumSquares += sample * sample
                sampleCount++
            }
        }

        if (sampleCount > 0) {
            val rms = sqrt(sumSquares / sampleCount).toFloat()
            val normalized = (rms * 3.1f).coerceIn(0f, 1f)
            val prev = currentIntensity
            currentIntensity = if (normalized > prev) {
                prev + (normalized - prev) * 0.42f
            } else {
                prev + (normalized - prev) * 0.18f
            }.coerceIn(0f, 1f)
        }
    }

    fun decayWhenPaused() {
        currentIntensity = (currentIntensity * 0.80f).let { if (it < 0.01f) 0f else it }
    }
}
