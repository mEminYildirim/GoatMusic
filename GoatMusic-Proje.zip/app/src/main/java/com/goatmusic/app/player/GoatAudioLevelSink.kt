@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.goatmusic.app.player

import androidx.media3.common.C
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * GoatAudioLevelSink v6.0:
 * O an calan sesin (PCM 16-bit / Float) dinamik taban (noise floor) ve tavan (peak) degerlerini
 * otomatik olceklendirir. Boylece sarkida ses alcaldiginda gosterge gercekten duser,
 * ses veya bas yukseldiginde gosterge dogal sekilde yukselir.
 */
object GoatAudioLevelSink : TeeAudioProcessor.AudioBufferSink {

    private var encoding: Int = C.ENCODING_PCM_16BIT
    private var rollingPeak: Float = 0.22f
    private var rollingFloor: Float = 0.02f

    @Volatile
    var currentIntensity: Float = 0f
        private set

    override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
        this.encoding = encoding
    }

    override fun handleBuffer(buffer: ByteBuffer) {
        try {
            val dup = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
            val rem = dup.remaining()
            if (rem < 8) return

            var sumSquares = 0.0
            var count = 0

            if (encoding == C.ENCODING_PCM_FLOAT) {
                var pos = dup.position()
                val limit = dup.limit() - 4
                val step = 16
                while (pos <= limit) {
                    val sample = dup.getFloat(pos).toDouble().coerceIn(-1.0, 1.0)
                    sumSquares += sample * sample
                    count++
                    pos += step
                }
            } else {
                var pos = dup.position()
                val limit = dup.limit() - 2
                val step = 12
                while (pos <= limit) {
                    val sample = dup.getShort(pos).toDouble() / 32768.0
                    sumSquares += sample * sample
                    count++
                    pos += step
                }
            }

            if (count > 0) {
                val rms = sqrt(sumSquares / count).toFloat()

                // Dinamik taban ve tavan adaptasyonu (sarkinin kendi ses araligina uyum saglar)
                rollingPeak = if (rms > rollingPeak) {
                    rms
                } else {
                    (rollingPeak * 0.992f + rms * 0.008f).coerceAtLeast(0.06f)
                }

                rollingFloor = if (rms < rollingFloor) {
                    rms
                } else {
                    (rollingFloor * 0.995f + rms * 0.005f).coerceAtMost(rollingPeak * 0.45f)
                }

                val span = (rollingPeak - rollingFloor).coerceAtLeast(0.04f)
                val normalized = ((rms - rollingFloor) / span).coerceIn(0f, 1f)

                // Kontrast egrisi: dusuk seslerde gercekten dusuk, yuksek seslerde belirgin yuksek
                val shaped = (normalized * normalized * 0.75f + normalized * 0.25f).coerceIn(0f, 1f)

                currentIntensity = if (shaped > currentIntensity) {
                    currentIntensity * 0.60f + shaped * 0.40f
                } else {
                    currentIntensity * 0.84f + shaped * 0.16f
                }
            }
        } catch (_: Exception) {
        }
    }

    fun decayWhenPaused() {
        currentIntensity = (currentIntensity * 0.75f).coerceAtLeast(0f)
    }
}
