@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.goatmusic.app.player

import androidx.media3.common.C
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * ExoPlayer'in caldigi gercek PCM ses orneklerini (16-bit / Float) anlik analiz ederek
 * sarkinin gercek ses siddetini (RMS Loudness) hesaplar.
 * Sarki yukselirken dalga yukselir, sarki alcalirken veya sessizlesirken dalga alcalir.
 */
object GoatAudioLevelSink : TeeAudioProcessor.AudioBufferSink {

    private var encoding: Int = C.ENCODING_PCM_16BIT

    @Volatile
    var smoothedLoudness: Float = 0.06f
        private set

    override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
        this.encoding = encoding
    }

    override fun handleBuffer(buffer: ByteBuffer) {
        try {
            val dup = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
            val rem = dup.remaining()
            if (rem < 8) return

            var sumSquares = 0.0
            var count = 0

            if (encoding == C.ENCODING_PCM_FLOAT) {
                var pos = dup.position()
                val limit = dup.limit() - 4
                val step = 16
                while (pos <= limit) {
                    val sample = dup.getFloat(pos).toDouble().coerceIn(-1.0, 1.0)
                    sumSquares += sample * sample
                    count++
                    pos += step
                }
            } else {
                // Default 16-bit PCM
                var pos = dup.position()
                val limit = dup.limit() - 2
                val step = 12
                while (pos <= limit) {
                    val sample = dup.getShort(pos).toDouble() / 32768.0
                    sumSquares += sample * sample
                    count++
                    pos += step
                }
            }

            if (count > 0) {
                val rms = sqrt(sumSquares / count).toFloat()
                // Insan kulaginin algisina uygun logaritmik/karekok siddet egrisi (0.05 .. 1.0)
                val targetLevel = (sqrt(rms.toDouble()).toFloat() * 1.55f).coerceIn(0.05f, 1.0f)
                // Yumusak ve dogal gecis (Asiri hizli titremeyi onler)
                smoothedLoudness = if (targetLevel > smoothedLoudness) {
                    smoothedLoudness * 0.72f + targetLevel * 0.28f
                } else {
                    smoothedLoudness * 0.88f + targetLevel * 0.12f
                }
            }
        } catch (_: Exception) {
        }
    }

    fun resetToQuiet() {
        smoothedLoudness = smoothedLoudness * 0.80f + 0.05f * 0.20f
    }
}
