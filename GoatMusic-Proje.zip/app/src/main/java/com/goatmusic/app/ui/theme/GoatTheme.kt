package com.goatmusic.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ObsidianBlack = Color(0xFF06080D)
val DeepSlateBlack = Color(0xFF0D121C)
val CardMidnightBlue = Color(0xFF131B2E)
val SurfaceSteelBlue = Color(0xFF1B2640)
val ElectricCobalt = Color(0xFF2563EB)
val NeonSapphire = Color(0xFF38BDF8)
val PureIceWhite = Color(0xFFF1F5F9)
val MutedSilver = Color(0xFF94A3B8)
val CrimsonAccent = Color(0xFFEF4444)
val EmeraldSuccess = Color(0xFF10B981)

private val GoatColorScheme = darkColorScheme(
    primary = ElectricCobalt,
    secondary = NeonSapphire,
    tertiary = NeonSapphire,
    background = ObsidianBlack,
    surface = DeepSlateBlack,
    surfaceVariant = CardMidnightBlue,
    onPrimary = PureIceWhite,
    onSecondary = ObsidianBlack,
    onBackground = PureIceWhite,
    onSurface = PureIceWhite,
    onSurfaceVariant = MutedSilver
)

@Composable
fun GoatMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GoatColorScheme,
        content = content
    )
}
