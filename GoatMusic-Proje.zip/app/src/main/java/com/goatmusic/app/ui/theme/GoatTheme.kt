package com.goatmusic.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ObsidianBlack = Color(0xFF050811)
val DeepSlateBlack = Color(0xFF0B1222)
val CardMidnightBlue = Color(0xFF111C35)
val AmbientBlueGlow = Color(0xFF16284C)
val SurfaceSteelBlue = Color(0xFF223559)
val ElectricCobalt = Color(0xFF2563EB)
val NeonSapphire = Color(0xFF3B82F6)
val SoftSkyBlue = Color(0xFF60A5FA)
val PureIceWhite = Color(0xFFF8FAFC)
val MutedSilver = Color(0xFF94A3B8)
val SubtleGray = Color(0xFF64748B)
val EmeraldSuccess = Color(0xFF10B981)
val CrimsonAccent = Color(0xFFEF4444)

private val GoatDarkColors = darkColorScheme(
    primary = ElectricCobalt,
    secondary = NeonSapphire,
    tertiary = SoftSkyBlue,
    background = ObsidianBlack,
    surface = DeepSlateBlack,
    onPrimary = PureIceWhite,
    onSecondary = PureIceWhite,
    onBackground = PureIceWhite,
    onSurface = PureIceWhite
)

@Composable
fun GoatMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GoatDarkColors,
        content = content
    )
}
