package com.goatmusic.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Koyu Siyah & Hafif Modern Mavi Stüdyo Renk Paleti
val ObsidianBlack = Color(0xFF060911)
val DeepSlateBlack = Color(0xFF0C1322)
val CardMidnightBlue = Color(0xFF121D33)
val SurfaceSteelBlue = Color(0xFF1E2F4D)
val AmbientBlueGlow = Color(0xFF152C5B)
val ElectricCobalt = Color(0xFF2563EB)
val NeonSapphire = Color(0xFF3B82F6)
val SoftSkyBlue = Color(0xFF60A5FA)
val PureIceWhite = Color(0xFFF8FAFC)
val MutedSilver = Color(0xFF94A3B8)
val SubtleGray = Color(0xFF64748B)
val CrimsonAccent = Color(0xFFEF4444)
val EmeraldSuccess = Color(0xFF10B981)

private val GoatColorScheme = darkColorScheme(
    primary = ElectricCobalt,
    secondary = NeonSapphire,
    tertiary = SoftSkyBlue,
    background = ObsidianBlack,
    surface = DeepSlateBlack,
    surfaceVariant = CardMidnightBlue,
    onPrimary = PureIceWhite,
    onSecondary = ObsidianBlack,
    onBackground = PureIceWhite,
    onSurface = PureIceWhite,
    onSurfaceVariant = MutedSilver
)

@Composable
fun GoatMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GoatColorScheme,
        content = content
    )
}
