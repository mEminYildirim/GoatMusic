# GoatMusic ProGuard rules
-keep class com.goatmusic.app.** { *; }
